﻿using System;

namespace FileParser
{
    public class Class1
    {
    }
}
