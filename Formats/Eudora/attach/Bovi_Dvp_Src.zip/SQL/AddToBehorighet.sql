insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Produkt", "Show", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Produkt", "Edit", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Produkt", "Add", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Produkt", "Delete", "", "", "")
