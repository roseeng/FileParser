insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fraga", "Show", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fraga", "Edit", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fraga", "Add", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fraga", "Delete", "", "", "")
