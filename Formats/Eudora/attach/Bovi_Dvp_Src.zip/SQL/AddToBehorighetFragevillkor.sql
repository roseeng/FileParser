insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fragevillkor", "Show", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fragevillkor", "Edit", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fragevillkor", "Add", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Fragevillkor", "Delete", "", "", "")
