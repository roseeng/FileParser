insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Hjalptext", "Show", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Hjalptext", "Edit", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Hjalptext", "Add", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Hjalptext", "Delete", "", "", "")
