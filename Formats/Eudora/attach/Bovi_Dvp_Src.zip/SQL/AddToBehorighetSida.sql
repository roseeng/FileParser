insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Sida", "Show", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Sida", "Edit", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Sida", "Add", "", "", "")

insert into Beh�righet (AnvIdRolliNT, Bolag, Produktsystem, Delsystem, Funktion, Dom�niNT, Milj�, ObjektGrupp)
values("BoviAdmin", "*", "BoviAdm", "Sida", "Delete", "", "", "")
