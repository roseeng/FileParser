alter table bolag add LastUpdate datetime null
alter table bolag add LastUser varchar(40) null

alter table bolagsprodukt add LastUpdate datetime null
alter table bolagsprodukt add LastUser varchar(40) null

alter table fraga add LastUpdate datetime null
alter table fraga add LastUser varchar(40) null

alter table fragevillkor add LastUpdate datetime null
alter table fragevillkor add LastUser varchar(40) null

alter table hjalptext add LastUpdate datetime null
alter table hjalptext add LastUser varchar(40) null

alter table produkt add LastUpdate datetime null
alter table produkt add LastUser varchar(40) null

alter table sidordning add LastUpdate datetime null
alter table sidordning add LastUser varchar(40) null

alter table svarsalternativ add LastUpdate datetime null
alter table svarsalternativ add LastUser varchar(40) null

alter table termattribut add LastUpdate datetime null
alter table termattribut add LastUser varchar(40) null

