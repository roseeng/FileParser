if exists (select * from sysobjects where id = object_id(N'[dbo].[CheckFraga]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CheckFraga]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[CheckProdukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CheckProdukt]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromBolag]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromBolag]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromBolagsprodukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromBolagsprodukt]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromFragevillkor]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromFragevillkor]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromHjalptext]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromHjalptext]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromSidordning]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromSidordning]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromSvarsalternativ]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromSvarsalternativ]
GO

if exists (select * from sysobjects where id = object_id(N'[LWAB\b00sol].[DeleteFromTermattribut]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [LWAB\b00sol].[DeleteFromTermattribut]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoBolag]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoBolag]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoBolagsprodukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoBolagsprodukt]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoFragevillkor]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoFragevillkor]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoHjalptext]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoHjalptext]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoSidordning]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoSidordning]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoSvarsalternativ]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoSvarsalternativ]
GO

if exists (select * from sysobjects where id = object_id(N'[LWAB\b00sol].[InsertIntoTermattribut]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [LWAB\b00sol].[InsertIntoTermattribut]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[TransferBolag]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[TransferBolag]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[TransferBolagProdukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[TransferBolagProdukt]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[TransferGlobalTables]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[TransferGlobalTables]
GO

if exists (select * from sysobjects where id = object_id(N'[LWAB\b00gro].[TransferTableFraga]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [LWAB\b00gro].[TransferTableFraga]
GO

if exists (select * from sysobjects where id = object_id(N'[LWAB\b00gro].[TransferTableHjalptext]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [LWAB\b00gro].[TransferTableHjalptext]
GO

if exists (select * from sysobjects where id = object_id(N'[LWAB\b00gro].[TransferTableProdukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [LWAB\b00gro].[TransferTableProdukt]
GO

if exists (select * from sysobjects where id = object_id(N'[LWAB\b00gro].[TransferTableTermattribut]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [LWAB\b00gro].[TransferTableTermattribut]
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/****************************************************************************************************************************************************
Name:	CheckFraga

Desc:	...

In:	Bolagsnummer
	Databas	- Den databas som kontrollen skall ske i

Out:	Antal rader	- Antalet funna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kontrollen

Author:	2001-06-25, B00SOL

Rev:
****************************************************************************************************************************************************/
CREATE PROCEDURE CheckFraga
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i CheckFraga'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall kolla i spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall kolla i spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	SELECT @intRowcount = COUNT(*)
	FROM [spin-boviadm]..SIDORDNING	A
	WHERE A.BOLAGSNR = @chrBolagsnr
	AND A.PRODUKTKOD LIKE @chrProduktkod
	AND NOT EXISTS
	(
		SELECT *
		FROM [spin-bovi]..FRAGA	B
		WHERE B.FRAGENR = A.FRAGENR
	)
  END
ELSE
  BEGIN 
	SELECT @intRowcount = COUNT(*)
	FROM [spin-bovi]..SIDORDNING	A
	WHERE A.BOLAGSNR = @chrBolagsnr
	AND A.PRODUKTKOD LIKE @chrProduktkod
	AND NOT EXISTS
	(
		SELECT *
		FROM [spin-boviadm]..FRAGA	B
		WHERE B.FRAGENR = A.FRAGENR
	)
  END

-- Spara felkod
SELECT @Errcode = @@ERROR

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred checking the FRAGA table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The FRAGA table has been checked"
	PRINT "There was " + CONVERT(VARCHAR, @intRowcount) + " rows"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/****************************************************************************************************************************************************
Name:	CheckProdukt

Desc:	...

In:	Bolagsnummer
	Databas	- Den databas som kontrollen skall ske i

Out:	Antal rader	- Antalet funna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kontrollen

Author:	2001-06-25, B00SOL

Rev:
****************************************************************************************************************************************************/
CREATE PROCEDURE CheckProdukt
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i CheckProdukt'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall kolla i spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall kolla i spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	SELECT @intRowcount = COUNT(*)
	FROM [spin-boviadm]..BOLAGSPRODUKT	A
	WHERE A.BOLAGSNR = @chrBolagsnr
	AND A.PRODUKTKOD LIKE @chrProduktkod
	AND NOT EXISTS
	(
		SELECT *
		FROM [spin-bovi]..PRODUKT	B
		WHERE B.PRODUKTKOD = A.PRODUKTKOD
	)
  END
ELSE
  BEGIN
	SELECT @intRowcount = COUNT(*)
	FROM [spin-bovi]..BOLAGSPRODUKT	A
	WHERE A.BOLAGSNR = @chrBolagsnr
	AND A.PRODUKTKOD LIKE @chrProduktkod
	AND NOT EXISTS
	(
		SELECT *
		FROM [spin-boviadm]..PRODUKT	B
		WHERE B.PRODUKTKOD = A.PRODUKTKOD
	)
  END

-- Spara felkod
SELECT @Errcode = @@ERROR

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred checking the PRODUKT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The PRODUKT table has been checked"
	PRINT "There was " + CONVERT(VARCHAR, @intRowcount) + " rows"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/************************************************************************************************************************************
Name:	DeleteFromBolag

Desc:	Tar bort alla rader f�r ett bolag fr�n tabellen BOLAG i en angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromBolag
	@chrBolagsnr		CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromBolag'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	DELETE
	FROM [spin-bovi]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr

/*	SELECT *
	FROM [spin-bovi]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
*/
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr

/*	SELECT *
	FROM [spin-boviadm]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
*/
  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading from the BOLAG table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAG table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/***********************************************************************************************************************************************************
Name:	DeleteFromBolagprodukt

Desc:	Tar bort alla rader f�r en bolagsprodukt fr�n tabellen BOLAGSPRODUKT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
***********************************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromBolagsprodukt
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromBolagsprodukt'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	DELETE
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading from the BOLAGSPRODUKT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAGSPRODUKT table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*******************************************************************************************************************************************************
Name:	DeleteFromFragevillkor

Desc:	Tar bort alla rader f�r en bolagsprodukt fr�n tabellen FRAGEVILLKOR i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*******************************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromFragevillkor
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromFragevillkor'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	DELETE
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the FRAGEVILLKOR table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The FRAGEVILLKOR table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*************************************************************************************************************************************************************
Name:	DeleteFromHjalptext

Desc:	Tar bort alla rader f�r en bolagsprodukt fr�n tabellen HJALPTEXT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*************************************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromHjalptext
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'DeleteFromHjalptext'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	DELETE
	FROM [spin-bovi]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the HJALPTEXT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The HJALPTEXT table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/****************************************************************************************************************************************************
Name:	DeleteFromSidordning

Desc:	Tar bort alla rader f�r en bolagsprodukt fr�n tabellen SIDORDNING i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
****************************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromSidordning
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromSidordning'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	DELETE
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the SIDORDNING table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SIDORDNING table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*************************************************************************************************************************************************************
Name:	DeleteFromSvarsalternativ

Desc:	Tar bort alla rader f�r en bolagsprodukt fr�n tabellen SVARSALTERNATIV i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*************************************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromSvarsalternativ
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'DeleteFromSvarsalternativ'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	DELETE
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the SVARSALTERNATIV table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SVARSALTERNATIV table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

setuser N'LWAB\b00sol'
GO

/************************************************************************************************************************************
Name:	DeleteFromTermattribut

Desc:	Tar bort alla rader fr�n tabellen TERMATTRIBUT i en angiven databas, [spin-bovi] och [spin-boviadm].

In:	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet borttagna rader fr�n tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i borttaget

Author:	2001-06-26, B00SOL

Rev:
************************************************************************************************************************************/
CREATE PROCEDURE DeleteFromTermattribut
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromTermattribut'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall ta bort fr�n spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall ta bort fr�n spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*	DELETE
	FROM [spin-bovi]..TERMATTRIBUT
*/
	SELECT *
	FROM [spin-bovi]..TERMATTRIBUT
  END
ELSE
  BEGIN
/*	DELETE
	FROM [spin-boviadm]..TERMATTRIBUT
*/
	SELECT *
	FROM [spin-boviadm]..TERMATTRIBUT

  END

-- Spara felkod och antal borttagna poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading from the TERMATTRIBUT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The TERMATTRIBUT table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
setuser
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*************************************************************************************************************************************************
Name:	InsertIntoBolag

Desc:	L�gger till alla rader f�r ett bolag i tabellen BOLAG i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoBolag
	@chrBolagsnr		CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoBolag'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	INSERT
	INTO [spin-bovi]..BOLAG
	SELECT *
	FROM [spin-boviadm]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr

/*	SELECT *
	FROM [spin-bovi]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
*/
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..BOLAG
	SELECT *
	FROM [spin-bovi]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr

/*	SELECT *
	FROM [spin-boviadm]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the BOLAG table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAG table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/********************************************************************************************************************************************************
Name:	InsertIntoBolagsprodukt

Desc:	L�gger till alla rader f�r en bolagsprodukt i tabellen BOLAGSPRODUKT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoBolagsprodukt
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoBolagsprodukt'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	INSERT
	INTO [spin-bovi]..BOLAGSPRODUKT
	SELECT *
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..BOLAGSPRODUKT
	SELECT *
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the BOLAGSPRODUKT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAGSPRODUKT table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/********************************************************************************************************************************************************
Name:	InsertIntoFragevillkor

Desc:	L�gger till alla rader f�r en bolagsprodukt i tabellen FRAGEVILLKOR i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoFragevillkor
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoFragevillkor'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	INSERT
	INTO [spin-bovi]..FRAGEVILLKOR
	SELECT *
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..FRAGEVILLKOR
	SELECT *
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the FRAGEVILLKOR table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The FRAGEVILLKOR table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/**********************************************************************************************************************************************************
Name:	InsertIntoHjalptext

Desc:	L�gger till alla rader f�r en bolagsprodukt i tabellen HJALPTEXT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
**********************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoHjalptext
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoHjalptext'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	INSERT
	INTO [spin-bovi]..HJALPTEXT
	SELECT *
	FROM [spin-boviadm]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..HJALPTEXT
	SELECT *
	FROM [spin-bovi]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..HJALPTEXT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the HJALPTEXT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The HJALPTEXT table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/********************************************************************************************************************************************************
Name:	InsertIntoSidordning

Desc:	L�gger till alla rader f�r en bolagsprodukt i tabellen SIDORDNING i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoSidordning
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoSidordning'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	INSERT
	INTO [spin-bovi]..SIDORDNING
	SELECT *
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..SIDORDNING
	SELECT *
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the SIDORDNING table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SIDORDNING table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/**********************************************************************************************************************************************************
Name:	InsertIntoSvarsalternativ

Desc:	L�gger till alla rader f�r en bolagsprodukt i tabellen SVARSALTERNATIV i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
**********************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoSvarsalternativ
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoSvarsalternativ'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
	INSERT
	INTO [spin-bovi]..SVARSALTERNATIV
	SELECT *
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..SVARSALTERNATIV
	SELECT *
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD LIKE @chrProduktkod
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the SVARSALTERNATIV table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SVARSALTERNATIV table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

setuser N'LWAB\b00sol'
GO

/*************************************************************************************************************************************************
Name:	InsertIntoTermattribut

Desc:	L�gger till alla rader f�r ett bolag i tabellen BOLAG i angiven databas, [spin-bovi] och [spin-boviadm].

In:	Bolagsnummer
	Databas	- Den databas som borttaget skall ske i

Out:	Antal rader	- Antalet tillagda rader i tabellen

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*************************************************************************************************************************************************/
CREATE PROCEDURE InsertIntoTermattribut
	@chrBolagsnr		CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoTermattribut'

SET NOCOUNT ON

DECLARE @Returvarde INT
DECLARE @Errcode	INT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*	INSERT
	INTO [spin-bovi]..BOLAG
	SELECT *
	FROM [spin-boviadm]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
*/
	SELECT *
	FROM [spin-bovi]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..BOLAG
	SELECT *
	FROM [spin-bovi]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr

/*	SELECT *
	FROM [spin-boviadm]..BOLAG
	WHERE BOLAGSNR = @chrBolagsnr
*/
  END

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR, @intRowcount = @@ROWCOUNT

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the BOLAG table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAG table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
setuser
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*****************************************************************************************************************************
Name:	TransferBolag

Desc:	Kopierar ett helt bolags alla uppgifter mellan 2 databaser, [spin-bovi] och [spin-boviadm].
	Tabeller som kopieras �r:
	BOLAG
	BOLAGSPRODUKT
	SIDORDNING
	SVARSALTERNATIV
	FRAGEVILLKOR
	HJALPTEXT

In:	Bolagsnummer
	Databas	- Den databas som skall fyllas p� med v�rden fr�n den andra

Out:	-

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*****************************************************************************************************************************/
CREATE PROCEDURE TransferBolag
	@chrBolagsnr		CHAR(2) = '',
	@chrDatabas		CHAR(20) = ''
AS
PRINT 'Inne i TransferBolag'

SET NOCOUNT ON

-- Deklarationer
DECLARE @Returvarde		INT
DECLARE @NoOfRows		INT
DECLARE @OutMsg		VARCHAR(255)
DECLARE @TranName		VARCHAR(20)
DECLARE @chrProduktkod	CHAR(2)

-- S�tt @chrProduktkod till markering f�r att det g�ller alla produkter. 2 stycken wildcard eftersom det �r ett CHAR(2) f�lt
SET @chrProduktkod = '%%'

-- Kontrollera att man angivit en giltig databas att uppdatera
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- Kontrollera om det finns produkter i den ena databasen, men inte i den andra. Detta f�r att slippa f� fel i FOREIGN KEYS.
EXECUTE @Returvarde = CheckProdukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO EndOfProc
IF @NoOfRows > 0
  BEGIN
	PRINT "Det finns rader i BOLAGSPRODUKT som saknas i PRODUKT"
	SET @Returvarde = 97
	GOTO EndOfProc
  END

-- Kontrollera om det finns fr�gor i den ena databasen, men inte i den andra. Detta f�r att slippa f� fel i FOREIGN KEYS.
EXECUTE @Returvarde = CheckFraga @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO EndOfProc
IF @NoOfRows > 0
  BEGIN
	PRINT "Det finns rader i SIDORDNING som saknas i FRAGA"
	SET @Returvarde = 96
	GOTO EndOfProc
  END

-- Deklarera transaktion
SET @TranName = 'BOVITransferBolag'

-- Starta transaktion
BEGIN TRANSACTION @TranName

-- Kolla om bolaget redan finns.
IF @chrDatabas = 'spin-bovi'
  BEGIN
	IF EXISTS
		(
		SELECT *
		FROM	[spin-bovi]..BOLAG
		WHERE BOLAGSNR	= @chrBolagsnr
		)
	  BEGIN
		-- Bolaget finns G� till DELETE
		GOTO DeleteFromTables
	  END
	ELSE
	  BEGIN
		-- Bolaget saknas G� till INSERT
		GOTO InsertIntoTables
	  END
  END
ELSE
  BEGIN
	IF EXISTS
		(
		SELECT *
		FROM	[spin-boviadm]..BOLAG
		WHERE BOLAGSNR	= @chrBolagsnr
		)
	  BEGIN
		-- Bolaget finns G� till DELETE
		GOTO DeleteFromTables
	  END
	ELSE
	  BEGIN
		-- Bolaget saknas G� till INSERT
		GOTO InsertIntoTables
	  END
  END

-- DELETE
DeleteFromTables:
PRINT 'Inne i DeleteFromTables'
-- Ta bort allt ur FRAGEVILLKOR med nyckeln BOLAGSNR
EXECUTE @Returvarde = DeleteFromFragevillkor @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table FRAGEVILLKOR"
PRINT @OutMsg

-- Ta bort allt ur SVARSALTERNATIV med nyckeln BOLAGSNR
EXECUTE @Returvarde = DeleteFromSvarsalternativ @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table SVARSALTERNATIV"
PRINT @OutMsg

-- Ta bort allt ur SIDORDNING med nyckeln BOLAGSNR
EXECUTE @Returvarde = DeleteFromSidordning @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table SIDORDNING"
PRINT @OutMsg

-- Ta bort allt ur HJALPTEXT med nyckeln BOLAGSNR
EXECUTE @Returvarde = DeleteFromHjalptext @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table HJALPTEXT"
PRINT @OutMsg

-- Ta bort ur BOLAGSPRODUKT med nyckeln BOLAGSNR
EXECUTE @Returvarde = DeleteFromBolagsprodukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table BOLAGSPRODUKT"
PRINT @OutMsg

-- Ta bort ur BOLAG med nyckeln BOLAGSNR
EXECUTE @Returvarde = DeleteFromBolag @chrBolagsnr, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table BOLAG"
PRINT @OutMsg

-- INSERT
InsertIntoTables:
PRINT 'Inne i InsertIntoTables'
-- Skapa rad i BOLAG med nyckeln BOLAGSNR fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoBolag @chrBolagsnr, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table BOLAG"
PRINT @OutMsg

-- Skapa rad i BOLAGSPRODUKT med nyckeln BOLAGSNR fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoBolagsprodukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table BOLAGSPRODUKT"
PRINT @OutMsg

-- Skapa rader i FRAGEVILLKOR med nyckeln BOLAGSNR fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoFragevillkor @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table FRAGEVILLKOR"
PRINT @OutMsg

-- Skapa rader i SVARSALTERNATIV med nyckeln BOLAGSNR fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoSvarsalternativ @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table SVARSALTERNATIV"
PRINT @OutMsg

-- Skapa rader i SIDORDNING med nyckeln BOLAGSNR fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoSidordning @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table SIDORDNING"
PRINT @OutMsg

-- Skapa rader i HJALPTEXT med nyckeln BOLAGSNR fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoHjalptext @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table HJALPTEXT"
PRINT @OutMsg

-- Om allt OK G� till COMMIT
GOTO CommitTransaction

-- ROLLBACK
RollbackTransaction:
PRINT 'Inne i RollbackTransaction'
ROLLBACK TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc

-- COMMIT
CommitTransaction:
PRINT 'Inne i CommitTransaction'
COMMIT TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc

-- SLUT
EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*****************************************************************************************************************************
Name:	TransferBolagProdukt

Desc:	Kopierar en bolagsprodukts alla uppgifter mellan 2 databaser, [spin-bovi] och [spin-boviadm].
	Tabeller som kopieras �r:
	BOLAGSPRODUKT
	SIDORDNING
	SVARSALTERNATIV
	FRAGEVILLKOR
	HJALPTEXT

In:	Bolagsnummer
	Produktkod
	Databas	- Den databas som skall fyllas p� med v�rden fr�n den andra

Out:	-

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:
*****************************************************************************************************************************/
CREATE PROCEDURE TransferBolagProdukt
	@chrBolagsnr		CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = ''
AS
PRINT 'Inne i TransferBolagProdukt'

SET NOCOUNT ON

-- Bolag och produkt, databas IN
-- Deklarationer
DECLARE @Returvarde	INT
DECLARE @NoOfRows	INT
DECLARE @OutMsg	VARCHAR(255)
DECLARE @TranName	VARCHAR(30)

-- Kontrollera att man angivit en giltig databas att uppdatera
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- Kontrollera om det finns produkter i den ena databasen, men inte i den andra. Detta f�r att slippa f� fel i FOREIGN KEYS.
EXECUTE @Returvarde = CheckProdukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO EndOfProc
IF @NoOfRows > 0
  BEGIN
	PRINT "Det finns rader i BOLAGSPRODUKT som saknas i PRODUKT"
	SET @Returvarde = 97
	GOTO EndOfProc
  END

-- Kontrollera om det finns fr�gor i den ena databasen, men inte i den andra. Detta f�r att slippa f� fel i FOREIGN KEYS.
EXECUTE @Returvarde = CheckFraga @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO EndOfProc
IF @NoOfRows > 0
  BEGIN
	PRINT "Det finns rader i SIDORDNING som saknas i FRAGA"
	SET @Returvarde = 96
	GOTO EndOfProc
  END

-- Deklarera transaktion
SET @TranName = 'BOVITransferBolagProdukt'

-- STARTA transaktion
BEGIN TRANSACTION @TranName

-- Kolla om produkten redan finns.
IF @chrDatabas = 'spin-bovi'
  BEGIN
	IF EXISTS
		(
		SELECT *
		FROM	[spin-bovi]..BOLAGSPRODUKT
		WHERE BOLAGSNR	= @chrBolagsnr
		AND	PRODUKTKOD	= @chrProduktkod
		)
	  BEGIN
		-- Produkten finns G� till DELETE
		GOTO DeleteFromTables
	  END
	ELSE
	  BEGIN
		-- Produkten saknas G� till INSERT
		GOTO InsertIntoTables
	  END
  END
ELSE
  BEGIN
	IF EXISTS
		(
		SELECT *
		FROM	[spin-boviadm]..BOLAGSPRODUKT
		WHERE BOLAGSNR	= @chrBolagsnr
		AND	PRODUKTKOD	= @chrProduktkod
		)
	  BEGIN
		-- Produkten finns G� till DELETE
		GOTO DeleteFromTables
	  END
	ELSE
	  BEGIN
		-- Produkten saknas G� till INSERT
		GOTO InsertIntoTables
	  END
  END

-- DELETE
DeleteFromTables:
PRINT 'Inne i DeleteFromTables'
-- Ta bort allt ur FRAGEVILLKOR med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromFragevillkor @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table FRAGEVILLKOR"
PRINT @OutMsg
--
-- Ta bort allt ur SVARSALTERNATIV med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromSvarsalternativ @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table SVARSALTERNATIV"
PRINT @OutMsg
--
-- Ta bort allt ur SIDORDNING med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromSidordning @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table SIDORDNING"
PRINT @OutMsg
--
-- Ta bort allt ur HJALPTEXT med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromHjalptext @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table HJALPTEXT"
PRINT @OutMsg
--
-- Ta bort ur BOLAGSPRODUKT med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromBolagsprodukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table BOLAGSPRODUKT"
PRINT @OutMsg

-- INSERT
InsertIntoTables:
PRINT 'Inne i InsertIntoTables'
-- Skapa rad i BOLAGSPRODUKT med nycklarna BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoBolagsprodukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table BOLAGSPRODUKT"
PRINT @OutMsg
--
-- Skapa rader i FRAGEVILLKOR med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoFragevillkor @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table FRAGEVILLKOR"
PRINT @OutMsg
--
-- Skapa rader i SVARSALTERNATIV med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoSvarsalternativ @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table SVARSALTERNATIV"
PRINT @OutMsg
--
-- Skapa rader i SIDORDNING med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoSidordning @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table SIDORDNING"
PRINT @OutMsg
--
-- Skapa rader i HJALPTEXT med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoHjalptext @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table HJALPTEXT"
PRINT @OutMsg
--
-- Om allt OK G� till COMMIT
GOTO CommitTransaction
--
-- ROLLBACK
RollbackTransaction:
PRINT 'Inne i RollbackTransaction'
ROLLBACK TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc
--
-- COMMIT
CommitTransaction:
PRINT 'Inne i CommitTransaction'
COMMIT TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc

-- SLUT
EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

/*****************************************************************************************************************************
Name:	TransferGlobalTables

Desc:	Kopierar de 'globala' tabellerna mellan 2 databaser, [spin-bovi] och [spin-boviadm].
	Tabeller som kopieras �r:
	PRODUKT
	FRAGA
	TERMATTRIBUT
	HJALPTEXT

In:	Databas	- Den databas som skall fyllas p� med v�rden fr�n den andra

Out:	-

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-06-21, B00SOL

Rev:	2001-07-18, b00GRO

*****************************************************************************************************************************/
CREATE PROCEDURE TransferGlobalTables
	@chrDatabas		CHAR(20) = ''
AS

PRINT 'Inne i TransferGlobalTables....'

SET NOCOUNT ON

-- Deklarationer
DECLARE @Returvarde		INT
DECLARE @NoOfRows		INT
DECLARE @OutMsg		VARCHAR(255)
DECLARE @TranName		VARCHAR(20)
DECLARE @chrProduktkod	CHAR(2)

-- Kontrollera att man angivit en giltig databas att uppdatera
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- Deklarera transaktion
SET @TranName = 'BOVITransferGlobalTables'

-- Starta transaktion
BEGIN TRANSACTION @TranName

EXECUTE @Returvarde = TransferTableProdukt @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Transferred " + CONVERT(VARCHAR, @NoOfRows) + " rows from table PRODUKT"
PRINT @OutMsg

EXECUTE @Returvarde = TransferTableFraga @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Transferred " + CONVERT(VARCHAR, @NoOfRows) + " rows from table FRAGA"
PRINT @OutMsg

EXECUTE @Returvarde = TransferTableTermattribut @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Transferred " + CONVERT(VARCHAR, @NoOfRows) + " rows from table TERMATTRIBUT"
PRINT @OutMsg

EXECUTE @Returvarde = TransferTableHjalptext @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Transferred " + CONVERT(VARCHAR, @NoOfRows) + " rows from table HJALPTEXT"
PRINT @OutMsg

-- Om allt OK G� till COMMIT
GOTO CommitTransaction

-- ROLLBACK
RollbackTransaction:
PRINT 'Inne i RollbackTransaction'
ROLLBACK TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc

-- COMMIT
CommitTransaction:
PRINT 'Inne i CommitTransaction'
COMMIT TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc

-- SLUT
EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde













GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

setuser N'LWAB\b00gro'
GO

/********************************************************************************************************************************************************
Name:	TransferTableFraga

Desc:	L�gger till alla rader i tabellen FRAGA i angiven databas, [spin-bovi] och [spin-boviadm].

In:	chrDatabas	- Den databas som skall uppdateras

Out:	intRowcount	- Antalet rader som kopierats/lagts till

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-07-18, B00GRO

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE TransferTableFraga
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i TransferTableFraga'

SET NOCOUNT ON

DECLARE @Returvarde 	INT
DECLARE @Errcode	INT

/* Till cursorn: */
DECLARE @Fragenr 	SMALLINT
DECLARE @GUIKomponent	CHAR(1)
DECLARE	@Ledtext	VARCHAR(255)
DECLARE	@Beskrivning	VARCHAR(255)
DECLARE	@Hjalpknapp	BIT
DECLARE	@Nyckelord	VARCHAR(255)

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
    PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
    IF @chrDatabas = 'spin-boviadm'
      BEGIN
	PRINT "Skall flytta till spin-boviadm"
      END
    ELSE
      BEGIN
	PRINT "Error: No valid database"
	SET @Returvarde = 98
	GOTO EndOfProc
      END
  END

SELECT @intRowcount = 0

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
    DECLARE curFraga CURSOR FOR
    SELECT Fragenr,GUIKomponent,Ledtext,Beskrivning,Hjalpknapp,Nyckelord 
    FROM [Spin-Boviadm]..Fraga

    OPEN curFraga
    FETCH NEXT FROM curFraga
    INTO @Fragenr,@GUIKomponent,@Ledtext,@Beskrivning,@Hjalpknapp,@Nyckelord 

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Bovi]..Fraga WHERE Fragenr = @Fragenr)
        BEGIN
/*          UPDATE [Spin-Bovi]..Fraga
          SET GUIKomponent = @GUIKomponent, 
              Ledtext = @Ledtext,
              Beskrivning = @Beskrivning,
              Hjalpknapp = @Hjalpknapp,
              Nyckelord = @Nyckelord
          WHERE Fragenr = @Fragenr
*/
          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
/*          INSERT INTO [Spin-Bovi]..Fraga (Fragenr,GUIKomponent,Ledtext,Beskrivning,Hjalpknapp,Nyckelord)
          VALUES (@Fragenr,@GUIKomponent,@Ledtext,@Beskrivning,@Hjalpknapp,@Nyckelord)
*/
          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curFraga
      INTO @Fragenr,@GUIKomponent,@Ledtext,@Beskrivning,@Hjalpknapp,@Nyckelord 
    END

    CLOSE curFraga
    DEALLOCATE curFraga

  END
ELSE /* chrDatabas = 'Spin-Boviadm' */
  BEGIN
    DECLARE curFraga CURSOR FOR
    SELECT Fragenr,GUIKomponent,Ledtext,Beskrivning,Hjalpknapp,Nyckelord 
    FROM [Spin-Bovi]..Fraga

    OPEN curFraga
    FETCH NEXT FROM curFraga
    INTO @Fragenr,@GUIKomponent,@Ledtext,@Beskrivning,@Hjalpknapp,@Nyckelord 

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Boviadm]..Fraga WHERE Fragenr = @Fragenr)
        BEGIN
          UPDATE [Spin-Boviadm]..Fraga
          SET GUIKomponent = @GUIKomponent, 
              Ledtext = @Ledtext,
              Beskrivning = @Beskrivning,
              Hjalpknapp = @Hjalpknapp,
              Nyckelord = @Nyckelord
          WHERE Fragenr = @Fragenr

          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
          INSERT INTO [Spin-Boviadm]..Fraga (Fragenr,GUIKomponent,Ledtext,Beskrivning,Hjalpknapp,Nyckelord)
          VALUES (@Fragenr,@GUIKomponent,@Ledtext,@Beskrivning,@Hjalpknapp,@Nyckelord)

          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curFraga
      INTO @Fragenr,@GUIKomponent,@Ledtext,@Beskrivning,@Hjalpknapp,@Nyckelord 
    END

    CLOSE curFraga
    DEALLOCATE curFraga

  END /* chrDatabas */

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred transferring the FRAGA table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The FRAGA table has been transfered"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde






GO
setuser
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

setuser N'LWAB\b00gro'
GO

/********************************************************************************************************************************************************
Name:	TransferTableHjalptext

Desc:	L�gger till alla rader i tabellen HJALPTEXT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	chrDatabas	- Den databas som skall uppdateras

Out:	intRowcount	- Antalet rader som kopierats/lagts till

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-07-18, B00GRO

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE TransferTableHjalptext
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i TransferTableHjalptext'

SET NOCOUNT ON

DECLARE @Returvarde 	INT
DECLARE @Errcode	INT

/* Till cursorn: */
DECLARE @Fragenr 	SMALLINT
DECLARE @Bolagsnr	CHAR(2)
DECLARE @Produktkod	CHAR(2)
DECLARE	@Hjalptext	VARCHAR(5000)

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
    PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
    IF @chrDatabas = 'spin-boviadm'
      BEGIN
	PRINT "Skall flytta till spin-boviadm"
      END
    ELSE
      BEGIN
	PRINT "Error: No valid database"
	SET @Returvarde = 98
	GOTO EndOfProc
      END
  END

SELECT @intRowcount = 0

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
    DECLARE curHjalptext CURSOR FOR
    SELECT Fragenr, Bolagsnr, Produktkod, Hjalptext 
    FROM [Spin-Boviadm]..Hjalptext
    WHERE Bolagsnr LIKE '%*%' /* Vi flyttar bara de 'globala' hj�lptexterna h�r. */

    OPEN curHjalptext
    FETCH NEXT FROM curHjalptext
    INTO @Fragenr, @Bolagsnr, @Produktkod, @Hjalptext 

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Bovi]..Hjalptext
                 WHERE Fragenr = @Fragenr AND Bolagsnr = @Bolagsnr AND Produktkod = @Produktkod)
        BEGIN
/*          UPDATE [Spin-Bovi]..Hjalptext
          SET Hjalptext = @Hjalptext
          WHERE Fragenr = @Fragenr AND Bolagsnr = @Bolagsnr AND Produktkod = @Produktkod
*/
          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
/*          INSERT INTO [Spin-Bovi]..Hjalptext (Fragenr, Bolagsnr, Produktkod, Hjalptext)
          VALUES (@Fragenr, @Bolagsnr, @Produktkod, @Hjalptext)
*/
          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curHjalptext
      INTO @Fragenr, @Bolagsnr, @Produktkod, @Hjalptext 
    END

    CLOSE curHjalptext
    DEALLOCATE curHjalptext

  END
ELSE /* chrDatabas = 'Spin-Boviadm' */
  BEGIN
    DECLARE curHjalptext CURSOR FOR
    SELECT Fragenr, Bolagsnr, Produktkod, Hjalptext 
    FROM [Spin-Bovi]..Hjalptext
    WHERE Bolagsnr LIKE '%*%' /* Vi flyttar bara de 'globala' hj�lptexterna h�r. */

    OPEN curHjalptext
    FETCH NEXT FROM curHjalptext
    INTO @Fragenr, @Bolagsnr, @Produktkod, @Hjalptext 

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Boviadm]..Hjalptext
                 WHERE Fragenr = @Fragenr AND Bolagsnr = @Bolagsnr AND Produktkod = @Produktkod)
        BEGIN
          UPDATE [Spin-Boviadm]..Hjalptext
          SET Hjalptext = @Hjalptext
          WHERE Fragenr = @Fragenr AND Bolagsnr = @Bolagsnr AND Produktkod = @Produktkod

          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
          INSERT INTO [Spin-Boviadm]..Hjalptext (Fragenr, Bolagsnr, Produktkod, Hjalptext)
          VALUES (@Fragenr, @Bolagsnr, @Produktkod, @Hjalptext)

          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curHjalptext
      INTO @Fragenr, @Bolagsnr, @Produktkod, @Hjalptext 
    END

    CLOSE curHjalptext
    DEALLOCATE curHjalptext

  END /* chrDatabas */

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred transferring the HJALPTEXT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The HJALPTEXT table has been transfered"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde








GO
setuser
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

setuser N'LWAB\b00gro'
GO



/********************************************************************************************************************************************************
Name:	TransferTableProdukt

Desc:	L�gger till alla rader i tabellen PRODUKT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	chrDatabas	- Den databas som skall uppdateras

Out:	intRowcount	- Antalet rader som kopierats/lagts till

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-07-17, B00GRO

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE TransferTableProdukt
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i TransferTableProdukt'

SET NOCOUNT ON

DECLARE @Returvarde 	INT
DECLARE @Errcode	INT

/* Till cursorn: */
DECLARE @Produktkod 	CHAR(2)
DECLARE @Namn		VARCHAR(50)

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

SELECT @intRowcount = 0

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
    DECLARE curProdukt CURSOR FOR
    SELECT Produktkod,Namn FROM [Spin-Boviadm]..Produkt

    OPEN curProdukt
    FETCH NEXT FROM curProdukt
    INTO @Produktkod, @Namn

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Bovi]..Produkt WHERE Produktkod = @Produktkod)
        BEGIN
/*          UPDATE [Spin-Bovi]..Produkt
          SET Namn = @Namn
          WHERE Produktkod = @Produktkod
*/
          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
/*          INSERT INTO [Spin-Bovi]..Produkt (Produktkod, Namn)
          VALUES (@Produktkod, @Namn)
*/
          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curProdukt
      INTO @Produktkod, @Namn
    END

    CLOSE curProdukt
    DEALLOCATE curProdukt

  END
ELSE /* chrDatabas = 'Spin-Boviadm' */
  BEGIN
    DECLARE curProdukt CURSOR FOR
    SELECT Produktkod,Namn FROM [Spin-Bovi]..Produkt

    OPEN curProdukt
    FETCH NEXT FROM curProdukt
    INTO @Produktkod, @Namn

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Boviadm]..Produkt WHERE Produktkod = @Produktkod)
        BEGIN
          UPDATE [Spin-Boviadm]..Produkt
          SET Namn = @Namn
          WHERE Produktkod = @Produktkod

          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
          INSERT INTO [Spin-Boviadm]..Produkt (Produktkod, Namn)
          VALUES (@Produktkod, @Namn)

          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curProdukt
      INTO @Produktkod, @Namn
    END

    CLOSE curProdukt
    DEALLOCATE curProdukt

  END /* chrDatabas */

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred transferring the PRODUKT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The PRODUKT table has been transfered"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde




GO
setuser
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

setuser N'LWAB\b00gro'
GO

/********************************************************************************************************************************************************
Name:	TransferTableTermattribut

Desc:	L�gger till alla rader i tabellen TERMATTRIBUT i angiven databas, [spin-bovi] och [spin-boviadm].

In:	chrDatabas	- Den databas som skall uppdateras

Out:	intRowcount	- Antalet rader som kopierats/lagts till

Return:	0 - Allt gick bra
	98 - Ingen giltig databas vald
	99- Fel i kopieringen

Author:	2001-07-18, B00GRO

Rev:
********************************************************************************************************************************************************/
CREATE PROCEDURE TransferTableTermattribut
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i TransferTableTermattribut'

SET NOCOUNT ON

DECLARE @Returvarde 	INT
DECLARE @Errcode	INT

/* Till cursorn: */
DECLARE @Termnamn	CHAR(10)
DECLARE @Objektnamn	VARCHAR(50)
DECLARE @Attribut	VARCHAR(50)
DECLARE @Interface	VARCHAR(50)
DECLARE @Exemplarraknare	TINYINT

--
IF @chrDatabas = 'spin-bovi'
  BEGIN
    PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
    IF @chrDatabas = 'spin-boviadm'
      BEGIN
	PRINT "Skall flytta till spin-boviadm"
      END
    ELSE
      BEGIN
	PRINT "Error: No valid database"
	SET @Returvarde = 98
	GOTO EndOfProc
      END
  END

SELECT @intRowcount = 0

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
    DECLARE curTermattribut CURSOR FOR
    SELECT Termnamn,Objektnamn,Attribut,Interface,Exemplarraknare
    FROM [Spin-Boviadm]..Termattribut

    OPEN curTermattribut
    FETCH NEXT FROM curTermattribut
    INTO @Termnamn,@Objektnamn,@Attribut,@Interface,@Exemplarraknare 

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Bovi]..Termattribut WHERE Termnamn = @Termnamn)
        BEGIN
/*          UPDATE [Spin-Bovi]..Termattribut
          SET Termnamn = @Termnamn,
              Objektnamn = @Objektnamn,
              Attribut = @Attribut,
              Interface = @Interface,
              Exemplarraknare = @Exemplarraknare
          WHERE Termnamn = @Termnamn
*/
          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
/*          INSERT INTO [Spin-Bovi]..Termattribut (Termnamn,Objektnamn,Attribut,Interface,Exemplarraknare)
          VALUES (@Termnamn,@Objektnamn,@Attribut,@Interface,@Exemplarraknare)
*/
          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curTermattribut
      INTO @Termnamn,@Objektnamn,@Attribut,@Interface,@Exemplarraknare 
    END

    CLOSE curTermattribut
    DEALLOCATE curTermattribut

  END
ELSE /* chrDatabas = 'Spin-Boviadm' */
  BEGIN
    DECLARE curTermattribut CURSOR FOR
    SELECT Termnamn,Objektnamn,Attribut,Interface,Exemplarraknare
    FROM [Spin-Bovi]..Termattribut

    OPEN curTermattribut
    FETCH NEXT FROM curTermattribut
    INTO @Termnamn,@Objektnamn,@Attribut,@Interface,@Exemplarraknare 

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF EXISTS (SELECT * FROM [Spin-Boviadm]..Termattribut WHERE Termnamn = @Termnamn)
        BEGIN
          UPDATE [Spin-Boviadm]..Termattribut
          SET Termnamn = @Termnamn,
              Objektnamn = @Objektnamn,
              Attribut = @Attribut,
              Interface = @Interface,
              Exemplarraknare = @Exemplarraknare
          WHERE Termnamn = @Termnamn

          SELECT @intRowcount = @intRowcount + 1
        END
      ELSE
        BEGIN
          INSERT INTO [Spin-Boviadm]..Termattribut (Termnamn,Objektnamn,Attribut,Interface,Exemplarraknare)
          VALUES (@Termnamn,@Objektnamn,@Attribut,@Interface,@Exemplarraknare)

          SELECT @intRowcount = @intRowcount + 1
        END

      FETCH NEXT FROM curTermattribut
      INTO @Termnamn,@Objektnamn,@Attribut,@Interface,@Exemplarraknare 
    END

    CLOSE curTermattribut
    DEALLOCATE curTermattribut

  END /* chrDatabas */

-- Spara felkod och antal tillagda poster
SELECT @Errcode = @@ERROR

-- Kolla om n�got fel
IF @Errcode <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred transferring the TERMATTRIBUT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The TERMATTRIBUT table has been transfered"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde



GO
setuser
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

