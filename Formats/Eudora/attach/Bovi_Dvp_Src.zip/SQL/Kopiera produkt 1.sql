select * from svarsalternativ

insert into svarsalternativ (BOLAGSNR,PRODUKTKOD,FRAGENR,LOPNR,SVARSTEXT,
           EXTRATEXT,FALTLANGD,FALTTYP,GTE,LTE,RETURVARDE,TVANGSVARDE,TERMNAMN,
           LastUpdate,LastUser)

        select "77","B�",FRAGENR,LOPNR,SVARSTEXT,
           EXTRATEXT,FALTLANGD,FALTTYP,GTE,LTE,RETURVARDE,TVANGSVARDE,TERMNAMN,
            getdate(), "LWAB\b00gro"
        from svarsalternativ
        where bolagsnr = "43" and produktkod = "B�"

