select * from sidordning

insert into sidordning (BOLAGSNR,PRODUKTKOD,FRAGENR,SIDNR,ORDNINGSNR,
                        LastUpdate,LastUser)

	select "77", "B�",FRAGENR,SIDNR,ORDNINGSNR,getdate(), "LWAB\B00GRO"
	from sidordning
	where bolagsnr = "43" and produktkod = "B�"
