if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromBolagsprodukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromBolagsprodukt]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromFragevillkor]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromFragevillkor]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromSidordning]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromSidordning]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[DeleteFromSvarsalternativ]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[DeleteFromSvarsalternativ]
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE DeleteFromBolagsprodukt
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromBolagsprodukt'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	DELETE
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading from the BOLAGSPRODUKT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAGSPRODUKT table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE DeleteFromFragevillkor
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromFragevillkor'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*	DELETE
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the FRAGEVILLKOR table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The FRAGEVILLKOR table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE DeleteFromSidordning
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i DeleteFromSidordning'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	DELETE
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the SIDORDNING table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SIDORDNING table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE DeleteFromSvarsalternativ
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'DeleteFromSvarsalternativ'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	DELETE
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	DELETE
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred unloading the SVARSALTERNATIV table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SVARSALTERNATIV table has been unloaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

