if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoBolagsprodukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoBolagsprodukt]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoFragevillkor]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoFragevillkor]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoSidordning]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoSidordning]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[InsertIntoSvarsalternativ]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[InsertIntoSvarsalternativ]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[TransferBolagProdukt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[TransferBolagProdukt]
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE InsertIntoBolagsprodukt
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoBolagsprodukt'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	INSERT
	INTO [spin-bovi]..BOLAGSPRODUKT
	SELECT *
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..BOLAGSPRODUKT
	SELECT *
	FROM [spin-bovi]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..BOLAGSPRODUKT
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the BOLAGSPRODUKT table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The BOLAGSPRODUKT table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE InsertIntoFragevillkor
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoFragevillkor'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	INSERT
	INTO [spin-bovi]..FRAGEVILLKOR
	SELECT *
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..FRAGEVILLKOR
	SELECT *
	FROM [spin-bovi]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..FRAGEVILLKOR
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
--IF @@ERROR <> 1
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the FRAGEVILLKOR table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The FRAGEVILLKOR table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE InsertIntoSidordning
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoSidordning'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	INSERT
	INTO [spin-bovi]..SIDORDNING
	SELECT *
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..SIDORDNING
	SELECT *
	FROM [spin-bovi]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SIDORDNING
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the SIDORDNING table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SIDORDNING table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE InsertIntoSvarsalternativ
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = '',
	@intRowcount		INT OUT
AS
PRINT 'Inne i InsertIntoSvarsalternativ'

SET NOCOUNT ON

DECLARE @Returvarde INT
--
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END

-- G�r 2 olika sql:er beroende p� vilken databas som skall uppdateras
IF @chrDatabas = 'spin-bovi'
  BEGIN
/*
	INSERT
	INTO [spin-bovi]..SVARSALTERNATIV
	SELECT *
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SELECT *
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

	SET @intRowcount = @@ROWCOUNT
  END
ELSE
  BEGIN
	INSERT
	INTO [spin-boviadm]..SVARSALTERNATIV
	SELECT *
	FROM [spin-bovi]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod

/*	SELECT *
	FROM [spin-boviadm]..SVARSALTERNATIV
	WHERE BOLAGSNR = @chrBolagsnr
	AND PRODUKTKOD = @chrProduktkod
*/
	SET @intRowcount = @@ROWCOUNT
  END

--
IF @@ERROR <> 0
  BEGIN
	-- Return 99 to the calling program to indicate failure.
	PRINT "An error occurred loading the SVARSALTERNATIV table"
	SET @Returvarde = 99
	GOTO EndOfProc
  END
ELSE
  BEGIN
	-- Return 0 to the calling program to indicate success.
	PRINT "The SVARSALTERNATIV table has been loaded"
	SET @Returvarde = 0
	GOTO EndOfProc
  END

EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE TransferBolagProdukt
	@chrBolagsnr	CHAR(2) = '',
	@chrProduktkod	CHAR(2) = '',
	@chrDatabas		CHAR(20) = ''
AS
PRINT 'Inne i TransferBolagProdukt'

SET NOCOUNT ON

-- Bolag och produkt, databas IN
-- Deklarationer
DECLARE @Returvarde	INT
DECLARE @NoOfRows	INT
DECLARE @OutMsg	VARCHAR(255)

-- Kontrollera att man angivit en giltig databas att uppdatera
IF @chrDatabas = 'spin-bovi'
  BEGIN
	PRINT "Skall flytta till spin-bovi"
  END
ELSE
  BEGIN
	IF @chrDatabas = 'spin-boviadm'
	  BEGIN
		PRINT "Skall flytta till spin-boviadm"
	  END
	ELSE
	  BEGIN
		PRINT "Error: No valid database"
		SET @Returvarde = 98
		GOTO EndOfProc
	  END
  END
--
-- Deklarera transaktion
DECLARE @TranName VARCHAR(20)

SET @TranName = 'BOVITransaction'
--
-- STARTA transaktion
BEGIN TRANSACTION @TranName

-- Kolla om produkten redan finns.
IF @chrDatabas = 'spin-bovi'
  BEGIN
	IF EXISTS
		(
		SELECT *
		FROM	[spin-bovi]..BOLAGSPRODUKT
		WHERE BOLAGSNR	= @chrBolagsnr
		AND	PRODUKTKOD	= @chrProduktkod
		)
	  BEGIN
		-- Produkten finns G� till DELETE
		GOTO DeleteFromTables
	  END
	ELSE
	  BEGIN
		-- Produkten saknas G� till INSERT
		GOTO InsertIntoTables
	  END
  END
ELSE
  BEGIN
	IF EXISTS
		(
		SELECT *
		FROM	[spin-boviadm]..BOLAGSPRODUKT
		WHERE BOLAGSNR	= @chrBolagsnr
		AND	PRODUKTKOD	= @chrProduktkod
		)
	  BEGIN
		-- Produkten finns G� till DELETE
		GOTO DeleteFromTables
	  END
	ELSE
	  BEGIN
		-- Produkten saknas G� till INSERT
		GOTO InsertIntoTables
	  END
  END

-- DELETE
DeleteFromTables:
PRINT 'Inne i DeleteFromTables'
-- Ta bort allt ur FRAGEVILLKOR med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromFragevillkor @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table FRAGEVILLKOR"
PRINT @OutMsg
--
-- Ta bort allt ur SVARSALTERNATIV med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromSvarsalternativ @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table SVARSALTERNATIV"
PRINT @OutMsg
--
-- Ta bort allt ur SIDORDNING med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromSidordning @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table SIDORDNING"
PRINT @OutMsg
--
-- Ta bort ur BOLAGSPRODUKT med nycklarna BOLAGSNR coh PRODUKTKOD
EXECUTE @Returvarde = DeleteFromBolagsprodukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Deleted " + CONVERT(VARCHAR, @NoOfRows) + " rows from table BOLAGSPRODUKT"
PRINT @OutMsg

-- INSERT
InsertIntoTables:
PRINT 'Inne i InsertIntoTables'
-- Skapa rad i BOLAGSPRODUKT med nycklarna BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoBolagsprodukt @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table BOLAGSPRODUKT"
PRINT @OutMsg
--
-- Skapa rader i FRAGEVILLKOR med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoFragevillkor @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table FRAGEVILLKOR"
PRINT @OutMsg
--
-- Skapa rader i SVARSALTERNATIV med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoSvarsalternativ @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table SVARSALTERNATIV"
PRINT @OutMsg
--
-- Skapa rader i SIDORDNING med nycklaran BOLAGSNR och PRODUKTKOD fr�n den andra databasen
EXECUTE @Returvarde = InsertIntoSidordning @chrBolagsnr, @chrProduktkod, @chrDatabas, @NoOfRows OUT
IF @Returvarde <> 0 GOTO RollbackTransaction
SET @OutMsg = "Inserted " + CONVERT(VARCHAR, @NoOfRows) + " rows into table SIDORDNING"
PRINT @OutMsg
--
-- Om allt OK G� till COMMIT
GOTO CommitTransaction
--
-- ROLLBACK
RollbackTransaction:
PRINT 'Inne i RollbackTransaction'
ROLLBACK TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc
--
-- COMMIT
CommitTransaction:
PRINT 'Inne i CommitTransaction'
COMMIT TRANSACTION @TranName
-- G� till SLUT
GOTO EndOfProc

-- SLUT
EndOfProc:
SET NOCOUNT OFF
RETURN @Returvarde
GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

