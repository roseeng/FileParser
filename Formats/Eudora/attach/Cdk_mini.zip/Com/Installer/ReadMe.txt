This is the ReadMe.txt file that accompanies the 
self-extracting executable PalmCOMInstaller.exe.


Overview:
---------
The PalmCOMInstaller.exe is a self-extracting
executable to be used for the installation and
uninstallation of the Palm COM objects required
on the end user's machine.  This executable
installs the COM objects required by conduits
written using the PALM COM API.  The COM objects
will be installed on the target machine as an
application named "Palm Conduit Support for COM".

The intent of this executable is to facilate 
installation of the required COM objects for the 
developer so that the developer's installation 
program can be simplified.  The developer's conduit
installation program should invoke this
executable with the appropriate command line
options to install/uninstall the Palm COM
objects.

The developer is given permission to redistribute
the PalmCOMInstaller.exe as part of their conduit
distribution.


Command Line Parameters:
------------------------
The following command line parameters can be used:

/s -a /s	
	This set of parameters will suppress
	or silence all dialogs associated with
	the installation execution.

-a -uninstall
	This set of parameters will uninstall
	PalmCOMComponents from the user's system.

/s -a -uninstall /s
	This set of parameters will uninstall
	PalmCOMComponents from the user's system
	while suppressing or silencing all
	dialogs.

If no command line parameters are used, the default
action is to install (or reinstall) Palm COM objects
onto the user's system and show progress dialogs.


Uninstallation:
---------------
The DLLs installed as part of the Palm COM objects
are shared DLLs.  This implies that an application 
reference count is maintained for each DLL by the 
operating system. If an attempt to uninstall one of 
the DLLs occur, the DLL is only uninstalled if there 
are no further applications referencing it.  
This feature of Windows Operating Systems allows
the developer's conduit uninstaller to attempt
to safely attempt on uninstall the Palm COM objects 
without affecting other installed conduits.


