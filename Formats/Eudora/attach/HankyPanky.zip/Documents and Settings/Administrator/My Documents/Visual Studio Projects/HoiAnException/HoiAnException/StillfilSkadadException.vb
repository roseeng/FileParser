<Serializable()> Public Class StilfilSkadadException
    Inherits OOPERA.HoiAnException.HoiAnException

    Private Const DESCRIPTION As String = "Stilfil �r skadad."

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal Message As String)
        MyBase.New(Message)
    End Sub

    Public Sub New(ByVal Message As String, ByVal InnerException As System.Exception)
        MyBase.New(Message, InnerException)
    End Sub

    Protected Sub New(ByVal Info As System.Runtime.Serialization.SerializationInfo, ByVal Context As System.Runtime.Serialization.StreamingContext)
        MyBase.New(Info, Context)
    End Sub

    Public Sub New(ByVal InnerException As System.Exception)
        MyBase.New(DESCRIPTION, InnerException)
    End Sub

End Class
