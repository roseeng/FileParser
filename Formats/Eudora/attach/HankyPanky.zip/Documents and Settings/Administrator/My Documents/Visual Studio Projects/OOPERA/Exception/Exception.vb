<Serializable()> Public Class Exception
    Inherits System.ApplicationException

    Private Const DESCRIPTION As String = "Odefinierat systemfel."

    Private mstrAssemblyName As String
    Private mstrCallStack As String = Environment.StackTrace
    Private mintLine As Integer
    Private mstrMachine As String = Environment.MachineName
    Private mdatTime As DateTime = Now()
    Private mstrType As String = Me.GetType().FullName
    Private mstrUser As String = Environment.UserDomainName & "\" & Environment.UserName 'hmmm

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal Message As String)
        MyBase.New(Message)
    End Sub

    Public Sub New(ByVal Message As String, ByVal InnerException As System.Exception)
        MyBase.New(Message, InnerException)
    End Sub

    '---

    Protected Sub New(ByVal Info As System.Runtime.Serialization.SerializationInfo, ByVal Context As System.Runtime.Serialization.StreamingContext)
        MyBase.New(Info, Context)
    End Sub

    '---

    Public Sub New(ByVal InnerException As System.Exception)
        MyBase.New(DESCRIPTION, InnerException)
    End Sub

    '---

    Public Property Line() As Integer
        Get
            Line = mintLine
        End Get
        Set(ByVal Value As Integer)
            mintLine = Value
        End Set
    End Property

    Public ReadOnly Property Machine() As String
        Get
            Machine = mstrMachine
        End Get
    End Property

    Public ReadOnly Property Time() As DateTime
        Get
            Time = mdatTime
        End Get
    End Property

    Public ReadOnly Property Type() As String
        Get
            Type = mstrType
        End Get
    End Property

    Public ReadOnly Property User() As String
        Get
            User = mstrUser
        End Get
    End Property

    Public Property AssemblyName() As String
        Get
            AssemblyName = mstrAssemblyName
        End Get
        Set(ByVal Value As String)
            mstrAssemblyName = Value
        End Set
    End Property

End Class
