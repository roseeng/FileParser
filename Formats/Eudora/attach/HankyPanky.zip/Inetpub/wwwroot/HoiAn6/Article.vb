Imports System.Xml
Imports OOPERA.HoiAnException

Public Class Article

    Public Function Load(ByVal ArticleFile As String) As Table
        Dim objTable As New Table()
        Dim objControl As New Control()
        Dim objCell As New Cell()
        Dim objXMLDocument As New XmlDocument()
        Dim objElement As XmlElement
        Dim objTempTable As Table
        Dim intRowblocksPage As Integer
        Dim intColumnsPage As Integer
        Dim intCellblocksArticle As Integer
        Dim intRowblocksArticle As Integer
        Dim intColumnsArticle As Integer
        Dim intCellblocksCell As Integer
        Dim intColumnsCell As Integer
        Dim strStyle As String
        Dim intCurrentRow As Integer

        Try
            objTempTable = ContentTableRelated.SetTableProperties(objTable, ContentTableRelated.TableEnum.TABLEInnerContent)

            objXMLDocument.Load(ArticleFile)

            intColumnsPage = objXMLDocument.SelectSingleNode("/Article/PageLayout").Attributes.GetNamedItem("Columns").Value
            intRowblocksPage = objXMLDocument.SelectSingleNode("/Article/PageLayout").Attributes.GetNamedItem("Rowblocks").Value
            intColumnsArticle = objXMLDocument.SelectSingleNode("/Article/ArticleLayout").Attributes.GetNamedItem("Columns").Value
            intRowblocksArticle = objXMLDocument.SelectSingleNode("/Article/ArticleLayout").Attributes.GetNamedItem("Rowblocks").Value
            intCellblocksArticle = objXMLDocument.SelectSingleNode("/Article/ArticleLayout").Attributes.GetNamedItem("Cellblocks").Value

            objTempTable = TableRelated.AddTableRows(objTempTable, intCellblocksArticle)

            For Each objElement In objXMLDocument.SelectNodes("/Article/Cells/Cell")
                intCurrentRow = objElement.Attributes.GetNamedItem("StartRow").Value
                intCellblocksCell = objElement.Attributes.GetNamedItem("Cellblocks").Value
                intColumnsCell = objElement.Attributes.GetNamedItem("Columns").Value
                strStyle = objElement.Attributes.GetNamedItem("Style").Value

                objTempTable.Rows(intCurrentRow).Cells.Add(ContentTableRelated.AddArticleTableCell(intCellblocksCell, intRowblocksArticle, intColumnsCell, intCellblocksArticle, intRowblocksPage, intColumnsPage, IIf(strStyle = "", "", PROJECT_PATH & strStyle)))
                objCell.Load(objTempTable.Rows(intCurrentRow).Cells(objTempTable.Rows(intCurrentRow).Cells.Count - 1), objElement.OuterXml)
            Next

            objControl = Nothing
            objXMLDocument = Nothing

            Return objTempTable

        Catch objException As System.NullReferenceException
            Throw New ArtikelfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New ArtikelfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New ArtikelfilSaknasException(objException)

        Catch objException As System.OverflowException
            Throw New ArtikelfilSkadadException(objException)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

End Class
