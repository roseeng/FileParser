Imports System.Xml
Imports OOPERA.HoiAnException

Public Class Cell

    Public Function Load(ByVal TableCell As TableCell, ByVal CellXML As String) As TableCell
        Dim objTableCell As New TableCell()
        Dim objControl As New Control()
        Dim objXMLDocument As New XmlDocument()
        Dim objElement As XmlElement
        Dim strContent As String

        Try
            objTableCell = TableCell

            objXMLDocument.LoadXml(CellXML)

            For Each objElement In objXMLDocument.SelectNodes("/Cell/Contents/Content")
                strContent = objElement.Attributes.GetNamedItem("FileName").Value

                If strContent <> "" Then objTableCell.Controls.Add(objControl.Load(PROJECT_PATH & strContent))
            Next

            objControl = Nothing
            objXMLDocument = Nothing

            Return objTableCell

        Catch objException As System.NullReferenceException
            Throw New InnehallsfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New InnehallsfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New InnehallsfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

End Class
