Module Common

#Region "Constants"

    Public Const PROJECT_PATH As String = "C:\Inetpub\wwwroot\HoiAn6\"
    Public Const DATAFILES_FOLDER As String = "DataFiles\"

    Public Const TD_MENU_WIDTH As Integer = 106 ''110
    Public Const TD_MENU_HEIGHT As Integer = 20
    Public Const TD_SUBMENU_WIDTH As Integer = 106  ''110
    Public Const TD_SUBMENU_HEIGHT As Integer = 20
    'Public Const TD_HEADER_WIDTH As Integer = 100
    Public Const TD_HEADER_HEIGHT As Integer = 75
    Public Const TD_FOOTER_HEIGHT As Integer = 20
    Public Const TD_RULE_HEIGHT As Integer = 3
    'Public Const TABLE_MENU_TOP As Integer = 0
    'Public Const TABLE_SUBMENU_TOP As Integer = 20
    Public Const MENU_SEPARATOR_WIDTH As Integer = 1
    Public Const BODY_WIDTH As Integer = 776
    Public Const BODY_HEIGHT As Integer = 582

    Public Const TABLE_MENU_WIDTH As Integer = BODY_WIDTH
    Public Const TABLE_MENU_HEIGHT As Integer = TD_MENU_HEIGHT
    Public Const TABLE_SUBMENU_HEIGHT As Integer = TD_SUBMENU_HEIGHT
    Public Const TABLE_HEADER_WIDTH As Integer = BODY_WIDTH
    Public Const TABLE_HEADER_HEIGHT As Integer = TD_HEADER_HEIGHT + TD_RULE_HEIGHT
    Public Const TABLE_FOOTER_WIDTH As Integer = BODY_WIDTH
    Public Const TABLE_FOOTER_HEIGHT As Integer = TD_FOOTER_HEIGHT + TD_RULE_HEIGHT

    Public Const TD_MENUTRAIL_WIDTH As Integer = TABLE_MENU_WIDTH - (7 * TD_MENU_WIDTH + 2 * MENU_SEPARATOR_WIDTH)
    'Public Const TABLE_SUBMENU_STARTSIDA_WIDTH As Integer = 0 * TD_SUBMENU_WIDTH + (3 - 0) * MENU_SEPARATOR_WIDTH
    Public Const TABLE_SUBMENU_OMOSS_WIDTH As Integer = 3 * TD_SUBMENU_WIDTH + (3 - 0) * MENU_SEPARATOR_WIDTH
    Public Const TABLE_SUBMENU_SYSTEMUTVECKLING_WIDTH As Integer = 2 * TD_SUBMENU_WIDTH + (3 - 0) * MENU_SEPARATOR_WIDTH
    Public Const TABLE_SUBMENU_PRODUKTER_WIDTH As Integer = 2 * TD_SUBMENU_WIDTH + (3 - 1) * MENU_SEPARATOR_WIDTH
    Public Const TABLE_SUBMENU_UTBILDNING_WIDTH As Integer = 7 * TD_SUBMENU_WIDTH + (4 - 1) * MENU_SEPARATOR_WIDTH
    Public Const TABLE_SUBMENU_METODER_WIDTH As Integer = 3 * TD_SUBMENU_WIDTH + (3 - 1) * MENU_SEPARATOR_WIDTH
    Public Const TABLE_SUBMENU_KONTAKT_WIDTH As Integer = 3 * TD_SUBMENU_WIDTH + (3 - 1) * MENU_SEPARATOR_WIDTH

    Public Const CONTENT_TABLE_HEIGHT As Integer = BODY_HEIGHT - 180 '147
    Public Const CONTENT_TABLE_WIDTH As Integer = BODY_WIDTH - 26

#End Region

    Public Enum StyleEnum
        TABLEContent
        TABLEInnerContent
        TABLEFooter
        TABLEHeader
        TABLEMenu
        TABLESubMenuOmOss
        TABLESubMenuSystemUtveckling
        TABLESubMenuProdukter
        TABLESubMenuUtbildning
        TABLESubMenuMetoder
        TABLESubMenuKontakt

        TDPage
        TDContent
        TDHeader
        TDFooter
        TDMenu
        TDMenuHiLite
        TDMenuTrail
        TDSubMenuAttached
        TDSubMenuAttachedLeft
        TDSubMenuAttachedRight
        TDSubMenuNotAttached
        TDSubMenuNotAttachedLeft
        TDSubMenuNotAttachedRight
        TDSubMenuHiLite
        TDSubMenuHiLiteAttached
        TDSubMenuHiLiteAttachedLeft
        TDSubMenuHiLiteNotAttachedLeft
        TDSubMenuHiLiteAttachedRight
        TDSubMenuHiLiteNotAttachedRight
        TDRule

        HREFMenu
        HREFSubMenu
        HREFSubMenuHiLite
    End Enum

    Public Enum HTMLPropertyValueEnum
        HTMLPropertyValueBodyRows

        HTMLPropertyValueDefaultCols
        HTMLPropertyValueDefaultRows
        HTMLPropertyValueDefaultFrameBody
    End Enum

    Public Function GetHTMLPropertyValue(ByVal HTMLPropertyValue As HTMLPropertyValueEnum) As String
        Try
            Select Case HTMLPropertyValue
                Case HTMLPropertyValueEnum.HTMLPropertyValueBodyRows
                    Return TABLE_HEADER_HEIGHT + 0 & "," & TABLE_MENU_HEIGHT + TABLE_SUBMENU_HEIGHT + 0 & ",*," & TABLE_FOOTER_HEIGHT + 0

                Case HTMLPropertyValueEnum.HTMLPropertyValueDefaultCols
                    Return "*," & BODY_WIDTH & ",*"

                Case HTMLPropertyValueEnum.HTMLPropertyValueDefaultRows
                    Return "*," & BODY_HEIGHT & ",*"

                Case HTMLPropertyValueEnum.HTMLPropertyValueDefaultFrameBody
                    Return "Body.aspx?Content=0&Menu=1&SubMenu=1"

                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function CreateContentPage(ByVal Table As Table, ByVal ContentValue As Integer) As Table
        Dim objPageSet As New PageSet()
        Dim objTable As Table

        Try
            objTable = objPageSet.Load(Table, ContentValue)

            objPageSet = Nothing

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function CreateFooter(ByVal Table As Table) As Table
        Dim objTable As Table

        Try
            objTable = TableRelated.SetTableProperties(Table, TableRelated.TableEnum.TABLEFooter)

            With objTable
                .Rows.Add(TableRelated.AddTableRow())
                .Rows.Add(TableRelated.AddTableRow())

                .Rows(0).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDFooter_RC_0_0))
                .Rows(0).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDFooter_RC_0_1))

                .Rows(1).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDFooter_RC_1_0))
                .Rows(1).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDFooter_RC_1_1))

                .Rows(1).Cells(0).Controls.Add(LabelRelated.AddLabel(LabelRelated.LabelEnum.LABELFooter_RC_0_0))
            End With

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function CreateHeader(ByVal Table As Table) As Table
        Dim objTable As Table

        Try
            objTable = TableRelated.SetTableProperties(Table, TableRelated.TableEnum.TABLEHeader)

            With objTable
                .Rows.Add(TableRelated.AddTableRow())
                .Rows.Add(TableRelated.AddTableRow())

                .Rows(0).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDHeader_RC_0_0))
                .Rows(0).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDHeader_RC_0_1))
                .Rows(0).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDHeader_RC_0_2))

                .Rows(1).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDHeader_RC_1_0))
                .Rows(1).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDHeader_RC_1_1))
                .Rows(1).Cells.Add(TableRelated.AddTableCell(TableRelated.TableCellEnum.TDHeader_RC_1_2))

                .Rows(0).Cells(0).Controls.Add(ImageRelated.AddImage(ImageRelated.ImageTypeEnum.itOoperaWeblogo2))
                .Rows(0).Cells(1).Controls.Add(LabelRelated.AddLabel(LabelRelated.LabelEnum.LABELHeader_RC_0_1))
                .Rows(0).Cells(2).Controls.Add(ImageRelated.AddImage(ImageRelated.ImageTypeEnum.itMcp))
            End With

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function CreateMenu(ByVal Table As Table, ByVal MenuValue As Integer) As Table
        Dim objTable As Table 'egentligen vill jag ha en menuklass motsvarande content t�nket

        Try
            objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLEMenu)

            With objTable
                .Rows.Add(MenuTableRelated.AddTableRow())

                Select Case MenuValue
                    Case 1
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case 2
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case 3
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case 4
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case 5
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case 6
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case 7
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenuHiLite_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))

                    Case Else
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_0))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_1))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_2))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_3))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_4))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_5))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_6))
                        .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDMenu_RC_0_7))
                End Select

                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_0))
                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_1))
                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_2))
                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_3))
                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_4))
                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_5))
                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFMenu_RC_0_6))
            End With

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function CreateSubMenu(ByVal Table As Table, ByVal MenuValue As Integer, ByVal SubMenuValue As Integer) As Table
        Dim objTable As Table 'egentligen vill jag ha en menuklass motsvarande content t�nket

        Try
            Select Case MenuValue
                Case 1 'Startsida

                Case 2 'Om oss
                    objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLESubMenuOmOss)

                    With objTable
                        .Rows.Add(MenuTableRelated.AddTableRow())

                        Select Case SubMenuValue
                            Case 1
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteOmOss_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteOmOss_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_2))

                            Case 2
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteOmOss_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteOmOss_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_2))

                            Case 3
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteOmOss_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteOmOss_RC_0_2))

                            Case Else
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuOmOss_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuOmOss_RC_0_2))
                        End Select
                    End With

                Case 3 'Systemutveckling
                    objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLESubMenuSystemUtveckling)

                    With objTable
                        .Rows.Add(MenuTableRelated.AddTableRow())

                        Select Case SubMenuValue
                            Case 1
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteProdukter_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_1))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteProdukter_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuProdukter_RC_0_1))

                            Case 2
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteProdukter_RC_0_1))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteProdukter_RC_0_1))

                            Case Else
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_1))

                        End Select
                    End With

                Case 4 'Metod

                    objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLESubMenuMetoder)

                    With objTable
                        .Rows.Add(MenuTableRelated.AddTableRow())

                        Select Case SubMenuValue
                            Case 1
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteMetoder_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteMetoder_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_2))

                            Case 2
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteMetoder_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteMetoder_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_2))

                            Case 3
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteMetoder_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteMetoder_RC_0_2))

                            Case Else
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuMetoder_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuMetoder_RC_0_2))
                        End Select
                    End With


                Case 5 'Utbildning
                    objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLESubMenuUtbildning)

                    With objTable
                        .Rows.Add(MenuTableRelated.AddTableRow())

                        Select Case SubMenuValue
                            Case 1
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))

                            Case 2
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))

                            Case 3
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))

                            Case 4
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))

                            Case 5
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))

                            Case 6
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))

                            Case 7
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_6))

                            Case Else
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuUtbildning_RC_0_6))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2))
                                .Rows(0).Cells(3).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3))
                                .Rows(0).Cells(4).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4))
                                .Rows(0).Cells(5).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5))
                                .Rows(0).Cells(6).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6))
                        End Select
                    End With

                Case 6 'Produkter
                    objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLESubMenuProdukter)

                    With objTable
                        .Rows.Add(MenuTableRelated.AddTableRow())

                        Select Case SubMenuValue
                            Case 1
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteProdukter_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_1))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteProdukter_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuProdukter_RC_0_1))

                            Case 2
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteProdukter_RC_0_1))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteProdukter_RC_0_1))

                            Case Else
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuProdukter_RC_0_1))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuProdukter_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuProdukter_RC_0_1))
                        End Select
                    End With


                Case 7 'Kontakt
                    objTable = MenuTableRelated.SetTableProperties(Table, MenuTableRelated.TableEnum.TABLESubMenuKontakt)

                    With objTable
                        .Rows.Add(MenuTableRelated.AddTableRow())

                        Select Case SubMenuValue
                            Case 1
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteKontakt_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteKontakt_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_2))

                            Case 2
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteKontakt_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteKontakt_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_2))

                            Case 3
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuHiLiteKontakt_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuHiLiteKontakt_RC_0_2))

                            Case Else
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_0))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_1))
                                .Rows(0).Cells.Add(MenuTableRelated.AddTableCell(MenuTableRelated.TableCellEnum.TDSubMenuKontakt_RC_0_2))
                                .Rows(0).Cells(0).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_0))
                                .Rows(0).Cells(1).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_1))
                                .Rows(0).Cells(2).Controls.Add(HyperlinkRelated.AddHyperLink(HyperlinkRelated.HyperLinkEnum.HREFSubMenuKontakt_RC_0_2))
                        End Select
                    End With

                Case Else
            End Select

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try
    End Function

End Module
