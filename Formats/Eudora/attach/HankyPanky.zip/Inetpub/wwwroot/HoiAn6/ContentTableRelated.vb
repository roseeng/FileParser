Imports System.Xml
Imports OOPERA.HoiAnException

Module ContentTableRelated

    Public Enum TableEnum
        TABLEContent
        TABLEInnerContent
    End Enum

    Public Function AddTableRow() As TableRow
        Try
            Return New TableRow()

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function AddTableRows(ByVal Table As Table, ByVal NoOfRows As Integer) As Table
        Dim objTable As Table
        Dim i As Integer

        Try
            objTable = Table

            For i = 1 To NoOfRows
                objTable.Rows.Add(AddTableRow())
            Next 'i

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Public Function SetTableProperties(ByVal TableToSet As Table, ByVal Table As TableEnum) As Table
        Dim objTable As Table

        Try
            objTable = TableToSet

            Select Case Table
                Case TableEnum.TABLEContent
                    With objTable
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderStyle = BorderStyle.Solid
                        .BorderWidth = New Unit("1px")
                        .BorderColor = Color.White '.Red

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TableContent.opb")
                    End With

                Case TableEnum.TABLEInnerContent
                    With objTable
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderStyle = BorderStyle.Solid
                        .BorderWidth = New Unit("1px")
                        .BorderColor = Color.White '.Red

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TableInnerContent.opb")
                    End With

                Case Else
            End Select

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Public Function AddPageTableCell(ByVal Cellblocks As Integer, ByVal Columns As Integer, ByVal PageRowblocks As Integer, ByVal PageColumns As Integer, ByVal Style As String) As TableCell
        Try
            Return mobjCreateContentTableCell(Cellblocks, Columns, PageRowblocks, PageColumns, HorizontalAlign.Left, VerticalAlign.Top, Style)

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Public Function AddArticleTableCell(ByVal Cellblocks As Integer, ByVal Rowblocks As Integer, ByVal Columns As Integer, ByVal ArticleCellblocks As Integer, ByVal PageRowblocks As Integer, ByVal PageColumns As Integer, ByVal Style As String) As TableCell
        Try
            Return (mobjCreateInnerContentTableCell(Cellblocks, Rowblocks, Columns, ArticleCellblocks, PageRowblocks, PageColumns, HorizontalAlign.Left, VerticalAlign.Top, Style))

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateContentTableCell(ByVal intRowSpan As Integer, ByVal intColumnSpan As Integer, ByVal intPageRowblocks As Integer, ByVal intPageColumns As Integer, ByVal enmHAlign As HorizontalAlign, ByVal enmVAlign As VerticalAlign, ByVal strStyle As String) As TableCell
        Dim objTableCell As New TableCell()

        Try
            With objTableCell
                .Height = New Unit(CInt(CONTENT_TABLE_HEIGHT * (intRowSpan / intPageRowblocks)) & "px")
                .Width = New Unit(CInt(CONTENT_TABLE_WIDTH * (intColumnSpan / intPageColumns)) & "px")
                .RowSpan = intRowSpan
                .ColumnSpan = intColumnSpan
                .HorizontalAlign = enmHAlign
                .VerticalAlign = enmVAlign

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objTableCell

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateInnerContentTableCell(ByVal intCellblocks As Integer, ByVal intRowSpan As Integer, ByVal intColumnSpan As Integer, ByVal intArticleCellblocks As Integer, ByVal intPageRowblocks As Integer, ByVal intPageColumns As Integer, ByVal enmHAlign As HorizontalAlign, ByVal enmVAlign As VerticalAlign, ByVal strStyle As String) As TableCell
        Dim objTableCell As New TableCell()

        Try
            With objTableCell
                .Height = New Unit(CInt(CONTENT_TABLE_HEIGHT * (intRowSpan * intCellblocks) / (intPageRowblocks * intArticleCellblocks)) & "px")
                .Width = New Unit(CInt(CONTENT_TABLE_WIDTH * (intColumnSpan / intPageColumns)) & "px")
                .RowSpan = intCellblocks
                .ColumnSpan = intColumnSpan
                .HorizontalAlign = enmHAlign
                .VerticalAlign = enmVAlign

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objTableCell

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Sub mobjAddTDStyle(ByRef objStyleCollection As CssStyleCollection, ByVal strStyleFile As String)
        Dim objXMLDocument As New XmlDocument()
        Dim objTempElement As XmlElement
        Dim strType As String
        Dim strValue As String

        Try
            objXMLDocument.Load(strStyleFile)

            With objStyleCollection
                For Each objTempElement In objXMLDocument.SelectNodes("/Style/StyleRows/StyleRow")
                    strType = objTempElement.Attributes.GetNamedItem("Type").Value
                    strValue = objTempElement.Attributes.GetNamedItem("Value").Value

                    .Add(strType, strValue)
                Next 'objTempElement
            End With

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try

    End Sub

End Module
