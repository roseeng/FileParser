Imports System.Web.UI.WebControls
Imports System.Xml
Imports OOPERA.HoiAnException

Public Class Control

    Public Function Load(ByVal ControlFile As String) As System.Web.UI.Control
        Dim objControl As System.Web.UI.Control
        Dim objXMLDocument As New XmlDocument()
        Dim strHyperlinkText As String
        Dim strHyperlinkNavigateURL As String
        Dim strHyperlinkTarget As String
        Dim strHyperlinkImage As String
        Dim strHyperlinkType As String
        Dim strHyperlinkStyle As String
        Dim strImageHeight As String
        Dim strImageWidth As String
        Dim strImageImageURL As String
        Dim strImageStyle As String
        Dim strLabelText As String
        Dim strLabelStyle As String

        Try
            objXMLDocument.Load(ControlFile)

            Select Case objXMLDocument.DocumentElement.Attributes.GetNamedItem("Type").Value
                Case "Hyperlink"
                    strHyperlinkImage = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Image").Value
                    strHyperlinkTarget = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Target").Value
                    strHyperlinkText = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Text").Value
                    strHyperlinkType = objXMLDocument.DocumentElement.Attributes.GetNamedItem("LinkType").Value
                    strHyperlinkStyle = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Style").Value
                    strHyperlinkNavigateURL = objXMLDocument.DocumentElement.Attributes.GetNamedItem("URL").Value

                    If strHyperlinkType = "Image" Then
                        objControl = mobjCreateHyperLinkWithImage(PROJECT_PATH & strHyperlinkImage, strHyperlinkNavigateURL, strHyperlinkTarget, IIf(strHyperlinkStyle = "", "", PROJECT_PATH & strHyperlinkStyle))
                    ElseIf strHyperlinkType = "Text" Then
                        objControl = mobjCreateHyperLink(strHyperlinkText, strHyperlinkNavigateURL, strHyperlinkTarget, IIf(strHyperlinkStyle = "", "", PROJECT_PATH & strHyperlinkStyle))
                    End If
                Case "Image"
                    strImageHeight = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Height").Value
                    strImageWidth = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Width").Value
                    strImageImageURL = objXMLDocument.DocumentElement.Attributes.GetNamedItem("RelativePath").Value
                    strImageStyle = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Style").Value

                    objControl = mobjCreateImage(strImageHeight, strImageWidth, strImageImageURL, IIf(strImageStyle = "", "", PROJECT_PATH & strImageStyle))
                Case "Label"
                    strLabelText = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Text").Value
                    strLabelStyle = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Style").Value

                    objControl = mobjCreateLabel(strLabelText, IIf(strLabelStyle = "", "", PROJECT_PATH & strLabelStyle))
                Case Else
            End Select

            objXMLDocument = Nothing

            Return objControl

        Catch objException As System.NullReferenceException
            Throw New ObjektsfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New ObjektsfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Private Function mobjCreateLabel(ByVal strText As String, ByVal strStyle As String) As Label
        Dim objLabel As New Label()

        Try
            With objLabel
                .Text = strText

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objLabel

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateHyperLink(ByVal strText As String, ByVal strNavigateURL As String, ByVal strTarget As String, ByVal strStyle As String) As HyperLink
        Dim objHyperLink As New HyperLink()

        Try
            With objHyperLink
                .Text = strText
                .NavigateUrl = strNavigateURL
                .Target = strTarget

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objHyperLink

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateHyperLinkWithImage(ByVal strImage As String, ByVal strNavigateURL As String, ByVal strTarget As String, ByVal strStyle As String) As HyperLink
        Dim objControl As System.Web.UI.Control
        Dim objXMLDocument As New XmlDocument()
        Dim objElement As XmlElement
        Dim objHyperLink As New HyperLink()
        Dim strImageHeight As String
        Dim strImageWidth As String
        Dim strImageImageURL As String
        Dim strImageStyle As String

        Try
            objXMLDocument.Load(strImage)

            For Each objElement In objXMLDocument.SelectNodes("/Content")
                strImageHeight = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Height").Value
                strImageWidth = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Width").Value
                strImageImageURL = objXMLDocument.DocumentElement.Attributes.GetNamedItem("RelativePath").Value
                strImageStyle = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Style").Value
            Next

            objControl = mobjCreateImage(strImageHeight, strImageWidth, strImageImageURL, strImageStyle)

            With objHyperLink
                .Text = ""
                .NavigateUrl = strNavigateURL
                .Target = strTarget
                .Controls.Add(objControl)

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            objXMLDocument = Nothing

            Return objHyperLink

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateImage(ByVal intHeight As Integer, ByVal intWidth As Integer, ByVal strImageURL As String, ByVal strStyle As String) As Image
        Dim objImage As New Image()

        Try
            With objImage
                .Height = New Unit(intHeight & "px")
                .Width = New Unit(intWidth & "px")
                .ImageUrl = strImageURL

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objImage

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Sub mobjAddTDStyle(ByRef objStyleCollection As CssStyleCollection, ByVal strStyleFile As String)
        Dim objXMLDocument As New XmlDocument()
        Dim objTempElement As XmlElement
        Dim strType As String
        Dim strValue As String

        Try
            objXMLDocument.Load(strStyleFile)

            With objStyleCollection
                For Each objTempElement In objXMLDocument.SelectNodes("/Style/StyleRows/StyleRow")
                    strType = objTempElement.Attributes.GetNamedItem("Type").Value
                    strValue = objTempElement.Attributes.GetNamedItem("Value").Value

                    .Add(strType, strValue)
                Next 'objTempElement
            End With

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try

    End Sub

End Class
