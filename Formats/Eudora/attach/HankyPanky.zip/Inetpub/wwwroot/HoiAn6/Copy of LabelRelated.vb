Module LabelRelated

    Public Enum LabelEnum
        LABELFooter_RC_0_0
        LABELHeader_RC_0_1
    End Enum

    Public Function AddLabel(ByVal Label As LabelEnum) As Label
        Dim strTemp As String

        Select Case Label
            Case LabelEnum.LABELHeader_RC_0_1
                Return mobjCreateLabel("Vi utvecklar din systemutveckling")

            Case LabelEnum.LABELFooter_RC_0_0
                Return mobjCreateLabel("Copyright &copy; 1999-2002 OOPERA Konsult AB.")

            Case Else
        End Select
    End Function

    Private Function mobjCreateLabel(ByVal strText As String) As Label
        Dim objLabel As New Label()

        With objLabel
            .Text = strText
        End With

        Return objLabel
    End Function

End Module
