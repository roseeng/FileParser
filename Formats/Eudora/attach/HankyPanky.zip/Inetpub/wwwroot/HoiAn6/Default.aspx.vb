Public Class _Default
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "H�kans kod"

    Public Function Cols() As String
        Try
            Return Common.GetHTMLPropertyValue(Common.HTMLPropertyValueEnum.HTMLPropertyValueDefaultCols)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function Rows() As String
        Try
            Return Common.GetHTMLPropertyValue(Common.HTMLPropertyValueEnum.HTMLPropertyValueDefaultRows)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function SrcBody() As String
        Try
            Return Common.GetHTMLPropertyValue(Common.HTMLPropertyValueEnum.HTMLPropertyValueDefaultFrameBody)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Page_Error(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Error
        'HB
        Try
            Server.Transfer("ExceptionPage.aspx?Exception=" & Server.GetLastError().Message)

        Catch objException As System.Threading.ThreadAbortException
            'Vad kommer det h�r felet sig av

        Catch objException As Exception
            Server.Transfer("ExceptionPage.aspx?Exception=" & "Felet oidentifierat")

        End Try
        '/HB
    End Sub

End Class
