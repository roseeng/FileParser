Public Class Header
    Inherits System.Web.UI.Page
    Protected WithEvents HeaderTable As System.Web.UI.WebControls.Table

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "H�kans kod"

    Private Sub mCreateTable()
        Dim objTable As Table

        Try
            objTable = HeaderTable

            HeaderTable = Common.CreateHeader(objTable)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        'HB
        Try
            mCreateTable()

        Catch objException As Exception
            Throw objException

        End Try
        '/HB
    End Sub

    Private Sub Page_Error(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Error
        'HB
        Try
            Server.Transfer("ExceptionPage.aspx?Exception=" & Server.GetLastError().Message)

        Catch objException As System.Threading.ThreadAbortException
            'Vad kommer det h�r felet sig av

        Catch objException As Exception
            Server.Transfer("ExceptionPage.aspx?Exception=" & "Felet oidentifierat")

        End Try
        '/HB
    End Sub

End Class
