Imports System.Xml
Imports OOPERA.HoiAnException

Module HyperlinkRelated

    Public Enum PageEnum
        ctStartSidan
        ctOmOssF�retaget
        ctOmOssAff�rside
        ctOmOssTj�nster
        ctOmOssKunder
        ctOmOssJobb
        ctProdukterOOPERATid
        ctProdukterOOPUSOnLine
    End Enum

    Public Enum HyperLinkEnum
        HREFMenu_RC_0_0
        HREFMenu_RC_0_1
        HREFMenu_RC_0_2
        HREFMenu_RC_0_3
        HREFMenu_RC_0_4
        HREFMenu_RC_0_5
        HREFMenu_RC_0_6

        HREFSubMenuOmOss_RC_0_0
        HREFSubMenuOmOss_RC_0_1
        HREFSubMenuOmOss_RC_0_2
        HREFSubMenuOmOss_RC_0_3
        HREFSubMenuOmOss_RC_0_4

        HREFSubMenuProdukter_RC_0_0
        HREFSubMenuProdukter_RC_0_1

        HREFSubMenuUtbildning_RC_0_0
        HREFSubMenuUtbildning_RC_0_1
        HREFSubMenuUtbildning_RC_0_2
        HREFSubMenuUtbildning_RC_0_3
        HREFSubMenuUtbildning_RC_0_4
        HREFSubMenuUtbildning_RC_0_5
        HREFSubMenuUtbildning_RC_0_6

        HREFSubMenuMetoder_RC_0_0
        HREFSubMenuMetoder_RC_0_1
        HREFSubMenuMetoder_RC_0_2

        HREFSubMenuKontakt_RC_0_0
        HREFSubMenuKontakt_RC_0_1
        HREFSubMenuKontakt_RC_0_2

        HREFSubMenuHiLiteOmOss_RC_0_0
        HREFSubMenuHiLiteOmOss_RC_0_1
        HREFSubMenuHiLiteOmOss_RC_0_2
        HREFSubMenuHiLiteOmOss_RC_0_3
        HREFSubMenuHiLiteOmOss_RC_0_4

        HREFSubMenuHiLiteProdukter_RC_0_0
        HREFSubMenuHiLiteProdukter_RC_0_1

        HREFSubMenuHiLiteUtbildning_RC_0_0
        HREFSubMenuHiLiteUtbildning_RC_0_1
        HREFSubMenuHiLiteUtbildning_RC_0_2
        HREFSubMenuHiLiteUtbildning_RC_0_3
        HREFSubMenuHiLiteUtbildning_RC_0_4
        HREFSubMenuHiLiteUtbildning_RC_0_5
        HREFSubMenuHiLiteUtbildning_RC_0_6

        HREFSubMenuHiLiteMetoder_RC_0_0
        HREFSubMenuHiLiteMetoder_RC_0_1
        HREFSubMenuHiLiteMetoder_RC_0_2

        HREFSubMenuHiLiteKontakt_RC_0_0
        HREFSubMenuHiLiteKontakt_RC_0_1
        HREFSubMenuHiLiteKontakt_RC_0_2
    End Enum

    Public Function AddHyperLink(ByVal HyperLink As HyperLinkEnum) As HyperLink 'opb filer sedan
        Try
            Select Case HyperLink
                Case HyperLinkEnum.HREFMenu_RC_0_0
                    Return mobjCreateHyperLink("Startsida", "Body.aspx?Content=" & PageEnum.ctStartSidan & "&Menu=1&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFMenu_RC_0_1
                    Return mobjCreateHyperLink("Om oss", "Menu.aspx?Menu=2", "menu", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFMenu_RC_0_2
                    Return mobjCreateHyperLink("Systemutveckling", "Menu.aspx?Menu=3", "menu", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFMenu_RC_0_3
                    Return mobjCreateHyperLink("Metod", "Menu.aspx?Menu=4", "menu", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFMenu_RC_0_4
                    Return mobjCreateHyperLink("Utbildning", "Menu.aspx?Menu=5", "menu", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFMenu_RC_0_5
                    Return mobjCreateHyperLink("Produkter", "Menu.aspx?Menu=6", "menu", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFMenu_RC_0_6
                    Return mobjCreateHyperLink("Kontakt", "Menu.aspx?Menu=7", "menu", PROJECT_PATH & "DataFiles\Styles\S_HREFMenu.opb")

                Case HyperLinkEnum.HREFSubMenuKontakt_RC_0_0
                    Return mobjCreateHyperLink("Adress", "Body.aspx?Content=21&Menu=7&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuKontakt_RC_0_1
                    Return mobjCreateHyperLink("Karta", "Body.aspx?Content=22&Menu=7&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuKontakt_RC_0_2
                    Return mobjCreateHyperLink("Kontaktpersoner", "Body.aspx?Content=23&Menu=7&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuMetoder_RC_0_0
                    Return mobjCreateHyperLink("Unified Process", "Body.aspx?Content=9&Menu=4&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuMetoder_RC_0_1
                    Return mobjCreateHyperLink("Mentoring", "Body.aspx?Content=10&Menu=4&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuMetoder_RC_0_2
                    Return mobjCreateHyperLink("OOPUS", "Body.aspx?Content=11&Menu=4&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuOmOss_RC_0_0
                    Return mobjCreateHyperLink("F�retaget", "Body.aspx?Content=2&Menu=2&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuOmOss_RC_0_1
                    Return mobjCreateHyperLink("Kunder", "Body.aspx?Content=5&Menu=2&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuOmOss_RC_0_2
                    Return mobjCreateHyperLink("Jobb", "Body.aspx?Content=6&Menu=2&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuProdukter_RC_0_0
                    Return mobjCreateHyperLink("OOTid", "Body.aspx?Content=19&Menu=6&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuProdukter_RC_0_1
                    Return mobjCreateHyperLink("OOPUS OnLine", "Body.aspx?Content=20&Menu=6&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_0
                    Return mobjCreateHyperLink("�versikt", "Body.aspx?Content=12&Menu=5&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_1
                    Return mobjCreateHyperLink("SQL Server", "Body.aspx?Content=13&Menu=5&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_2
                    Return mobjCreateHyperLink("Unified Process", "Body.aspx?Content=14&Menu=5&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_3
                    Return mobjCreateHyperLink("Programspr�k", "Body.aspx?Content=15&Menu=5&SubMenu=4", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_4
                    Return mobjCreateHyperLink("Metoder", "Body.aspx?Content=16&Menu=5&SubMenu=5", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_5
                    Return mobjCreateHyperLink("Databasteori", "Body.aspx?Content=17&Menu=5&SubMenu=6", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuUtbildning_RC_0_6
                    Return mobjCreateHyperLink("Objektorientering", "Body.aspx?Content=18&Menu=5&SubMenu=7", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenu.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteKontakt_RC_0_0
                    Return mobjCreateHyperLink("Adress", "Body.aspx?Content=21&Menu=7&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteKontakt_RC_0_1
                    Return mobjCreateHyperLink("Karta", "Body.aspx?Content=22&Menu=7&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteKontakt_RC_0_2
                    Return mobjCreateHyperLink("Kontaktpersoner", "Body.aspx?Content=23&Menu=7&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteMetoder_RC_0_0
                    Return mobjCreateHyperLink("Unified Process", "Body.aspx?Content=9&Menu=4&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteMetoder_RC_0_1
                    Return mobjCreateHyperLink("Mentoring", "Body.aspx?Content=10&Menu=4&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteMetoder_RC_0_2
                    Return mobjCreateHyperLink("OOPUS", "Body.aspx?Content=11&Menu=4&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteOmOss_RC_0_0
                    Return mobjCreateHyperLink("F�retaget", "Body.aspx?Content=2&Menu=2&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteOmOss_RC_0_1
                    Return mobjCreateHyperLink("Kunder", "Body.aspx?Content=5&Menu=2&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteOmOss_RC_0_2
                    Return mobjCreateHyperLink("Jobb", "Body.aspx?Content=6&Menu=2&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteProdukter_RC_0_0
                    Return mobjCreateHyperLink("OOTid", "Body.aspx?Content=19&Menu=6&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteProdukter_RC_0_1
                    Return mobjCreateHyperLink("OOPUS OnLine", "Body.aspx?Content=20&Menu=6&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_0
                    Return mobjCreateHyperLink("�versikt", "Body.aspx?Content=12&Menu=5&SubMenu=1", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_1
                    Return mobjCreateHyperLink("SQL Server", "Body.aspx?Content=13&Menu=5&SubMenu=2", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_2
                    Return mobjCreateHyperLink("Unified Process", "Body.aspx?Content=14&Menu=5&SubMenu=3", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_3
                    Return mobjCreateHyperLink("Programspr�k", "Body.aspx?Content=15&Menu=5&SubMenu=4", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_4
                    Return mobjCreateHyperLink("Metoder", "Body.aspx?Content=16&Menu=5&SubMenu=5", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_5
                    Return mobjCreateHyperLink("Databasteori", "Body.aspx?Content=17&Menu=5&SubMenu=6", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case HyperLinkEnum.HREFSubMenuHiLiteUtbildning_RC_0_6
                    Return mobjCreateHyperLink("Objektorientering", "Body.aspx?Content=18&Menu=5&SubMenu=7", "body", PROJECT_PATH & "DataFiles\Styles\S_HREFSubMenuHiLite.opb")

                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateHyperLink(ByVal strText As String, ByVal strNavigateURL As String, ByVal strTarget As String, ByVal strStyle As String) As HyperLink
        Dim objHyperLink As New HyperLink()

        Try
            With objHyperLink
                .Text = strText
                .NavigateUrl = strNavigateURL
                .Target = strTarget

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objHyperLink

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Sub mobjAddTDStyle(ByRef objStyleCollection As CssStyleCollection, ByVal strStyleFile As String)
        Dim objXMLDocument As New XmlDocument()
        Dim objTempElement As XmlElement
        Dim strType As String
        Dim strValue As String

        Try
            objXMLDocument.Load(strStyleFile)

            With objStyleCollection
                For Each objTempElement In objXMLDocument.SelectNodes("/Style/StyleRows/StyleRow")
                    strType = objTempElement.Attributes.GetNamedItem("Type").Value
                    strValue = objTempElement.Attributes.GetNamedItem("Value").Value

                    .Add(strType, strValue)
                Next 'objTempElement
            End With

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try

    End Sub

End Module
