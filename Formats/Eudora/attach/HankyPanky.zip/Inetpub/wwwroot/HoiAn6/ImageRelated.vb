Imports System.Web.UI.WebControls
Imports System.Xml
Imports OOPERA.HoiAnException

Module ImageRelated

    Public Enum ImageTypeEnum
        itMcp
        itOoperaWeblogo2
    End Enum

    Public Function AddImage(ByVal Image As ImageTypeEnum) As Image
        Dim objXMLDocument As New XmlDocument()
        Dim objElement As XmlElement
        Dim intIndex As Integer

        Dim intWidth As Integer
        Dim intHeight As Integer
        Dim strRelativePath As String
        Dim strStyle As String

        Try
            Select Case Image
                Case ImageTypeEnum.itOoperaWeblogo2
                    objXMLDocument.Load(PROJECT_PATH & "DataFiles\Images\I_Oopera-WebLogo-2.opb")

                Case ImageTypeEnum.itMcp
                    objXMLDocument.Load(PROJECT_PATH & "DataFiles\Images\I_mcp.opb")

                Case Else
            End Select

            intHeight = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Height").Value
            intWidth = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Width").Value
            strRelativePath = objXMLDocument.DocumentElement.Attributes.GetNamedItem("RelativePath").Value
            strStyle = objXMLDocument.DocumentElement.Attributes.GetNamedItem("Style").Value

            objXMLDocument = Nothing

            Return mobjCreateImage(intHeight, intWidth, strRelativePath, IIf(strStyle = "", "", PROJECT_PATH & strStyle))

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateImage(ByVal intHeight As Integer, ByVal intWidth As Integer, ByVal strImageURL As String, ByVal strStyle As String) As Image
        Dim objImage As New Image()

        Try
            With objImage
                .Height = New Unit(intHeight & "px")
                .Width = New Unit(intWidth & "px")
                .ImageUrl = strImageURL

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objImage

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Sub mobjAddTDStyle(ByRef objStyleCollection As CssStyleCollection, ByVal strStyleFile As String)
        Dim objXMLDocument As New XmlDocument()
        Dim objTempElement As XmlElement
        Dim strType As String
        Dim strValue As String

        Try
            objXMLDocument.Load(strStyleFile)

            With objStyleCollection
                For Each objTempElement In objXMLDocument.SelectNodes("/Style/StyleRows/StyleRow")
                    strType = objTempElement.Attributes.GetNamedItem("Type").Value
                    strValue = objTempElement.Attributes.GetNamedItem("Value").Value

                    .Add(strType, strValue)
                Next 'objTempElement
            End With

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try

    End Sub

End Module
