Imports OOPERA.HoiAnException

Module LabelRelated

    Public Enum LabelEnum
        LABELFooter_RC_0_0
        LABELHeader_RC_0_1
    End Enum

    Public Function AddLabel(ByVal Label As LabelEnum) As Label
        Dim strTemp As String

        Try
            Select Case Label
                Case LabelEnum.LABELHeader_RC_0_1
                    Return mobjCreateLabel("Vi utvecklar din systemutveckling")

                Case LabelEnum.LABELFooter_RC_0_0
                    Return mobjCreateLabel("Copyright &copy; 2002 OOPERA Konsult AB.")

                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateLabel(ByVal strText As String) As Label
        Dim objLabel As New Label()

        Try
            With objLabel
                .Text = strText
            End With

            Return objLabel

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try

    End Function

End Module
