Imports System.Xml
Imports OOPERA.HoiAnException

Module MenuTableRelated

    Public Enum TableEnum
        TABLEMenu
        TABLESubMenuOmOss
        TABLESubMenuSystemUtveckling
        TABLESubMenuProdukter
        TABLESubMenuUtbildning
        TABLESubMenuMetoder
        TABLESubMenuKontakt
    End Enum

    Public Enum TableCellEnum
        TDMenu_RC_0_0
        TDMenu_RC_0_1
        TDMenu_RC_0_2
        TDMenu_RC_0_3
        TDMenu_RC_0_4
        TDMenu_RC_0_5
        TDMenu_RC_0_6
        TDMenu_RC_0_7 'trail

        TDMenuHiLite_RC_0_0
        TDMenuHiLite_RC_0_1
        TDMenuHiLite_RC_0_2
        TDMenuHiLite_RC_0_3
        TDMenuHiLite_RC_0_4
        TDMenuHiLite_RC_0_5
        TDMenuHiLite_RC_0_6

        TDSubMenuOmOss_RC_0_0
        TDSubMenuOmOss_RC_0_1
        TDSubMenuOmOss_RC_0_2
        TDSubMenuOmOss_RC_0_3
        TDSubMenuOmOss_RC_0_4

        TDSubMenuProdukter_RC_0_0
        TDSubMenuProdukter_RC_0_1

        TDSubMenuUtbildning_RC_0_0
        TDSubMenuUtbildning_RC_0_1
        TDSubMenuUtbildning_RC_0_2
        TDSubMenuUtbildning_RC_0_3
        TDSubMenuUtbildning_RC_0_4
        TDSubMenuUtbildning_RC_0_5
        TDSubMenuUtbildning_RC_0_6

        TDSubMenuMetoder_RC_0_0
        TDSubMenuMetoder_RC_0_1
        TDSubMenuMetoder_RC_0_2

        TDSubMenuKontakt_RC_0_0
        TDSubMenuKontakt_RC_0_1
        TDSubMenuKontakt_RC_0_2

        TDSubMenuHiLiteOmOss_RC_0_0
        TDSubMenuHiLiteOmOss_RC_0_1
        TDSubMenuHiLiteOmOss_RC_0_2
        TDSubMenuHiLiteOmOss_RC_0_3
        TDSubMenuHiLiteOmOss_RC_0_4

        TDSubMenuHiLiteProdukter_RC_0_0
        TDSubMenuHiLiteProdukter_RC_0_1

        TDSubMenuHiLiteUtbildning_RC_0_0
        TDSubMenuHiLiteUtbildning_RC_0_1
        TDSubMenuHiLiteUtbildning_RC_0_2
        TDSubMenuHiLiteUtbildning_RC_0_3
        TDSubMenuHiLiteUtbildning_RC_0_4
        TDSubMenuHiLiteUtbildning_RC_0_5
        TDSubMenuHiLiteUtbildning_RC_0_6

        TDSubMenuHiLiteMetoder_RC_0_0
        TDSubMenuHiLiteMetoder_RC_0_1
        TDSubMenuHiLiteMetoder_RC_0_2

        TDSubMenuHiLiteKontakt_RC_0_0
        TDSubMenuHiLiteKontakt_RC_0_1
        TDSubMenuHiLiteKontakt_RC_0_2
    End Enum

    Public Function AddTableRow() As TableRow
        Try
            Return New TableRow()

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Public Function AddTableRows(ByVal Table As Table, ByVal NoOfRows As Integer) As Table
        Dim objTable As Table
        Dim i As Integer

        Try
            objTable = Table

            For i = 1 To NoOfRows
                objTable.Rows.Add(AddTableRow())
            Next 'i

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Public Function SetTableProperties(ByVal TableToSet As Table, ByVal Table As TableEnum) As Table
        Dim objTable As Table

        Try
            objTable = TableToSet

            Select Case Table
                Case TableEnum.TABLEMenu
                    With objTable
                        .Height = New Unit(TABLE_MENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_MENU_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLEMenu.opb")
                    End With

                Case TableEnum.TABLESubMenuKontakt
                    With objTable
                        .Height = New Unit(TABLE_SUBMENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_SUBMENU_KONTAKT_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLESubMenuKontakt.opb")
                    End With

                Case TableEnum.TABLESubMenuMetoder
                    With objTable
                        .Height = New Unit(TABLE_SUBMENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_SUBMENU_METODER_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLESubMenuMetoder.opb")
                    End With

                Case TableEnum.TABLESubMenuOmOss
                    With objTable
                        .Height = New Unit(TABLE_SUBMENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_SUBMENU_OMOSS_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLESubMenuOmOss.opb")
                    End With

                Case TableEnum.TABLESubMenuProdukter
                    With objTable
                        .Height = New Unit(TABLE_SUBMENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_SUBMENU_PRODUKTER_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLESubMenuProdukter.opb")
                    End With

                Case TableEnum.TABLESubMenuSystemUtveckling
                    With objTable
                        .Height = New Unit(TABLE_SUBMENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_SUBMENU_SYSTEMUTVECKLING_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLESubMenuSystemutveckling.opb")
                    End With

                Case TableEnum.TABLESubMenuUtbildning
                    With objTable
                        .Height = New Unit(TABLE_SUBMENU_HEIGHT & "px")
                        .Width = New Unit(TABLE_SUBMENU_UTBILDNING_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLESubMenuUtbildning.opb")
                    End With

                Case Else
            End Select

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Public Function AddTableCell(ByVal TableCell As TableCellEnum) As TableCell
        Try
            Select Case TableCell
                Case TableCellEnum.TDMenu_RC_0_0
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_1
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_2
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_3
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_4
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_5
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_6
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenu.opb")

                Case TableCellEnum.TDMenu_RC_0_7
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENUTRAIL_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuTrail.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_0
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_1
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_2
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_3
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_4
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_5
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDMenuHiLite_RC_0_6
                    Return mobjCreateTableCell(TD_MENU_HEIGHT, TD_MENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuKontakt_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuKontakt_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH - MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuKontakt_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuAttachedRight.opb")

                Case TableCellEnum.TDSubMenuMetoder_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuMetoder_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH - MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuMetoder_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuOmOss_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuOmOss_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuOmOss_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuProdukter_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuProdukter_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_3
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH - MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_4
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + 2 * MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuAttached.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_5
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttached.opb")

                Case TableCellEnum.TDSubMenuUtbildning_RC_0_6
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuHiLiteKontakt_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuNotAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuHiLiteKontakt_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH - MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteKontakt_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteAttachedRight.opb")

                Case TableCellEnum.TDSubMenuHiLiteMetoder_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuHiLiteMetoder_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH - MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteMetoder_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuHiLiteOmOss_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuHiLiteOmOss_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteOmOss_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuHiLiteProdukter_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuHiLiteProdukter_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteNotAttachedRight.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_0
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteNotAttachedLeft.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_1
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_2
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_3
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH - MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_4
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH + 2 * MENU_SEPARATOR_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteAttached.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_5
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLite.opb")

                Case TableCellEnum.TDSubMenuHiLiteUtbildning_RC_0_6
                    Return mobjCreateTableCell(TD_SUBMENU_HEIGHT, TD_SUBMENU_WIDTH, HorizontalAlign.Center, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDSubMenuHiLiteNotAttachedRight.opb")
                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Function mobjCreateTableCell(ByVal intHeight As Integer, ByVal intWidth As Integer, ByVal enmHAlign As HorizontalAlign, ByVal enmVAlign As VerticalAlign, ByVal strStyle As String) As TableCell
        Dim objTableCell As New TableCell()

        Try
            With objTableCell
                .Height = New Unit(intHeight & "px")
                .Width = New Unit(intWidth & "px")
                .HorizontalAlign = enmHAlign
                .VerticalAlign = enmVAlign

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objTableCell

        Catch objException As Exception
            Throw objException

        End Try

    End Function

    Private Sub mobjAddTDStyle(ByRef objStyleCollection As CssStyleCollection, ByVal strStyleFile As String)
        Dim objXMLDocument As New XmlDocument()
        Dim objTempElement As XmlElement
        Dim strType As String
        Dim strValue As String

        Try
            objXMLDocument.Load(strStyleFile)

            With objStyleCollection
                For Each objTempElement In objXMLDocument.SelectNodes("/Style/StyleRows/StyleRow")
                    strType = objTempElement.Attributes.GetNamedItem("Type").Value
                    strValue = objTempElement.Attributes.GetNamedItem("Value").Value

                    .Add(strType, strValue)
                Next 'objTempElement
            End With

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try

    End Sub

End Module
