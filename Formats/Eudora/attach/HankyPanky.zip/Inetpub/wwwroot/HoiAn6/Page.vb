Imports System.Xml
Imports OOPERA.HoiAnException

Public Class Page

    Public Function Load(ByVal Table As Table, ByVal PageFile As String) As Table
        Dim objArticle As New Article()
        Dim objXMLDocument As New XmlDocument()
        Dim objTempTable As Table
        Dim objTempElement As XmlElement
        Dim intPageRowblocks As Integer
        Dim intPageColumns As Integer
        Dim intArticleCellblocks As Integer
        Dim intArticleColumns As Integer
        Dim strArticle As String
        Dim strStyle As String
        Dim intCurrentRow As Integer

        Try
            objTempTable = ContentTableRelated.SetTableProperties(Table, ContentTableRelated.TableEnum.TABLEContent)

            objXMLDocument.Load(PageFile)

            intPageColumns = objXMLDocument.SelectSingleNode("/Page/PageLayout").Attributes.GetNamedItem("Columns").Value
            intPageRowblocks = objXMLDocument.SelectSingleNode("/Page/PageLayout").Attributes.GetNamedItem("Rowblocks").Value

            objTempTable = TableRelated.AddTableRows(objTempTable, intPageRowblocks)

            For Each objTempElement In objXMLDocument.SelectNodes("/Page/Cells/Cell")
                intCurrentRow = objTempElement.Attributes.GetNamedItem("StartRow").Value
                intArticleCellblocks = objTempElement.Attributes.GetNamedItem("Rowblocks").Value
                intArticleColumns = objTempElement.Attributes.GetNamedItem("Columns").Value
                strArticle = objTempElement.Attributes.GetNamedItem("Article").Value
                strStyle = objTempElement.Attributes.GetNamedItem("Style").Value

                objTempTable.Rows(intCurrentRow).Cells.Add(ContentTableRelated.AddPageTableCell(intArticleCellblocks, intArticleColumns, intPageRowblocks, intPageColumns, IIf(strStyle = "", "", PROJECT_PATH & strStyle)))
                If strArticle <> "" Then objTempTable.Rows(intCurrentRow).Cells(objTempTable.Rows(intCurrentRow).Cells.Count - 1).Controls.Add(objArticle.Load(IIf(strArticle = "", "", PROJECT_PATH & strArticle)))
            Next

            objArticle = Nothing
            objXMLDocument = Nothing

            Return objTempTable

        Catch objException As System.NullReferenceException
            Throw New SidfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New SidfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New SidfilSaknasException(objException)

        Catch objException As System.OverflowException
            Throw New SidfilSkadadException(objException)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

End Class
