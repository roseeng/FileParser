Imports System.Xml
Imports OOPERA.HoiAnException

Public Class PageSet

    Public Function Load(ByVal Table As Table, ByVal PageFileID As Integer) As Table
        Dim objPage As New Page()
        Dim objXMLDocument As New XmlDocument()
        Dim objElement As XmlElement
        Dim strPage As String

        Try
            objXMLDocument.Load(PROJECT_PATH & DATAFILES_FOLDER & "PageSet.opb")

            objElement = objXMLDocument.SelectSingleNode("/PageSet/Page[@ID=" & PageFileID & "]")

            If Not objElement Is Nothing Then strPage = objElement.Attributes.GetNamedItem("FileName").Value

            objElement = Nothing
            objXMLDocument = Nothing

            Return objPage.Load(Table, PROJECT_PATH & "\" & strPage)

        Catch objException As System.NullReferenceException
            Throw New SidgruppsfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New SidgruppsfilSaknasException(objException)

        Catch objException As System.IO.DirectoryNotFoundException
            Throw New SidgruppsfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try
    End Function

End Class
