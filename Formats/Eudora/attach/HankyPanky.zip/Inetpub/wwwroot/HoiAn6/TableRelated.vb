Imports System.Xml
Imports OOPERA.HoiAnException

Module TableRelated

    Public Enum TableEnum
        TABLEFooter
        TABLEHeader
    End Enum

    Public Enum TableCellEnum
        TDFooter_RC_0_0
        TDFooter_RC_0_1
        TDFooter_RC_1_0
        TDFooter_RC_1_1

        TDHeader_RC_0_0
        TDHeader_RC_0_1
        TDHeader_RC_0_2
        TDHeader_RC_1_0
        TDHeader_RC_1_1
        TDHeader_RC_1_2
    End Enum

    Public Function AddTableRow() As TableRow
        Try
            Return New TableRow()

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function AddTableRows(ByVal Table As Table, ByVal NoOfRows As Integer) As Table
        Dim objTable As Table
        Dim i As Integer

        Try
            objTable = Table

            For i = 1 To NoOfRows
                objTable.Rows.Add(AddTableRow())
            Next 'i

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function SetTableProperties(ByVal TableToSet As Table, ByVal Table As TableEnum) As Table
        Dim objTable As Table

        Try
            objTable = TableToSet

            Select Case Table
                Case TableEnum.TABLEFooter
                    With objTable
                        .Height = New Unit(TABLE_FOOTER_HEIGHT & "px")
                        .Width = New Unit(TABLE_FOOTER_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("1px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLEFooter.opb")
                    End With

                Case TableEnum.TABLEHeader
                    With objTable
                        .Height = New Unit(TABLE_HEADER_HEIGHT & "px")
                        .Width = New Unit(TABLE_HEADER_WIDTH & "px")
                        .CellPadding = "0"
                        .CellSpacing = "0"
                        .BorderWidth = New Unit("0px")

                        mobjAddTDStyle(.Style, PROJECT_PATH & "DataFiles\Styles\S_TABLEHeader.opb")
                    End With

                Case Else
            End Select

            Return objTable

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Function AddTableCell(ByVal TableCell As TableCellEnum) As TableCell
        Try
            Select Case TableCell

                Case TableCellEnum.TDHeader_RC_0_0
                    Return mobjCreateTableCell(TD_HEADER_HEIGHT, 300, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDHeader.opb")

                Case TableCellEnum.TDHeader_RC_0_1
                    Return mobjCreateTableCell(TD_HEADER_HEIGHT, 300, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDHeader.opb")

                Case TableCellEnum.TDHeader_RC_0_2
                    Return mobjCreateTableCell(TD_HEADER_HEIGHT, 200, HorizontalAlign.Right, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDHeader.opb")

                Case TableCellEnum.TDHeader_RC_1_0
                    Return mobjCreateTableCell(TD_RULE_HEIGHT, 300, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDRule.opb")

                Case TableCellEnum.TDHeader_RC_1_1
                    Return mobjCreateTableCell(TD_RULE_HEIGHT, 300, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDRule.opb")

                Case TableCellEnum.TDHeader_RC_1_2
                    Return mobjCreateTableCell(TD_RULE_HEIGHT, 200, HorizontalAlign.Right, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDRule.opb")

                Case TableCellEnum.TDFooter_RC_0_0
                    Return mobjCreateTableCell(TD_RULE_HEIGHT, 300, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDRule.opb")

                Case TableCellEnum.TDFooter_RC_0_1
                    Return mobjCreateTableCell(TD_RULE_HEIGHT, 500, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDRule.opb")

                Case TableCellEnum.TDFooter_RC_1_0
                    Return mobjCreateTableCell(TD_FOOTER_HEIGHT, 300, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDFooter.opb")

                Case TableCellEnum.TDFooter_RC_1_1
                    Return mobjCreateTableCell(TD_FOOTER_HEIGHT, 500, HorizontalAlign.Left, VerticalAlign.Middle, PROJECT_PATH & "DataFiles\Styles\S_TDFooter.opb")

                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Private Function mobjCreateTableCell(ByVal intHeight As Integer, ByVal intWidth As Integer, ByVal enmHAlign As HorizontalAlign, ByVal enmVAlign As VerticalAlign, ByVal strStyle As String) As TableCell
        Dim objTableCell As New TableCell()

        Try
            With objTableCell
                .Height = New Unit(intHeight & "px")
                .Width = New Unit(intWidth & "px")
                .HorizontalAlign = enmHAlign
                .VerticalAlign = enmVAlign

                If strStyle <> "" Then mobjAddTDStyle(.Style, strStyle)
            End With

            Return objTableCell

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Private Sub mobjAddTDStyle(ByRef objStyleCollection As CssStyleCollection, ByVal strStyleFile As String)
        Dim objXMLDocument As New XmlDocument()
        Dim objTempElement As XmlElement
        Dim strType As String
        Dim strValue As String

        Try
            objXMLDocument.Load(strStyleFile)

            With objStyleCollection
                For Each objTempElement In objXMLDocument.SelectNodes("/Style/StyleRows/StyleRow")
                    strType = objTempElement.Attributes.GetNamedItem("Type").Value
                    strValue = objTempElement.Attributes.GetNamedItem("Value").Value

                    .Add(strType, strValue)
                Next 'objTempElement
            End With

        Catch objException As System.NullReferenceException
            Throw New StilfilSkadadException(objException)

        Catch objException As System.IO.FileNotFoundException
            Throw New StilfilSaknasException(objException)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

End Module
