/*
    salami - icq log analyzer
    Copyright (C) 2000 Nicklas Lindgren <nicli380@student.liu.se>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "salami.h"
#include "mirabilis.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

FILE *g_datfile;
FILE *g_idxfile;
long g_dbversion;

idxentry_t *g_idxlist;
long g_idxcount;

/****************************************************/
bool
openfiles(const char *filenamestub) 
{
  char *datfilename;
  char *idxfilename;

  datfilename = (char *)malloc(strlen(filenamestub)+5);
  if (datfilename == NULL) {
    outofmemory();
    return false;
  }
  idxfilename = (char *)malloc(strlen(filenamestub)+5);
  if (idxfilename == NULL) {
    outofmemory();
    free(datfilename);
    return false;
  }
  
  strcpy(datfilename, filenamestub);
  strcat(datfilename, ".dat");
  strcpy(idxfilename, filenamestub);
  strcat(idxfilename, ".idx");
  
  g_datfile = NULL;
  g_idxfile = NULL;

  g_datfile = fopen(datfilename, "rb");
  if (g_datfile == NULL) {
    fprintf(stderr, "Kunde inte �ppna %s!\n", datfilename);
    free(datfilename);
    free(idxfilename);
    return false;
  }

  g_idxfile = fopen(idxfilename, "rb");
  if (g_idxfile == NULL) {
    fprintf(stderr, "Kunde inte �ppna %s!\n", idxfilename);
    free(datfilename);
    free(idxfilename);
    return false;
  }
  
  free(datfilename);
  free(idxfilename);
  return true;
}

bool
closefiles() 
{
  if (g_datfile != NULL) {
    fclose(g_datfile);
  }
  if (g_idxfile != NULL) {
    fclose(g_idxfile);
  }
  return true;
}

bool
create_idxlist()
{
  char buffer0[IDXHEADERSIZE];
  long filepointer;
  idxentry_t *listpointer;
  idxentry_t *element;
  
  element = (idxentry_t *)malloc(sizeof(idxentry_t));
  if (element == NULL) {
    outofmemory();
    return false;
  }
  
  element->next = NULL;
  
  g_idxlist = element;
  g_idxcount = 0;
  listpointer = g_idxlist;
  
  fread((char *)&buffer0, IDXHEADERSIZE, 1, g_idxfile);
  g_dbversion = *((long *)&buffer0[0x10]);

  if (g_verbose) {
    fprintf(stderr, "Databasversion %ld - ", g_dbversion);
    switch (g_dbversion) {
    case VERSION_NEWDB:
      fprintf(stderr, "NewDB (99a)");
      break;
    case VERSION_DB99B:
      fprintf(stderr, "Db99b");
      break;
    case VERSION_2000A:
      fprintf(stderr, "2000a");
      break;
    case VERSION_2000B:
      fprintf(stderr, "2000b");
      break;
    default:
      fprintf(stderr, "Ok�nd");
    }
    fprintf(stderr, "\n");
  }

  filepointer = *((long *)&buffer0[0xC]);

  while (filepointer > 0) {
    fseek(g_idxfile, filepointer, SEEK_SET);
    fread((char *)&buffer0, IDXENTRYSIZE, 1, g_idxfile);
    filepointer = *((long *)&buffer0[0x8]);

    if (*((long *)&buffer0[0]) == -2) {
      element = (idxentry_t *)malloc(sizeof(idxentry_t));
      if (element == NULL) {
	outofmemory();
	return false;
      }
      element->fileaddress = *((long *)&buffer0[0x10]);
      /*printf("%d\n", element->fileaddress);*/
    
      element->next = NULL;
      listpointer->next = (void *)element;
      listpointer = element;
    }
    g_idxcount++;
  }
  
  return true;
}

bool 
destroy_idxlist() 
{
  void *thispointer;
  void *nextpointer;

  thispointer = g_idxlist;
  while (thispointer != NULL) {
    nextpointer = (void *)((idxentry_t *)thispointer)->next;
    free(thispointer);
    thispointer = nextpointer;
  }
  g_idxlist = NULL;
  return true;
}

#ifdef EXTRACHEAP_MIRABILIS
bool
handle_message(const char *messageblock, long fileaddress) 
#else
bool
handle_message(const char *messageblock)
#endif  
{
  message_t *newmessage;
  message_t *listpointer;
  unsigned short length = *((unsigned short *)&messageblock[0x28]);
#ifndef EXTRACHEAP_MIRABILIS
  char *messagebuffer;
#endif
  
  newmessage = (message_t *)malloc(sizeof(message_t));
  if (newmessage == NULL) {
    outofmemory();
    return false;
  }

#ifdef EXTRACHEAP_MIRABILIS
  newmessage->messagefileaddress = fileaddress + 0x28;
#else
  messagebuffer = (char *)malloc(length);
  if (messagebuffer == NULL) {
    outofmemory();
    free(newmessage);
    return false;
  }
  strcpy(messagebuffer, &messageblock[0x2A]);
  newmessage->message = messagebuffer;
#endif
  newmessage->flags = *((long *)&messageblock[0x1E]);
  newmessage->type = *((unsigned short *)&messageblock[0x22]);
  newmessage->uin = *((long *)&messageblock[0x24]);
/*    newmessage->sent = (*((long *)&messageblock[0x2A+length+0x4]) == 1); */
  newmessage->sent = (newmessage->flags & 1) != 1;
  newmessage->timestamp = *((long *)&messageblock[0x2A+length+0xA]) + UGLY_TIMEZONE_COMPENSATION;

  listpointer = g_messagelistend;
  while (listpointer != g_messagelist && difftime(listpointer->prev->timestamp, newmessage->timestamp) > 0) {
    listpointer = listpointer->prev;
  }
  
  newmessage->next = listpointer->next;
  newmessage->prev = listpointer;

  (newmessage->prev)->next = newmessage;
  if (newmessage->next != NULL) {
    (newmessage->next)->prev = newmessage;
  }
  else {
    g_messagelistend = newmessage;
  }

  g_messagecount++;
  
  return true;
}

bool
handle_contact(const char *contactblock) 
{
  char *namebuffer = NULL;
  long blockpointer = 0;
  long namestringpointer, datapointer;
  long count0, count1, count2;

  contact_t *newcontact = (contact_t *)malloc(sizeof(contact_t));
  if (newcontact == NULL) {
    outofmemory();
    return false;
  }
  newcontact->name = NULL;
  newcontact->messagecount_sent = 0;
  newcontact->messagecount_received = 0;
  newcontact->bytecount_sent = 0;
  newcontact->bytecount_received = 0;
  newcontact->uin = -1;
  
  /* skippa f�rbi wav-fil-info */
  switch (g_dbversion) {
  case VERSION_NEWDB:
    blockpointer += 0x54;
    break;
  case VERSION_DB99B:
  case VERSION_2000A: /* <-- gissar ang�ende denna */
  case VERSION_2000B:
    blockpointer += 0x2c;
    break;
  }

  count0 = *((long *)&contactblock[blockpointer]);
  blockpointer += 4;
  for (;count0 > 0; count0--) {
    blockpointer += 0x0A;
    count1 = *((unsigned short *)&contactblock[blockpointer]);
    blockpointer += 2 + count1;
  }

  switch (g_dbversion) {
  case VERSION_NEWDB:
    blockpointer += 0x26;
    /* L�s user-property-block */
    blockpointer += 2;
    count1 = *((long *)&contactblock[blockpointer]);
    blockpointer += 4;
    for (;count1 > 0; count1--) {
      count2 = *((unsigned short *)&contactblock[blockpointer]);
      namestringpointer = blockpointer+2;
      blockpointer += 2 + count2;
      count2 = *((unsigned char *)&contactblock[blockpointer]);
      datapointer = blockpointer+1;
      switch (count2) {
      case 100:
      case 101:
	blockpointer += 1 + 1;
	break;
      case 102:
      case 103:
	blockpointer += 1 + 2;
	break;
      case 104:
      case 105:
	blockpointer += 1 + 4;
	break;
      case 107:
	blockpointer += 1;
	count2 = *((unsigned short *)&contactblock[blockpointer]);
	datapointer = blockpointer+2;
	blockpointer += 2 + count2;
	break;
      }
    }
    /* Plocka ut str�ngar */
    blockpointer += 2;
    namebuffer = (char *)malloc(strlen(&contactblock[blockpointer+2])+1);
    if (namebuffer == NULL) {
      outofmemory();
      free(newcontact);
      return false;
    }
    strcpy(namebuffer, &contactblock[blockpointer+2]);
    newcontact->name = namebuffer;
    for (count0=0; count0<4; count0++) {
      count2 = *((unsigned short *)&contactblock[blockpointer]);
      blockpointer += count2 + 2;
    }
    newcontact->uin = *((long *)&contactblock[blockpointer]);
    
    break;
  case VERSION_DB99B:
  case VERSION_2000A: /* <-- gissar ang�ende denna */
  case VERSION_2000B:
    blockpointer += 2;
    count0 = *((long *)&contactblock[blockpointer]);
    blockpointer += 4;
    for (;count0 > 0; count0--) {
      /* L�s user-property-block */
      blockpointer += 2;
      count1 = *((long *)&contactblock[blockpointer]);
      fflush(stdout);
      blockpointer += 4;
      for (;count1 > 0; count1--) {
	count2 = *((unsigned short *)&contactblock[blockpointer]);
	namestringpointer = blockpointer+2;
	blockpointer += 2 + count2;
	count2 = *((unsigned char *)&contactblock[blockpointer]);
	datapointer = blockpointer+1;
	switch (count2) {
	case 100:
	case 101:
	  blockpointer += 1 + 1;
	  break;
	case 102:
	case 103:
	  blockpointer += 1 + 2;
	  break;
	case 104:
	case 105:
	  blockpointer += 1 + 4;
	  break;
	case 107:
	  blockpointer += 1;
	  count2 = *((unsigned short *)&contactblock[blockpointer]);
	  datapointer = blockpointer+2;
	  blockpointer += 2 + count2;
	  break;
	case 109:
	  blockpointer += 1;
	  count1 += *((long *)&contactblock[blockpointer]) + 0;
	  blockpointer += 5;
	  break;
	}
	if (strcasecmp(&contactblock[namestringpointer], "uin") == 0) {
	  newcontact->uin = *((long *)&contactblock[datapointer]);
	}
	else if (strcasecmp(&contactblock[namestringpointer], "nickname") == 0) {
	  namebuffer = (char *)malloc(strlen(&contactblock[datapointer])+1);
	  if (namebuffer == NULL) {
	    outofmemory();
	    free(newcontact);
	    return false;
	  }
	  strcpy(namebuffer, &contactblock[datapointer]);
	  newcontact->name = namebuffer;
	}
      }
    }
    break;
  }
  newcontact->messagecount_sent = 0;
  newcontact->messagecount_received = 0;
  
  if (contact(newcontact->uin) == NULL) {
    newcontact->next = g_contactlist;
    g_contactlist = newcontact;
  }
  else {
    free(newcontact);
    free(namebuffer);
  }
  
  return true;
}

bool
traverse_datfile() 
{
  long buffer0size = 0x1000;
  idxentry_t *thispointer = (idxentry_t *)g_idxlist->next;
  long blocksize;
  unsigned char blocktype;
  char *buffer0 = (char *)malloc(buffer0size);
  if (buffer0 == NULL) {
    outofmemory();
    return false;
  }

  while (thispointer != NULL) {
    fseek(g_datfile, thispointer->fileaddress, SEEK_SET);
    thispointer = (idxentry_t *)thispointer->next;
    fread(buffer0, sizeof(long), 1, g_datfile);
    blocksize = *((long *)&buffer0[0]);
    if (blocksize > MAX_BLOCKSIZE) {
      if (g_verbose) {
	fread(&buffer0[4], 0x10, 1, g_datfile);
	fprintf(stderr, "Ogiltigt DAT-block p�tr�ffat. (P�stods vara %ld bytes l�ngt)\n", blocksize);
	fprintf(stderr, "P�stods ha blocktype %d\n", (int)*((unsigned char *)&buffer0[0xC]));
      }
      continue;
    }
    
    if (blocksize+4 > buffer0size) {
      buffer0size = blocksize+4+0x100;
      free(buffer0);
      buffer0 = (char *)malloc(buffer0size);
      if (buffer0 == NULL) {
	outofmemory();
	return false;
      }
    }

    fread(&buffer0[4], blocksize, 1, g_datfile);
    blocktype = *((unsigned char *)&buffer0[0xC]);
/*      hexdump(stdout, buffer0, blocksize+4); */
/*      fflush(stdout); */
    switch (blocktype) {
    case TYPE_MESSAGE:
    case TYPE_NEWSTYLEMESSAGE:
/*        hexdump(stdout, buffer0, blocksize+4); */
/*        fflush(stdout); */
#ifdef EXTRACHEAP_MIRABILIS
      handle_message(buffer0, ftell(g_datfile)-blocksize-4);
#else
      handle_message(buffer0);
#endif
      break;
    case TYPE_CONTACT:
/*        hexdump(stdout, buffer0, blocksize+4); */
/*        fflush(stdout); */
      handle_contact(buffer0);
      break;
    default:
      /*printf("Typ: %x\n", blocktype);*/
      break;
    }
  }
  
  free(buffer0);
  return true;
}

bool
process_mirabilis_db(const char *filenamestub) 
{
  bool result;
  result = openfiles(filenamestub)
    && create_idxlist()
    && traverse_datfile();
  destroy_idxlist();
#ifndef EXTRACHEAP_MIRABILIS
  closefiles();
#endif
  return result;
}

#ifdef EXTRACHEAP_MIRABILIS
bool
cleanup_mirabilis_db()
{
  return closefiles();
}
#endif
