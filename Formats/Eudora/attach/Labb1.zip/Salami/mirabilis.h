/*
    salami - icq log analyzer
    Copyright (C) 2000 Nicklas Lindgren <nicli380@student.liu.se>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef MIRABILIS_H
#define MIRABILIS_H

#define MAX_BLOCKSIZE 0x100000
#ifndef UGLY_TIMEZONE_COMPENSATION
#define UGLY_TIMEZONE_COMPENSATION 0
#endif

/* Funkar inge bra som switch-labels: */
/*  const unsigned char TYPE_MESSAGE = 0xE0; */
/*  const unsigned char TYPE_NEWSTYLEMESSAGE = 0x50; */
/*  const unsigned char TYPE_CONTACT = 0xE5; */
/*  const long VERSION_NEWDB = 10; */
/*  const long VERSION_DB99B = 14; */
/*  const long VERSION_2000A = 17; */
/*  const long VERSION_2000B = 18; */
/* D�rf�r �r dom #define-s */

/* Dessutom allokerar dom minne ... */
/*  const int IDXHEADERSIZE = 0xE1; */
/*  const int IDXENTRYSIZE = 0x14; */

#define TYPE_MESSAGE 0xE0
#define TYPE_NEWSTYLEMESSAGE 0x50
#define TYPE_CONTACT 0xE5

#define VERSION_NEWDB 10
#define VERSION_DB99B 14
#define VERSION_2000A 17
#define VERSION_2000B 18

#define IDXHEADERSIZE 0xE1
#define IDXENTRYSIZE 0x14

typedef struct 
{
  long fileaddress;
  void *next;
} idxentry_t;

extern FILE *g_datfile;
extern FILE *g_idxfile;
extern long g_dbversion;

extern idxentry_t *g_idxlist;
extern long g_idxcount;

bool process_mirabilis_db(const char *filenamestub);
bool openfiles(const char *filenamestub);
bool closefiles();
bool create_idxlist();
bool destroy_idxlist();
#ifdef EXTRACHEAP_MIRABILIS
bool handle_message(const char *messageblock, long fileaddress);
#else
bool handle_message(const char *messageblock);
#endif
bool handle_contact(const char *contactblock);
bool traverse_datfile();

#ifdef EXTRACHEAP_MIRABILIS
bool cleanup_mirabilis_db();
#endif

#endif
