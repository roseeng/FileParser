/*
    salami - icq log analyzer
    Copyright (C) 2000 Nicklas Lindgren <nicli380@student.liu.se>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "salami.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "mirabilis.h"

/****************************************************/

const char *NAME = "Salami 0.24 - icq-logg l�sare";
const char *COPYRIGHT = "Copyright 2000 Nicklas Lindgren";

bool g_verbose;
bool g_htmloutput;

long g_messagecount;
contact_t *g_contactlist;
message_t *g_messagelist;
message_t *g_messagelistend;

/****************************************************/

void
usage() 
{
  printf("%s\n%s\n\nAnv�nds som s�:\n\tsalami [PARAMETRAR] -d ICQDB\n\nValfria parametrar:\n-c\tSkriv ut kontaktlistan\n-s\tSkriv ut statistik\n-u UIN\tFiltrera p� UIN\n-h\tResultat i html-format\n-v\tSkriv ut en massa on�dig information\n\nICQDB �r en s�kv�g till en databasfil utan filtill�gg, t.ex.\nC:\\Program\\ICQ\\Db99b\\8644683\n\n", NAME, COPYRIGHT);
}

void
hexdump(FILE *tofile, char *buffer, long length) 
{
  long i;
  char ascii[17];

  ascii[16] = 0;
  
  for (i=0; i<length; i++) {
    if (i%16 == 0) {
      fprintf(tofile, "%08lX  ", i);
    }
    fprintf(tofile, "%02x ", (unsigned char)buffer[i]);
    ascii[i%16] = (buffer[i] >= 0x20 && buffer[i] <= 0x79 ? buffer[i] : '.');
    if (i%16 == 7) {
      fprintf(tofile, "- ");
    }
    if (i%16 == 15) {
      fprintf(tofile, " %s\n", (char *)&ascii[0]);
    }
  }
  if (length%16 < 15) {
    for(i = 16-(length%16); i > 0; i--) {
      fprintf(tofile, "   ");
    }
    if (length%16 < 8) {
      fprintf(tofile, "  ");
    }
    ascii[(length%16) + 1] = 0;
    fprintf(tofile, " %s\n", (char *)&ascii[0]);
  }
  fprintf(tofile, "\n");
}

void
outofmemory() 
{
  fprintf(stderr, "Slut p� minne!\ng_idxcount: %ld\ng_messagecount: %ld\n", g_idxcount, g_messagecount);
  closefiles();
  /* _exit(1); */
}

bool
init_lists()
{
  /* initiera listorna */
  g_contactlist = (contact_t *)malloc(sizeof(contact_t));
  if (g_contactlist == NULL) {
    outofmemory();
    return false;
  }
  g_contactlist->next = NULL;
  g_contactlist->uin = 0;
  
  g_messagelist = (message_t *)malloc(sizeof(message_t));
  if (g_messagelist == NULL) {
    outofmemory();
    return false;
  }

#ifdef EXTRACHEAP_MIRABILIS
  g_messagelist->messagefileaddress = 0;
#else
  g_messagelist->message = NULL;
#endif
  g_messagelist->next = NULL;
  g_messagelist->timestamp = 0;
  g_messagelistend = g_messagelist;
  g_messagecount = 0;

  return true;
}

bool
destroy_lists() 
{
  void *thispointer;
  void *nextpointer;

  thispointer = g_messagelist;
  while (thispointer != NULL) {
/*      if (g_verbose) { */
/*        printf("%ld %s\n", g_messagecount--, ((message_t *)thispointer)->message); */
/*        hexdump(stdout, thispointer-16, sizeof(message_t)+9+16); */
/*        fflush(stdout); */
/*      } */
    nextpointer = (void *)((message_t *)thispointer)->next;
#ifndef EXTRACHEAP_MIRABILIS
    if (((message_t *)thispointer)->message != NULL) {
      free(((message_t *)thispointer)->message);
    }
#endif
    free(thispointer);
    thispointer = nextpointer;
  }
  g_messagelist = NULL;

/*    if (g_verbose) { */
/*      fprintf(stderr, "Frigjorde meddelandelistan...\n"); */
/*      fflush(stderr); */
/*    } */
  
  thispointer = g_contactlist;
  while (thispointer != NULL) {
    nextpointer = (void *)((contact_t *)thispointer)->next;
    if (((contact_t *)thispointer)->uin != 0
	&& ((contact_t *)thispointer)->name != NULL) {
      free(((contact_t *)thispointer)->name);
    }
    free(thispointer);
    thispointer = nextpointer;
  }
  g_contactlist = NULL;

  return true;
}

contact_t *
contact(long uin) 
{
  contact_t *thispointer = g_contactlist;

  while (thispointer != NULL) {
    if (thispointer->uin == uin) {
      return (thispointer);
    }
    thispointer = thispointer->next;
  }
  return NULL;
}

bool
listcontacts() 
{
  contact_t *thispointer = g_contactlist;

  if (g_htmloutput) {
    printf("<PRE>\n");
  }

  while (thispointer != NULL) {
    if (thispointer->uin != 0) {
      printf("%16s (%ld)\n", thispointer->name, thispointer->uin);
    }
    thispointer = thispointer->next;
  }

  if (g_htmloutput) {
    printf("</PRE>\n");
  }

  return true;
}

bool
listmessages(long uinfilter) 
{
  message_t *thispointer;
  long buffer0size = 0x100;
/*    time_t prevtime = 0; */
  char timebuffer[26];
  contact_t *nick;
#ifdef EXTRACHEAP_MIRABILIS
  unsigned short length;
#endif
  char *buffer0 = (char *)malloc(buffer0size);
  if (buffer0 == NULL) {
    outofmemory();
    return false;
  }
  
  if (g_htmloutput) {
    printf("<PRE>\n");
  }

  thispointer = g_messagelist;
  while (thispointer != NULL) {
#ifdef EXTRACHEAP_MIRABILIS
    if (thispointer->messagefileaddress != 0
#else
    if (thispointer->message != NULL
#endif
	&& (uinfilter == -1 || uinfilter == thispointer->uin)) {
      strcpy((char *)&timebuffer, asctime(localtime((time_t *)&thispointer->timestamp)));
      timebuffer[24] = 0;
      printf("[%s - ", timebuffer);
      if (thispointer->sent) {
	printf("Till");
      }
      else {
	printf("Fr�n");
      }
      nick = contact(thispointer->uin);
      if (nick != NULL) {
	printf(" %s (%ld)]\n", nick->name, thispointer->uin);
      }
      else {
	printf(" #%ld]\n", thispointer->uin);
      }
      
      if (!(thispointer->flags & 4)) {
	printf("[Flags: %ld, Type: %u]\n", thispointer->flags, thispointer->type);
      }
#ifdef EXTRACHEAP_MIRABILIS
      fseek(g_datfile, thispointer->messagefileaddress, SEEK_SET);
      fread(buffer0, sizeof(unsigned short), 1, g_datfile);
      length = *((unsigned short *)&buffer0[0]);
      if (length > buffer0size) {
  	buffer0size = length+0x100;
  	free(buffer0);
  	buffer0 = (char *)malloc(buffer0size);
  	if (buffer0 == NULL) {
  	  outofmemory();
  	  return false;
  	}
      }
      fread(buffer0, length, 1, g_datfile);
      printf("%s\n\n", buffer0);
#else
      printf("%s\n\n", thispointer->message);
#endif
    }
    thispointer = thispointer->next;
  }

  if (g_htmloutput) {
    printf("</PRE>\n");
  }

  free(buffer0);
  return true;
}

bool
liststatistics(long uinfilter) 
{
  message_t *messagepointer;
  contact_t *contactpointer;
  contact_t *nick;
  int messagecount_received = 0;
  int messagecount_sent = 0;
  int full_messagecount = 0;
  long bytecount_received = 0;
  long bytecount_sent = 0;
  struct tm *timestruct;
  int messagesperhour[24];
  int i;

#ifdef EXTRACHEAP_MIRABILIS
  unsigned short length;
  long buffer0size = 0x100;
  char *buffer0 = (char *)malloc(buffer0size);
  if (buffer0 == NULL) {
    outofmemory();
    return false;
  }
#endif



  memset(&messagesperhour, 0, sizeof(int)*24);

  if (g_htmloutput) {
    printf("<PRE>\n");
  }
  
  messagepointer = g_messagelist;
  while (messagepointer != NULL) {
    full_messagecount++;
#ifdef EXTRACHEAP_MIRABILIS
    if (messagepointer->messagefileaddress != 0
#else
    if (messagepointer->message != NULL
#endif
	&& (uinfilter == -1 || uinfilter == messagepointer->uin)
	&& messagepointer->flags & 4) {
      timestruct = localtime((time_t *)&messagepointer->timestamp);

      messagesperhour[timestruct->tm_hour]++;
      
#ifdef EXTRACHEAP_MIRABILIS
      fseek(g_datfile, messagepointer->messagefileaddress, SEEK_SET);
      fread(buffer0, sizeof(unsigned short), 1, g_datfile);
      length = *((unsigned short *)&buffer0[0]);
      if (length > buffer0size) {
  	buffer0size = length+0x100;
  	free(buffer0);
  	buffer0 = (char *)malloc(buffer0size);
  	if (buffer0 == NULL) {
  	  outofmemory();
  	  return false;
  	}
      }
      fread(buffer0, length, 1, g_datfile);
#endif
      nick = contact(messagepointer->uin);
      if (messagepointer->sent) {
	messagecount_sent++;
#ifdef EXTRACHEAP_MIRABILIS
	bytecount_sent += strlen(buffer0);
#else
	bytecount_sent += strlen(messagepointer->message);
#endif
	if (nick != NULL) {
	  nick->messagecount_sent++;
#ifdef EXTRACHEAP_MIRABILIS
	nick->bytecount_sent += strlen(buffer0);
#else
	  nick->bytecount_sent += strlen(messagepointer->message);
#endif
	}
      }
      else {
	messagecount_received++;
#ifdef EXTRACHEAP_MIRABILIS
	bytecount_received += strlen(buffer0);
#else
	bytecount_received += strlen(messagepointer->message);
#endif
	if (nick != NULL) {
	  nick->messagecount_received++;
#ifdef EXTRACHEAP_MIRABILIS
	  nick->bytecount_received += strlen(buffer0);
#else
	  nick->bytecount_received += strlen(messagepointer->message);
#endif
	}
      }
    }
    messagepointer = messagepointer->next;
  }

  if (uinfilter != -1) {
    nick = contact(uinfilter);
    if (nick != NULL) {
      printf ("Statistik f�r %s\n", nick->name);
    }
    else {
      printf ("Statistik f�r #%ld\n", uinfilter);
    }
  }
  else {
    printf ("Statistik f�r samtliga\n");
  }
  
  printf("\nMeddelanden skickade/mottagna per tid p� dygnet:\n");
  for (i=0; i<24; i++) {
    printf("%02d-%02d %6d = %5.2f%%\n", i, i+1, messagesperhour[i],
	   ((double)100.0*messagesperhour[i]/(messagecount_sent + messagecount_received)));
  }
  if (g_verbose) {
    printf("  Tot %6d  (g_messagecount = %ld; full_messagecount = %d)\n", (messagecount_sent + messagecount_received), g_messagecount,full_messagecount);
  }
  
  printf("\nMeddelanden skickade/mottagna per person:\n");
  contactpointer = g_contactlist;
  while (contactpointer != NULL) {
    if (contactpointer->uin != 0
	&& (uinfilter == -1 || uinfilter == contactpointer->uin)) {
      printf("%16s %6d (%6d + %6d) = %5.2f%%\n", contactpointer->name,
	     contactpointer->messagecount_sent + contactpointer->messagecount_received,
	     contactpointer->messagecount_sent,
	     contactpointer->messagecount_received,
	     ((double)100.0*(contactpointer->messagecount_sent + contactpointer->messagecount_received)) /
	      (messagecount_sent + messagecount_received)
	     );
    }
    contactpointer = contactpointer->next;
  }
  printf("%16s %6d (%6d + %6d)\n", "(Summa)",
	 messagecount_sent + messagecount_received,
	 messagecount_sent,
	 messagecount_received);

  printf("\nBytes skickade/mottagna per person:\n");
  contactpointer = g_contactlist;
  while (contactpointer != NULL) {
    if (contactpointer->uin != 0
	&& (uinfilter == -1 || uinfilter == contactpointer->uin)) {
      printf("%16s %8ld (%8ld + %8ld) = %5.2f%%\n", contactpointer->name,
	     contactpointer->bytecount_sent + contactpointer->bytecount_received,
	     contactpointer->bytecount_sent,
	     contactpointer->bytecount_received,
	     ((double)100.0*(contactpointer->bytecount_sent + contactpointer->bytecount_received)) /
	      (bytecount_sent + bytecount_received)
	     );
    }
    contactpointer = contactpointer->next;
  }
  printf("%16s %8ld (%8ld + %8ld)\n", "(Summa)",
	 bytecount_sent + bytecount_received,
	 bytecount_sent,
	 bytecount_received);

  if (g_htmloutput) {
    printf("</PRE>\n");
  }
  
#ifdef EXTRACHEAP_MIRABILIS
  free(buffer0);
#endif

  return true;
}

/****************************************************/
/* Stulen r�tt ur DJGPP-s libc */
#ifdef MISSING_GETOPT
/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
  /*#include <libc/stubs.h>*/
  /*#include <stdio.h>*/
  /*#include <string.h>*/
  /*#include <unistd.h>*/
  /*#include <libc/unconst.h>*/

int opterr = 1,	optind = 1, optopt = 0;
char *optarg = 0;

#define	BADCH	(int)'?'
#define	EMSG	""

int
getopt(int nargc, char *const nargv[], const char *ostr)
{
  static char *place = EMSG;	/* option letter processing */
  char *oli;			/* option letter list index */
  char *p;

  if (!*place)
  {
    if (optind >= nargc || *(place = nargv[optind]) != '-')
    {
      place = EMSG;
      return(EOF);
    }
    if (place[1] && *++place == '-')
    {
      ++optind;
      place = EMSG;
      return(EOF);
    }
  }

  if ((optopt = (int)*place++) == (int)':'
      || !(oli = strchr(ostr, optopt)))
  {
    /*
     * if the user didn't specify '-' as an option,
     * assume it means EOF.
     */
    if (optopt == (int)'-')
      return EOF;
    if (!*place)
      ++optind;
    if (opterr)
    {
      if (!(p = strrchr(*nargv, '/')))
	p = *nargv;
      else
	++p;
      fprintf(stderr, "%s: illegal option -- %c\n", p, optopt);
    }
    return BADCH;
  }
  if (*++oli != ':')
  {		/* don't need argument */
    optarg = NULL;
    if (!*place)
      ++optind;
  }
  else
  {				/* need an argument */
    if (*place)			/* no white space */
      /*      optarg = unconst(place, char *);*/
      optarg = place;
    else if (nargc <= ++optind)
    { /* no arg */
      place = EMSG;
      if (!(p = strrchr(*nargv, '/')))
	p = *nargv;
      else
	++p;
      if (opterr)
	fprintf(stderr, "%s: option requires an argument -- %c\n",
		p, optopt);
      return BADCH;
    }
    else			/* white space */
      optarg = nargv[optind];
    place = EMSG;
    ++optind;
  }
  return optopt;		/* dump back option letter */
}
#endif

/****************************************************/
int 
main(int argc, char **argv) 
{
  long uinfilter = -1;
  bool contacts = false;
  bool statistics = false;
  char *filename = NULL;

  int c;
  
  g_verbose = false;
  g_htmloutput = false;

  opterr = 0;
  while ((c=getopt(argc, argv, "csvhu:d:")) != -1)
    {
      switch (c)
	{
	case 'c':
	  contacts = true;
	  break;
	case 'd':
	  filename = optarg;
	  break;
	case 's':
	  statistics = true;
	  break;
	case 'v':
	  g_verbose = true;
	  break;
	case 'h':
	  g_htmloutput = true;
	  break;
	case 'u':
	  sscanf(optarg, "%ld", &uinfilter);
	  break;
	case '?':
	  fprintf(stderr, "Ok�nd parameter: %c\n", optopt);
	  usage();
	  exit(1);
	  break;
	}
    }
  
  if (filename == NULL) {
    fprintf(stderr, "Ingen databasfil angiven!\n");
    usage();
    exit(1);
  }

  init_lists()
    && process_mirabilis_db(filename)
    && (statistics ? liststatistics(uinfilter) : (contacts ? listcontacts() : listmessages(uinfilter)));
  fflush(stdout);
#ifdef EXTRACHEAP_MIRABILIS
  cleanup_mirabilis_db();
#endif
  
  destroy_lists();
  
  return 0;
}

    
