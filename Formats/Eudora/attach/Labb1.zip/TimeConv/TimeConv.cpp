// TimeConv.cpp : Defines the entry point for the DLL application.
//

#define TIMECONV_EXPORTS 1
#include "stdafx.h"
#include "TimeConv.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

DWORD WINAPI fnCtime(time_t tptr, char *buf, int buflen)
{
	char *tmpbuf; /* = "Allan tar Kakan.....x...\n"; */
	
	tmpbuf = ctime(&tptr);
	if (buflen < 26) return(0);
	strcpy(buf, tmpbuf);
	return(strlen(tmpbuf)); 
}

extern "C" TIMECONV_API int dummy(void)
{
	return 47;
}

extern "C" TIMECONV_API int dummy2(DWORD buflen)
{
	return buflen+47;
}

DWORD WINAPI numChar(CHAR s[], DWORD x) 
{ 
	int i; 

	for (i=0;s[i]!=0;i++){}; 

	return i+x; 
} 

