(c) 2000 Visual Basic Programmer's Journal
Fawcette Technical Publications

Issue: December 2000
Section: Web Developer
Author: A. Russell Jones
Filename: VB0012WD

This file contains Listings 1 and 2 from the article in the listings.txt file and the article's code project. There are two VB6 projects, one DLL, an EXE, a sample XML file, and an XSL file. You will not be able to load these projects in VB5.


BEFORE YOU START:
1. You must have the Microsoft MSXML parser --  May preview version or later to run the samples.
2. Register the XMLINIFile.dll using regsvr32.exe. Click Start, Run, and then type the following line into the RUN box. 
3. You need to ensure that the IIS default user (IUSR_MACHINENAME) has read/write permissions to the XML INI file in Web applications; otherwise you will not be able to write to the file. Of course, if your application doesn't change the file, you do not need to apply write permisssions.

regsvr32.exe "<full path>XMLINIFile.dll"

NOTE: Substitute the drive and path to the DLL for the <full path> portion of the preceding line.

DESCRIPTION
Project XMLINIFile is an ActiveX DLL project.
Project XMLINIFileReader is a standard EXE project. It references the XMLINIFile.dll.
The sampleXML_INI.xml file is a standard XML file. It references the translateXMLtoINI.xsl stylesheet file, so if you view the xml file in IE, it looks like a standard INI file.

