'**************************************************************************************************
' OOPERAWizardsAddIn Connect Class:
' Klass f�r AddIn.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************

Imports EnvDTE
Imports Extensibility
Imports Microsoft.Office.Core
Imports OOPERA.ExceptionHandler
Imports OOPERA.ExceptionViewer
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<GuidAttribute("291E1FE6-3293-4C60-9C2B-AADA55DE4E43"), ProgIdAttribute("OOPERAWizardsAddIn.Connect")> _
Public Class Connect
    Implements Extensibility.IDTExtensibility2

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler
    Private mobjViewer As Viewer

    Private mobjVSInstance As DTE

    Private mobjMenus As CommandBarControls

    Private WithEvents mobjAddInInformationMenu As CommandBarEvents
#End Region

#Region "* * * D Y N A M I S K A   V A R I A B L E R * * *"
    'Dessa variabler kan beh�va modifieras

    '<START ANPASSA KOD>
    'Dimensionera en undermeny f�r varje wizard
    Private WithEvents mobjBuilderMenu As CommandBarEvents
    Private WithEvents mobjDocumentationMenu As CommandBarEvents
    Private WithEvents mobjExceptionDesignerMenu As CommandBarEvents
    Private WithEvents mobjSystemDesignerMenu As CommandBarEvents
    '<SLUT ANPASSA KOD>
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Placera egna variabler h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r ej modifieras
    Public Sub OnAddInsUpdate(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
    End Sub

    Public Sub OnBeginShutdown(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnBeginShutdown
    End Sub

    Public Sub OnDisconnection(ByVal RemoveMode As Extensibility.ext_DisconnectMode, ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnDisconnection
    End Sub

    Public Sub OnStartupComplete(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnStartupComplete
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mShowException(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjViewer Is Nothing Then mobjViewer = New Viewer()

            mobjViewer.Show(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r modifieras internt
    Private Sub mobjAddInInformationMenu_Click(ByVal CommandBarControl As Object, ByRef handled As Boolean, ByRef CancelDefault As Boolean) Handles mobjAddInInformationMenu.Click
        '******************************************************************************************
        ' Beskrivning: Startar IE med URL till intran�tssida. Skall implementeras annorlunda s� att 
        '              man pr�var att g� mot lokal sida f�rst/ist�llet eller p� annat s�tt hanterar 
        '              <> OOPERA\.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        '        Dim iex As Object 'InternetExplorer.Application

        Try
            MsgBox("About OOPERA Architecture...")

            '        iex = CreateObject("InternetExplorer.Application")

            '        'iex.Navigate("http://213.131.147.137/OOPERA.net/Komponenter/OO<'AddInName'>AddIn.htm") 'S�kv�gen till komponentbeskrivningen
            '        iex.navigate("http://213.131.147.137/OOPERANet/Arkitektur/Arkitektur.htm")
            '        iex.Visible = True

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Public Sub OnConnection(ByVal application As Object, ByVal connectMode As Extensibility.ext_ConnectMode, ByVal addInInst As Object, ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnConnection
        '******************************************************************************************
        ' Beskrivning: Instansierar AddIn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjVSInstance = CType(application, DTE)

            If connectMode <> ext_ConnectMode.ext_cm_External Then
                mobjMenus = mobjCreateMenus()

                '<START ANPASSA KOD>
                'Skapa en submenyinstans f�r varje wizard
                mobjBuilderMenu = mobjVSInstance.Events.CommandBarEvents(mobjMenus.Item(1))
                mobjDocumentationMenu = mobjVSInstance.Events.CommandBarEvents(mobjMenus.Item(2))
                mobjExceptionDesignerMenu = mobjVSInstance.Events.CommandBarEvents(mobjMenus.Item(3))
                mobjSystemDesignerMenu = mobjVSInstance.Events.CommandBarEvents(mobjMenus.Item(4))
                '<SLUT ANPASSA KOD>

                mobjAddInInformationMenu = mobjVSInstance.Events.CommandBarEvents(mobjMenus.Item(5))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Function mobjCreateMenus() As CommandBarControls
        '******************************************************************************************
        ' Beskrivning: Skapar menyer f�r AddIn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objToolsMenu As CommandBar
        Dim objMenu As CommandBarControl
        Dim objSubMenu As CommandBarControl

        Try
            objToolsMenu = mobjVSInstance.CommandBars("Tools")

            objMenu = objToolsMenu.Controls.Add(MsoControlType.msoControlPopup)
            objMenu.Caption = "OOPERA Wizards" 'Inget event
            objMenu.BeginGroup = True

            '<START ANPASSA KOD>
            'Skapa en submeny f�r varje wizard
            objSubMenu = objMenu.Controls.Add(MsoControlType.msoControlButton)
            objSubMenu.Caption = mstrBuilderDisplayName() '"Builder Wizard"

            objSubMenu = objMenu.Controls.Add(MsoControlType.msoControlButton)
            objSubMenu.Caption = mstrDocumentationDisplayName() '"Documentation Wizard"

            objSubMenu = objMenu.Controls.Add(MsoControlType.msoControlButton)
            objSubMenu.Caption = mstrExceptionDesignerDisplayName() '"ExceptionDesigner Wizard"

            objSubMenu = objMenu.Controls.Add(MsoControlType.msoControlButton)
            objSubMenu.Caption = mstrSystemDesignerDisplayName() '"SystemDesigner Wizard"
            '<SLUT ANPASSA KOD>

            objSubMenu = objMenu.Controls.Add(MsoControlType.msoControlButton)
            objSubMenu.Caption = "About OOPERAWizards AddIn..."
            objSubMenu.BeginGroup = True

            Return objMenu.Controls

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner

    '<START ANPASSA KOD>
    'F�nga Menu_Click event f�r varje wizard
    Private Sub mobjDocumentationMenu_Click(ByVal CommandBarControl As Object, ByRef handled As Boolean, ByRef CancelDefault As Boolean) Handles mobjDocumentationMenu.Click
        '******************************************************************************************
        ' Beskrivning: Startar DocumentationWizard.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objWizard As New Object() 'OOPERA.Wizard.OOPERADocumentationWizard.Wizard()

        MsgBox("Documentation Wizard")

        Try
            objWizard.Load(mobjVSInstance)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mobjBuilderMenu_Click(ByVal CommandBarControl As Object, ByRef handled As Boolean, ByRef CancelDefault As Boolean) Handles mobjDocumentationMenu.Click
        '******************************************************************************************
        ' Beskrivning: Startar BuilderWizard.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objWizard As New Object() 'OOPERA.Wizard.OOPERABuilderWizard.Wizard()

        MsgBox("Builder Wizard")

        Try
            objWizard.Load(mobjVSInstance)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mobjExceptionDesignerMenu_Click(ByVal CommandBarControl As Object, ByRef handled As Boolean, ByRef CancelDefault As Boolean) Handles mobjExceptionDesignerMenu.Click
        '******************************************************************************************
        ' Beskrivning: Startar ErrorHandlerWizard.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objWizard As New Object() 'OOPERA.Wizard.OOPERAExceptionDesignerWizard.Wizard()

        MsgBox("ExceptionDesigner Wizard")

        Try
            objWizard.Load(mobjVSInstance)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mobjSystemDesignerMenu_Click(ByVal CommandBarControl As Object, ByRef handled As Boolean, ByRef CancelDefault As Boolean) Handles mobjSystemDesignerMenu.Click
        '******************************************************************************************
        ' Beskrivning: Startar SystemBuilderWizard.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objWizard As New OOPERA.Wizards.OOPERASystemDesignerWizard.Wizard()

        Try
            objWizard.Load(mobjVSInstance)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub
    '<SLUT ANPASSA KOD>

    '<START ANPASSA KOD>
    'Skapa en DisplyName metod f�r varje wizard
    Private Function mstrBuilderDisplayName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar DisplayName f�r Builder.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....: 
        '******************************************************************************************
        Dim objWizard As New Object() 'OOPERA.Wizard.OOPERABuilderWizard.Wizard()

        Try
            Return "Builder Wizard ej implementerad" 'objWizard.DisplayName

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Function mstrDocumentationDisplayName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar DisplayName f�r Documentation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....: 
        '******************************************************************************************
        Dim objWizard As New Object() 'OOPERA.Wizard.OOPERADocumentationWizard.Wizard()

        Try
            Return "Documentation Wizard ej implementerad" 'objWizard.DisplayName

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Function mstrExceptionDesignerDisplayName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar DisplayName f�r ExceptionDesigner.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....: 
        '******************************************************************************************
        Dim objWizard As New Object() 'OOPERA.Wizard.OOPERAExceptionDesignerWizard.Wizard()

        Try
            Return "ExceptionDesigner Wizard ej implementerad" 'objWizard.DisplayName

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Function mstrSystemDesignerDisplayName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar DisplayName f�r SystemDesigner.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....: 
        '******************************************************************************************
        Dim objWizard As New OOPERA.Wizards.OOPERASystemDesignerWizard.Wizard()

        Try
            Return objWizard.DisplayName

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
    '<SLUT ANPASSA KOD>
#End Region

End Class
