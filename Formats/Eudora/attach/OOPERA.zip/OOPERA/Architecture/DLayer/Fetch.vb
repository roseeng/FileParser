'**************************************************************************************************
' DLayer Fetch Class:
' Bas f�r klasser som fungerar som returnerande datatj�nst f�r objekt.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.Data.SqlClient
Imports System.Xml

Public MustInherit Class Fetch
    Inherits System.EnterpriseServices.ServicedComponent

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Protected pobjCommand As SqlCommand
    Protected pstrFetchedData As String

    Private mobjConnection As SqlConnection

    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public MustOverride Overloads Function FetchAll(ByVal Recursive As Boolean) As String

    Public MustOverride Overloads Function FetchByID(ByVal ID As String, ByVal Recursive As Boolean) As String

    Public MustOverride Overloads Function FetchByParentID(ByVal ParentID As String, ByVal Recursive As Boolean) As String

    Public Overloads Function FetchAll() As String
        '******************************************************************************************
        ' Beskrivning: H�mtar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return FetchAll(False)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function FetchByID(ByVal ID As String) As String
        '******************************************************************************************
        ' Beskrivning: H�mtar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return FetchByID(ID, False)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function FetchByParentID(ByVal ParentID As String) As String
        '******************************************************************************************
        ' Beskrivning: H�mtar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return FetchByParentID(ParentID, False)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * I C K E P U B L I K A   M E T O D E R * * *"
    Protected Sub pCloseDatabase()
        '******************************************************************************************
        ' Beskrivning: St�nger koppling till datak�lla.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjConnection.Close()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Protected Sub pFetchData(ByVal strObjectName As String)
        '******************************************************************************************
        ' Beskrivning: H�mtar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSQLDataReader As SqlDataReader
        Dim objXMLAttribute As XmlAttribute
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement
        Dim i As Integer

        Try
            objXMLElement = objXMLDocument.CreateElement(strObjectName & "Collection")
            objXMLDocument.AppendChild(objXMLElement)

            objSQLDataReader = pobjCommand.ExecuteReader()

            While objSQLDataReader.Read()
                objXMLElement = objXMLDocument.CreateElement(strObjectName & "Object")

                For i = 0 To objSQLDataReader.FieldCount - 1
                    objXMLAttribute = objXMLDocument.CreateAttribute(objSQLDataReader.GetName(i))
                    objXMLAttribute.Value = objSQLDataReader.GetValue(i)
                    objXMLElement.Attributes.Append(objXMLAttribute)
                Next

                objXMLDocument.DocumentElement.AppendChild(objXMLElement)
            End While

            objSQLDataReader.Close()

            pstrFetchedData = objXMLDocument.OuterXml

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Protected Sub pOpenDatabase(ByVal strSystemName As String)
        '******************************************************************************************
        ' Beskrivning: �ppnar koppling till datak�lla.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()

        Try
            mobjConnection = New SqlConnection()
            pobjCommand = New SqlCommand()

            mobjConnection.ConnectionString = objSupport.ConnectionString(strSystemName)

            mobjConnection.Open()

            pobjCommand.Connection = mobjConnection

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
