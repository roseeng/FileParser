'**************************************************************************************************
' DLayer Save Class:
' Bas f�r klasser som fungerar som sparande datatj�nst f�r objekt.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports OOPERA.Support
Imports System.Data.SqlClient
Imports System.Xml

Public MustInherit Class Save
    Inherits System.EnterpriseServices.ServicedComponent

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Protected pobjCommand As SqlCommand

    Private mobjConnection As SqlConnection

    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public MustOverride Sub Save(ByVal XMLString As String)
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Protected MustOverride Sub pDelete(ByVal objXmlElement As XmlElement)

    Protected MustOverride Sub pInsert(ByVal objXmlElement As XmlElement)

    Protected MustOverride Sub pUpdate(ByVal objXmlElement As XmlElement)

    Protected Sub pCloseDatabase()
        '******************************************************************************************
        ' Beskrivning: St�nger koppling till datak�lla.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjConnection.Close()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Protected Sub pExecute(ByVal strSystemName As String, ByVal strObjectName As String, ByVal strXMLString As String)
        '******************************************************************************************
        ' Beskrivning: Sparar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLDocument.LoadXml(strXMLString)

            pOpenDatabase(strSystemName)

            For Each objXMLElement In objXMLDocument.SelectNodes("/" & strObjectName & "Collection" & "/" & strObjectName & "Object")
                Select Case CType(objXMLElement.Attributes.GetNamedItem("SaveStatus").Value, SaveStatusEnum)
                    Case SaveStatusEnum.ssDelete
                        pDelete(objXMLElement)
                    Case SaveStatusEnum.ssInsert
                        pInsert(objXMLElement)
                    Case SaveStatusEnum.ssNone
                        'F�r n�rvarande ingen �tg�rd
                    Case SaveStatusEnum.ssUpdate
                        pUpdate(objXMLElement)
                    Case Else
                End Select
            Next 'objXMLElement

            pCloseDatabase()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Protected Sub pOpenDatabase(ByVal strSystemName As String)
        '******************************************************************************************
        ' Beskrivning: �ppnar koppling till datak�lla.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()

        Try
            mobjConnection = New SqlConnection()
            pobjCommand = New SqlCommand()

            mobjConnection.ConnectionString = objSupport.ConnectionString(strSystemName)

            mobjConnection.Open()

            pobjCommand.Connection = mobjConnection

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
