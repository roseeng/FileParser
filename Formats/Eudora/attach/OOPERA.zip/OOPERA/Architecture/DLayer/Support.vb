'**************************************************************************************************
' DLayer Support Class:
' Supportklass f�r komponenten.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports OOPERA.Support

Friend Class Support

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Function ConnectionString(ByVal SystemName As String) As String
        '******************************************************************************************
        ' Beskrivning: Returnerar systemets Connectionstr�ng.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg            H�r �r vi inte riktigt klara som synes! *.config kanske �r b�ttre om m�jligt
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strConnectionString As String

        Try
            'Return "Data Source=BORG-II;Integrated Security = SSPI;Initial Catalog=" & SystemName 'tex, egentligen fr�ga WindowsRegistry f�r SystemName

            strConnectionString = strConnectionString & "Data Source=" & WindowsRegistry.GetValue("SOFTWARE\OOPERA Konsult AB\DataConnections\" & SystemName, "ServerName", "(local)", WindowsRegistryHiveEnum.rhLocalMachine) & ";"
            strConnectionString = strConnectionString & "Integrated Security = SSPI;"
            strConnectionString = strConnectionString & "Initial Catalog=" & WindowsRegistry.GetValue("SOFTWARE\OOPERA Konsult AB\DataConnections\" & SystemName, "DatabaseName", SystemName, WindowsRegistryHiveEnum.rhLocalMachine)

            Return strConnectionString

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
