'**************************************************************************************************
' GLayer Application Class:
' Abstrakt f�r klasser som implementerar applikationsgenerell information.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.Console

Public MustInherit Class Application

    Implements OOPERA.Console.IConsoleApplication

    Public Overridable ReadOnly Property ComponentName() As String Implements OOPERA.Console.IConsoleApplication.ComponentName
        Get
            Return "Component.Name"
        End Get
    End Property

    Public Overridable ReadOnly Property FriendlyName() As String Implements OOPERA.Console.IConsoleApplication.FriendlyName
        Get
            Return "Friendly name"
        End Get
    End Property

    Public MustOverride Sub GetImages(ByVal Images As OOTreeList.ListImages) Implements OOPERA.Console.IConsoleApplication.GetImages

    Public MustOverride Sub GetStandardMenus(ByVal StandardMenus As OOPERA.Console.MenuToolbarEnum) Implements OOPERA.Console.IConsoleApplication.GetStandardMenus

    'Annat namn h�r och hela implementationen
    Protected Function mstrFormatError(ByVal lngErrorNumber As Long, ByVal strErrorSource As String, ByVal strErrorDescription As String, ByVal strEXEName As String, ByVal strClassName As String, ByVal strMethodName As String, ByVal lngErrorLine As Long) As String
        '******************************************************************************************
        ' Beskrivning: Formaterar Errorinformation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        '        Const THIS_METHOD As String = "mstrFormatError"

        '        On Error GoTo ErrorHandler

        '        mstrFormatError = strErrorDescription

        'ErrorHandler:
        'Ingen felhantering i felhanteringen
    End Function

End Class
