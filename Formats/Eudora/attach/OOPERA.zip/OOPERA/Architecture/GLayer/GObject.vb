'**************************************************************************************************
' GLayer Application Class:
' Abstrakt f�r klasser f�r objekt.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.Console

Public MustInherit Class GObject

    Implements OOPERA.Console.IConsoleObject

    Public Overridable Sub Add(ByVal NodeToAddTo As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef ListViewColumnHeaders As OOTreeList.ColumnHeaders, ByRef AllListImages As OOTreeList.ListImages, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Add

    End Sub

    Public Overridable Sub AddOwnContextMenuItems(ByRef ContextMenu As Object, ByVal SelectedNode As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef ListViewColumnHeaders As OOTreeList.ColumnHeaders, ByRef AllListImages As OOTreeList.ListImages, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.AddOwnContextMenuItems

    End Sub

    Public Overridable ReadOnly Property ComponentName() As String Implements OOPERA.Console.IConsoleObject.ComponentName
        Get
            Return "Component.Name"
        End Get
    End Property

    Public Overridable Sub Copy(ByVal NodeToCopy As OOTreeList.Node, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Copy

    End Sub

    Public Overridable Sub Cut(ByVal NodeToCut As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Cut

    End Sub

    Public Overridable Sub Delete(ByVal NodeToDelete As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Delete

    End Sub

    Public Overridable Sub Edit(ByVal NodeToEdit As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Edit

    End Sub

    Public Overridable Sub ExecuteOwnContextMethod(ByVal MenuIndex As Long, ByVal SelectedNode As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef ListViewColumnHeaders As OOTreeList.ColumnHeaders, ByRef AllListImages As OOTreeList.ListImages, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.ExecuteOwnContextMethod

    End Sub

    Public WriteOnly Property FormIcon() Implements OOPERA.Console.IConsoleObject.FormIcon
        Set(ByVal Value)

        End Set
    End Property

    Public ReadOnly Property FriendlyName() As String Implements OOPERA.Console.IConsoleObject.FriendlyName
        Get

        End Get
    End Property

    Public Overridable Sub Paste(ByVal NodeToPasteTo As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Paste

    End Sub

    Public Overridable Sub Preview(ByVal NodeToPreview As OOTreeList.Node, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Preview

    End Sub

    Public Overridable Sub PrintOut(ByVal NodeToPrintOut As OOTreeList.Node, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.PrintOut

    End Sub

    Public Overridable Sub Refresh(ByVal NodeToRefresh As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef ListViewColumnHeaders As OOTreeList.ColumnHeaders, ByRef AllListImages As OOTreeList.ListImages, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Refresh

    End Sub

    Public Overridable Sub Search(ByVal NodeToSearch As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef ListViewColumnHeaders As OOTreeList.ColumnHeaders, ByRef AllListImages As OOTreeList.ListImages, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Search

    End Sub

    Public Overridable Sub Show(ByVal NodeToShow As OOTreeList.Node, ByRef AllNodes As OOTreeList.Nodes, ByRef AllListItems As OOTreeList.ListItems, ByRef ListViewColumnHeaders As OOTreeList.ColumnHeaders, ByRef AllListImages As OOTreeList.ListImages, ByRef StateCollection As Collection) Implements OOPERA.Console.IConsoleObject.Show

    End Sub

    Public Overridable ReadOnly Property SupportContextMenu() As Boolean Implements OOPERA.Console.IConsoleObject.SupportContextMenu
        '******************************************************************************************
        ' Beskrivning: Returnerar om st�d finns f�r contextmeny.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Const THIS_METHOD As String = "SupportContextMenu"

            SupportContextMenu = True
        End Get
    End Property

    Public Function SupportFunction(ByVal Method As OOPERA.Console.MethodEnum) As Boolean Implements OOPERA.Console.IConsoleObject.SupportFunction
        '******************************************************************************************
        ' Beskrivning: Returnerar om en funktion st�ds och om beh�righet finns.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Const THIS_METHOD As String = "SupportFunction"

        On Error GoTo ErrorHandler

        SupportFunction = mblnSupportFunction(Method)

ErrorHandler:
        Dim lngErrNumber As Long, strErrSource As String, strErrDescription As String
        If Err.Number <> 0 Then
            lngErrNumber = Err.Number : strErrSource = Err.Source : strErrDescription = Err.Description
            Err.Raise(lngErrNumber, strErrSource, mstrFormatError(lngErrNumber, strErrSource, strErrDescription, "", TypeName(Me), THIS_METHOD, Erl))
        End If
    End Function

    '**********************************************************************************************

    Protected MustOverride Function mblnSupportFunction(ByVal metMethod As OOPERA.Console.MethodEnum) As Boolean

    'Annat namn h�r och hela implementationen
    Protected Function mstrFormatError(ByVal lngErrorNumber As Long, ByVal strErrorSource As String, ByVal strErrorDescription As String, ByVal strEXEName As String, ByVal strClassName As String, ByVal strMethodName As String, ByVal lngErrorLine As Long) As String
        '******************************************************************************************
        ' Beskrivning: Formaterar Errorinformation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        '        Const THIS_METHOD As String = "mstrFormatError"

        '        On Error GoTo ErrorHandler

        '        mstrFormatError = strErrorDescription

        'ErrorHandler:
        'Ingen felhantering i felhanteringen
    End Function

End Class
