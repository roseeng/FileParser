'**************************************************************************************************
' GTest Application Class:
' Klass som implementerar applikationsgenerell information.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Class Application
    Inherits OOPERA.Architecture.GLayer.Application

    Public Overrides Sub GetImages(ByVal Images As OOTreeList.ListImages)

    End Sub

    Public Overrides Sub GetStandardMenus(ByVal StandardMenus As OOPERA.Console.EEnum.MenuToolBarEnum)

    End Sub

End Class
