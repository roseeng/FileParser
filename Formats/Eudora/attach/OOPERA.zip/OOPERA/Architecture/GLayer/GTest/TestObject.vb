'**************************************************************************************************
' GTest TestObject Class:
' Klass f�r objekt.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Class TestObject
    Inherits OOPERA.Architecture.GLayer.GObject

    Protected Overrides Function mblnSupportFunction(ByVal metMethod As OOPERA.Console.EEnum.MethodEnum) As Boolean
        Select Case metMethod
            Case OOPERA.Console.EEnum.MethodEnum.x
                '*test
                Dim frm As New TestObjectForm()
                frm.ShowDialog()
                If Not frm.Cancelled Then
                    MsgBox("OK")
                End If
            Case Else

        End Select
    End Function

End Class
