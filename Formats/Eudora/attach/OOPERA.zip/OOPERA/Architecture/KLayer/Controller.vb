'**************************************************************************************************
' KLayer Controller Class:
' Bas f�r klasser f�r beh�righet.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public MustInherit Class Controller
    Inherits System.EnterpriseServices.ServicedComponent

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overridable Overloads Function MethodIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String, ByVal MethodName As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till metoden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overridable Overloads Function MethodIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String, ByVal MethodName As String, ByVal UserName As String, ByVal Password As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till metoden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overridable Overloads Function ObjectIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till objektet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overridable Overloads Function ObjectIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String, ByVal UserName As String, ByVal Password As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till objektet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overridable Overloads Function UseCaseIsAuthorized(ByVal UseCaseName As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till anv�ndningsfallet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overridable Overloads Function UseCaseIsAuthorized(ByVal UseCaseName As String, ByVal UserName As String, ByVal Password As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till anv�ndningsfallet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * I C K E P U B L I K A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
