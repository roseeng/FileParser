'**************************************************************************************************
' KLayer UseCase Class:
' Bas f�r klasser f�r anv�ndningsfall.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public MustInherit Class UseCase
    Inherits System.EnterpriseServices.ServicedComponent

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"

#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"

#End Region

#Region "* * * I C K E P U B L I K A   M E T O D E R * * *"

#End Region

End Class
