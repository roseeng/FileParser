'**************************************************************************************************
' ConsoleServer AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************

Imports System.EnterpriseServices
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("OOPERA.ConsoleServer")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("ConsoleServer")> 
<Assembly: AssemblyCopyright("Copyright �YYYY OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("3FDAFEB9-EF08-4D50-980C-E6CF15C8071A")> 'GuidGen /HB
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: ApplicationActivation(ActivationOption.Server)> 
<Assembly: ApplicationID("1C2F866B-372E-437a-B73C-D232BAE025C8")>  'GuidGen /HB
<Assembly: ApplicationName("ConsoleServer")> 
<Assembly: Description("Applikation f�r ConsoleServer")> 
<Assembly: AssemblyKeyFile("../../OOPERA.ConsoleServer.snk")> 
