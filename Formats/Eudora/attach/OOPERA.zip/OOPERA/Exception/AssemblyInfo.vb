Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("OOPERA.Exception")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("OOPERA.Exception")> 
<Assembly: AssemblyCopyright("Copyright �2002 OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("5DFE0A05-B7AE-4200-AB56-D2CFD3D842A8")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
