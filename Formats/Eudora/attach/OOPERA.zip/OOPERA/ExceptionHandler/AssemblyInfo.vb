'**************************************************************************************************
' ExceptionHandler AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("OOPERA.ExceptionHandler")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("OOPERA Exception Handler")> 
<Assembly: AssemblyCopyright("Copyright �2002 OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("49B41F48-F1AA-47D4-8237-F8CE96AE7AB9")> 
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyKeyFile("../../OOPERA.ExceptionHandler.snk")> 
