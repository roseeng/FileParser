'**************************************************************************************************
' OOErrorHandler EventLog Class:
' Klass f�r funktionalitet mot NTs Event Log.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports System.Diagnostics

Friend Class EventLogX

    Public Sub Log(ByVal Number As Long, ByVal Description As String, ByVal Source As String, ByVal Version As String, _
                   ByVal Line As Integer, ByVal TimeStamp As Date, ByVal Server As String)
        '******************************************************************************************
        ' Beskrivning: Formaterar meddelande f�r loggning.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim datTimeStamp As Date
        Dim objEventLog As New System.Diagnostics.EventLog("Application")
        Dim shtCategory As Long
        Dim strDescription As String
        Dim strMachineName As String
        Dim strMessage As String
        Dim strSource As String
        Dim strUser As String
        Dim strVersion As String

        Try
            If Server = "" Then
                strMachineName = Me.MachineName
            Else
                strMachineName = Server
            End If

            strUser = Me.DomainUser

            strDescription = IIf(Description = "", "Ok�nd", Description)
            strMachineName = IIf(strMachineName = "", "Ok�nd", strMachineName)
            strSource = IIf(Source = "", "Ok�nd", Source)
            datTimeStamp = IIf(TimeStamp = "00:00:00", Now(), TimeStamp)
            strUser = IIf(strUser = "", "Ok�nd", strUser)
            strVersion = IIf(Version = "", "Ok�nd", Version)

            strMessage = vbCrLf
            strMessage &= "App" & vbTab & ": " & strSource & vbCrLf
            strMessage &= "Version" & vbTab & ": " & strVersion & vbCrLf
            strMessage &= "Error" & vbTab & ": " & Number & vbCrLf
            strMessage &= "Text" & vbTab & ": " & strDescription & vbCrLf
            strMessage &= "Line" & vbTab & ": " & Line & vbCrLf
            strMessage &= "Time" & vbTab & ": " & datTimeStamp & vbCrLf
            strMessage &= "Server" & vbTab & ": " & strMachineName & vbCrLf
            strMessage &= "User" & vbTab & ": " & strUser

            shtCategory = 5

            objEventLog.WriteEntry(strSource, strMessage, EventLogEntryType.Error, Number, shtCategory)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Public ReadOnly Property MachineName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar maskinnamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return System.Environment.MachineName

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Get
    End Property

    Public ReadOnly Property DomainUser() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar Dom�n\Anv�ndarnamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return System.Environment.UserDomainName & "\" & System.Environment.UserName

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Get
    End Property

End Class
