'**************************************************************************************************
' ExceptionHandler Handler Class:
' Klass f�r funktionalitet kring fel med stack.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports System.Diagnostics
Imports System.Xml

Public Class Handler

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjXMLDocument As XmlDocument

    Private mstrMachineName As String
    Private mstrDomainUser As String
    Private mstrCallingAssembly As String
    Private mstrEntryAssembly As String
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public ReadOnly Property Message() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar Description.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Dim objXMLElement As XmlElement

            Try
                If Not mobjXMLDocument Is Nothing Then
                    objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception")
                    If Not objXMLElement Is Nothing Then
                        If Not objXMLElement.Attributes.GetNamedItem("Message") Is Nothing Then
                            Return objXMLElement.Attributes.GetNamedItem("Message").Value
                        End If
                    End If
                End If

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Get
    End Property

    Public ReadOnly Property Source() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar Source.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Dim objXMLElement As XmlElement

            Try
                If Not mobjXMLDocument Is Nothing Then
                    objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception")
                    If Not objXMLElement Is Nothing Then
                        If Not objXMLElement.Attributes.GetNamedItem("Source") Is Nothing Then
                            Return objXMLElement.Attributes.GetNamedItem("Source").Value
                        End If
                    End If
                End If

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Get
    End Property

    Public ReadOnly Property StackTrace() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar felets stack.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Dim objXMLElement As XmlElement

            Try
                If Not mobjXMLDocument Is Nothing Then
                    objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace")
                    If Not objXMLElement Is Nothing Then Return objXMLElement.OuterXml
                End If

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overloads Function Log(ByVal Exception As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: Tar emot och hanterar information om ett fel.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return Log(Exception, False)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Public Overloads Function Log(ByVal Exception As Exception, ByVal SaveToFile As Boolean) As Exception
        '******************************************************************************************
        ' Beskrivning: Tar emot och hanterar information om ett fel.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strFilePath As String
        Dim strFileName As String

        Try
            strFilePath = System.Environment.GetEnvironmentVariable("TEMP")
            strFileName = "~OOPERAExceptionHandler." & Format(Now(), "YYYYMMDDHHMMSS") & ".tmp"

            Return Log(Exception, SaveToFile, strFilePath, strFileName)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Public Overloads Function Log(ByVal Exception As Exception, ByVal SaveToFile As Boolean, ByVal FilePath As String, ByVal FileName As String) As Exception
        '******************************************************************************************
        ' Beskrivning: Tar emot och hanterar information om ett fel.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strServer As String
        Dim strDomainUser As String
        Dim objConstructorArgsArray(1) As Object

        Try
            mstrMachineName = System.Environment.MachineName
            mstrDomainUser = System.Environment.UserDomainName & "\" & System.Environment.UserName
            mstrCallingAssembly = System.Reflection.Assembly.GetCallingAssembly.FullName

            Try
                mstrEntryAssembly = System.Reflection.Assembly.GetEntryAssembly.FullName 'Bara om win32

            Catch objException As Exception

            End Try

            'Fyll stacktrace
            mExceptionToXML(Exception)

            'Ursprungsfelet till eventloggen
            If Exception.InnerException Is Nothing Then mLog()

            If SaveToFile Then mSaveToFile(FilePath, FileName)

            objConstructorArgsArray(0) = mobjXMLDocument.OuterXml
            objConstructorArgsArray(1) = Exception

            Return Activator.CreateInstance(Exception.GetType(), objConstructorArgsArray)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Sub mLog()
        '******************************************************************************************
        ' Beskrivning: Formaterar meddelande f�r loggning.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim datTimeStamp As Date
        Dim intEventID As Integer = 65535
        Dim objEventLog As New System.Diagnostics.EventLog("Application")
        Dim shtCategory As Short '>=8
        Dim strCaller As String
        Dim strDescription As String
        Dim strEntry As String
        Dim strEntryAssembly As String
        Dim strEntryVersion As String
        Dim strLine As String
        Dim strMessage As String
        Dim strSource As String

        Try
            If mstrEntryAssembly <> "" Then
                strEntryAssembly = mstrEntryAssembly.Substring(0, mstrEntryAssembly.IndexOf(",")).Trim()

                strEntryVersion = mstrEntryAssembly.Substring(mstrEntryAssembly.IndexOf("Version="))
                strEntryVersion = strEntryVersion.Substring(strEntryVersion.IndexOf("Version="), strEntryVersion.IndexOf(",") - strEntryVersion.IndexOf("Version="))
                strEntryVersion = strEntryVersion.Replace("Version=", "").Trim()

                strEntry = strEntryAssembly & vbTab & " " & strEntryVersion
            Else
                strEntryAssembly = "Web Application"
                strEntry = strEntryAssembly
            End If

            strCaller = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace/Entry").Attributes.GetNamedItem("Assembly").Value & vbTab & " " & mobjXMLDocument.SelectSingleNode("/Exception/StackTrace/Entry").Attributes.GetNamedItem("Version").Value
            strMessage = mobjXMLDocument.SelectSingleNode("/Exception").Attributes.GetNamedItem("Message").Value
            strLine = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace/Entry").Attributes.GetNamedItem("Line").Value
            strSource = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace/Entry").Attributes.GetNamedItem("Assembly").Value
            datTimeStamp = Now().ToString

            strDescription &= "Entry" & vbTab & ": " & strEntry & vbCrLf
            strDescription &= "Caller" & vbTab & ": " & strCaller & vbCrLf
            strDescription &= "Text" & vbTab & ": " & strMessage & vbCrLf
            strDescription &= "Line" & vbTab & ": " & strLine & vbCrLf
            strDescription &= "Time" & vbTab & ": " & datTimeStamp & vbCrLf
            strDescription &= "Server" & vbTab & ": " & mstrMachineName & vbCrLf
            strDescription &= "User" & vbTab & ": " & mstrDomainUser

            objEventLog.WriteEntry(strEntryAssembly, strDescription, EventLogEntryType.Error, intEventID, shtCategory)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Sub mExceptionToXML(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: Formaterar meddelande f�r loggning.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************        
        Dim objXMLElement As XmlElement

        Try
            mobjXMLDocument = New XmlDocument()

            Try
                mobjXMLDocument.LoadXml(objException.Message)

                If mobjXMLDocument.SelectSingleNode("/Exception") Is Nothing Then
                    mCreateExceptionXMLDocument(objException)
                End If

                objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace")
                objXMLElement.InsertBefore(mobjExceptionToStackEntry(objException), objXMLElement.FirstChild)

            Catch objLocalException As Exception
                mCreateExceptionXMLDocument(objException)

                objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace")
                objXMLElement.InsertBefore(mobjExceptionToStackEntry(objException), objXMLElement.FirstChild)

            End Try

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Function mobjExceptionToStackEntry(ByVal objException As Exception) As XmlElement
        '******************************************************************************************
        ' Beskrivning: Formaterar ett undantag till XML.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim objXMLAttribute As XmlAttribute
        Dim strTemp As String
        Dim strTempLeft As String
        Dim strAssembly As String
        Dim strAssemblyComponent As String
        Dim strComponent As String
        Dim strLine As String
        Dim strMethod As String
        Dim strTempRight As String
        Dim strVersion As String

        Try
            strTemp = objException.StackTrace.Substring(objException.StackTrace.LastIndexOf(" at ")).Replace(" at ", "").Trim()

            strTempLeft = strTemp.Substring(0, strTemp.LastIndexOf(")") + 1)
            strTempRight = strTemp.Substring(strTemp.LastIndexOf(")") + 1)

            strAssemblyComponent = strTempLeft.Substring(0, strTempLeft.LastIndexOf("."))
            strAssembly = strAssemblyComponent.Substring(0, strAssemblyComponent.LastIndexOf(".")).Trim()
            strComponent = strAssemblyComponent.Substring(strAssemblyComponent.LastIndexOf(".") + 1).Trim()

            strMethod = strTempLeft.Substring(strTempLeft.LastIndexOf(".") + 1, strTempLeft.LastIndexOf("(") - strTempLeft.LastIndexOf(".") - 1).Trim()

            strLine = strTempRight.Substring(strTempRight.IndexOf(":line")).Replace(":line", "").Trim()

            strVersion = mstrCallingAssembly.Substring(mstrCallingAssembly.IndexOf("Version="))
            strVersion = strVersion.Substring(strVersion.IndexOf("Version="), strVersion.IndexOf(",") - strVersion.IndexOf("Version="))
            strVersion = strVersion.Replace("Version=", "").Trim()

            objXMLElement = mobjXMLDocument.CreateElement("Entry")

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Assembly")
            objXMLAttribute.Value = strAssembly
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Component")
            objXMLAttribute.Value = strComponent
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Method")
            objXMLAttribute.Value = strMethod
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Line")
            objXMLAttribute.Value = strLine
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Version")
            objXMLAttribute.Value = strVersion
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Server")
            objXMLAttribute.Value = mstrMachineName
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("User")
            objXMLAttribute.Value = mstrDomainUser
            objXMLElement.SetAttributeNode(objXMLAttribute)

            Return objXMLElement

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mCreateExceptionXMLDocument(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: Skapar ett XMLDocument av ursprungsfelet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim objXMLElement2 As XmlElement
        Dim objXMLAttribute As XmlAttribute
        Dim strVersion As String

        Try
            mobjXMLDocument = New XmlDocument()

            objXMLElement = mobjXMLDocument.CreateElement("Exception")

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Source")
            objXMLAttribute.Value = objException.Source
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Message")
            objXMLAttribute.Value = objException.Message
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLElement2 = mobjXMLDocument.CreateElement("StackTrace")

            objXMLElement.AppendChild(objXMLElement2)

            mobjXMLDocument.AppendChild(objXMLElement)

            strVersion = System.Reflection.Assembly.GetExecutingAssembly().FullName
            strVersion = strVersion.Substring(strVersion.IndexOf("Version="))
            strVersion = strVersion.Substring(strVersion.IndexOf("Version="), strVersion.IndexOf(",") - strVersion.IndexOf("Version="))
            strVersion = strVersion.Replace("Version=", "").Trim()

            mobjXMLDocument.InsertBefore(mobjXMLDocument.CreateProcessingInstruction("ooperaexceptionhandler", "version=""" & strVersion & """"), mobjXMLDocument.FirstChild)
            mobjXMLDocument.InsertBefore(mobjXMLDocument.CreateProcessingInstruction("xml", "version='1.0' encoding='ISO-8859-1'"), mobjXMLDocument.FirstChild)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Sub mSaveToFile(ByVal strFilepath As String, ByVal strFilename As String)
        '******************************************************************************************
        ' Beskrivning: Sparar felet och dess stack till fil.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strFile As String

        Try
            strFile = strFilepath & "\" & strFilename

            mobjXMLDocument.Save(strFile)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

End Class
