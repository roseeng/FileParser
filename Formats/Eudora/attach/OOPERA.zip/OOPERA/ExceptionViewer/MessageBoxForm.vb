'**************************************************************************************************
' ExceptionViewer MessageBox Form:
' Formul�r f�r visning av felmeddelande och stack.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports System.Xml

Public Class MessageBoxForm
    Inherits System.Windows.Forms.Form

#Region "* * * K O N S T A N T E R * * *"
    Private Const BUTTON_TEXT_HIDESTACK As String = "&D�lj Stack"
    Private Const BUTTON_TEXT_SHOWSTACK As String = "Vi&sa Stack"

    Private Const FORM_HEIGHT_INITIAL As Long = 156
    Private Const FORM_HEIGHT_EXTENDED As Long = 432

    Private Const IMAGE_MSG_INFORMATION As Integer = 0
    Private Const IMAGE_MSG_QUESTION As Integer = 1
    Private Const IMAGE_MSG_WARNING As Integer = 2
    Private Const IMAGE_MSG_ERROR As Integer = 3
    Private Const IMAGE_ARROWDOWN As Integer = 4
#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjXMLDocument As XmlDocument

    Private msmMode As ShowModeEnum
    Private mblnSave As Boolean

    Private mblnVisible As Boolean
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public WriteOnly Property ShowMode() As ShowModeEnum
        '******************************************************************************************
        ' Beskrivning: S�tter ShowMode.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As ShowModeEnum)
            Try
                msmMode = Value

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Set
    End Property

    Public ReadOnly Property Save() As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar Spara.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Save = mblnSave

            Catch objException As Exception
                'Ignorera fel under felhanteringen!

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"
    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        '******************************************************************************************
        ' Beskrivning: St�nger formul�ret.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If chkSave.Checked Then mblnSave = True

            Me.Close()

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Sub cmdStack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStack.Click
        '******************************************************************************************
        ' Beskrivning: D�ljer/Visar stack.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mblnVisible Then
                mblnVisible = False
                Me.Height = FORM_HEIGHT_INITIAL
                cmdStack.Text = BUTTON_TEXT_SHOWSTACK
            Else
                mblnVisible = True
                Me.Height = FORM_HEIGHT_EXTENDED
                cmdStack.Text = BUTTON_TEXT_HIDESTACK
            End If

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Sub MessageBoxForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: Visar felets och dess stack.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case msmMode
                Case ShowModeEnum.smAll
                    Me.Height = FORM_HEIGHT_INITIAL
                    Me.FormBorderStyle = FormBorderStyle.Sizable
                    Me.MaximizeBox = True
                    Me.MinimizeBox = True

                    mShowError()
                    mFillstack()

                Case ShowModeEnum.smStack
                    Me.Height = FORM_HEIGHT_EXTENDED
                    Me.FormBorderStyle = FormBorderStyle.Sizable
                    Me.MaximizeBox = True
                    Me.MinimizeBox = True

                    'chkSave.Left = 4
                    cmdStack.Visible = False
                    cmdOK.Visible = False
                    picIcon.Visible = False
                    lblMessage.Visible = False

                    lvwStack.Top = 4
                    lvwStack.Left = 2
                    lvwStack.Height = Me.Height - 34
                    lvwStack.Width = Me.Width - 12

                    mFillstack()

                Case ShowModeEnum.smError
                    Me.Height = FORM_HEIGHT_INITIAL
                    Me.FormBorderStyle = FormBorderStyle.FixedDialog
                    Me.MaximizeBox = False
                    Me.MinimizeBox = False

                    cmdStack.Visible = False
                    cmdOK.Left = (Me.Width - cmdOK.Width) / 2

                    mShowError()

                Case Else
            End Select

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub LoadXML(ByVal XMLString As String)
        '******************************************************************************************
        ' Beskrivning: Tar emot ett fel och dess stack.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjXMLDocument = New XmlDocument()

            mobjXMLDocument.LoadXml(XMLString)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Sub mShowError()
        '******************************************************************************************
        ' Beskrivning: Visar felet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objElement As XmlElement
        Dim strTempMessage As String

        Try
            If Not mobjXMLDocument Is Nothing Then
                objElement = mobjXMLDocument.SelectSingleNode("/Exception")
                If Not objElement Is Nothing Then
                    strTempMessage &= "Felet : "
                    strTempMessage &= objElement.Attributes.GetNamedItem("Message").Value
                    strTempMessage &= vbCrLf
                    strTempMessage &= "intr�ffade i : "
                    strTempMessage &= objElement.Attributes.GetNamedItem("Source").Value

                    lblMessage.Text = strTempMessage
                End If
            End If

            picIcon.Image = imlImage.Images(IMAGE_MSG_ERROR)

            objElement = Nothing

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Sub mFillstack()
        '******************************************************************************************
        ' Beskrivning: Fyller listview med stack.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objElement As XmlElement
        Dim itm As ListViewItem

        Try
            lvwStack.Columns.Clear()

            lvwStack.Columns.Add("Assembly", 160, HorizontalAlignment.Left)
            lvwStack.Columns.Add("Version", 90, HorizontalAlignment.Left)
            lvwStack.Columns.Add("Komponent", 110, HorizontalAlignment.Left)
            lvwStack.Columns.Add("Metod", 150, HorizontalAlignment.Left)
            lvwStack.Columns.Add("Rad", 40, HorizontalAlignment.Right)
            lvwStack.Columns.Add("Server", 90, HorizontalAlignment.Left)
            lvwStack.Columns.Add("Konto", 110, HorizontalAlignment.Left)

            lvwStack.Items.Clear()

            For Each objElement In mobjXMLDocument.SelectNodes("/Exception/StackTrace/Entry")
                itm = lvwStack.Items.Add(objElement.Attributes.GetNamedItem("Assembly").Value, IMAGE_ARROWDOWN)
                itm.SubItems.Add(objElement.Attributes.GetNamedItem("Version").Value)
                itm.SubItems.Add(objElement.Attributes.GetNamedItem("Component").Value)
                itm.SubItems.Add(objElement.Attributes.GetNamedItem("Method").Value)
                itm.SubItems.Add(objElement.Attributes.GetNamedItem("Line").Value)
                itm.SubItems.Add(objElement.Attributes.GetNamedItem("Server").Value)
                itm.SubItems.Add(objElement.Attributes.GetNamedItem("User").Value)
            Next 'objElement

            lvwStack.Items.Item(lvwStack.Items.Count - 1).ImageIndex = IMAGE_MSG_ERROR

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdStack As System.Windows.Forms.Button
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents lvwStack As System.Windows.Forms.ListView
    Friend WithEvents picIcon As System.Windows.Forms.PictureBox
    Friend WithEvents imlImage As System.Windows.Forms.ImageList
    Friend WithEvents imlStack As System.Windows.Forms.ImageList
    Friend WithEvents chkSave As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MessageBoxForm))
        Me.cmdStack = New System.Windows.Forms.Button()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lvwStack = New System.Windows.Forms.ListView()
        Me.imlStack = New System.Windows.Forms.ImageList(Me.components)
        Me.picIcon = New System.Windows.Forms.PictureBox()
        Me.imlImage = New System.Windows.Forms.ImageList(Me.components)
        Me.chkSave = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'cmdStack
        '
        Me.cmdStack.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdStack.Location = New System.Drawing.Point(447, 98)
        Me.cmdStack.Name = "cmdStack"
        Me.cmdStack.TabIndex = 0
        Me.cmdStack.Text = "Vi&sa stack"
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdOK.Location = New System.Drawing.Point(370, 98)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.TabIndex = 1
        Me.cmdOK.Text = "OK"
        '
        'lblMessage
        '
        Me.lblMessage.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblMessage.Location = New System.Drawing.Point(60, 20)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(462, 65)
        Me.lblMessage.TabIndex = 2
        '
        'lvwStack
        '
        Me.lvwStack.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lvwStack.FullRowSelect = True
        Me.lvwStack.HideSelection = False
        Me.lvwStack.LabelWrap = False
        Me.lvwStack.Location = New System.Drawing.Point(10, 132)
        Me.lvwStack.MultiSelect = False
        Me.lvwStack.Name = "lvwStack"
        Me.lvwStack.Size = New System.Drawing.Size(512, 241)
        Me.lvwStack.SmallImageList = Me.imlStack
        Me.lvwStack.TabIndex = 3
        Me.lvwStack.View = System.Windows.Forms.View.Details
        '
        'imlStack
        '
        Me.imlStack.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlStack.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlStack.ImageStream = CType(resources.GetObject("imlStack.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlStack.TransparentColor = System.Drawing.Color.Transparent
        '
        'picIcon
        '
        Me.picIcon.Location = New System.Drawing.Point(10, 20)
        Me.picIcon.Name = "picIcon"
        Me.picIcon.Size = New System.Drawing.Size(32, 32)
        Me.picIcon.TabIndex = 4
        Me.picIcon.TabStop = False
        '
        'imlImage
        '
        Me.imlImage.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlImage.ImageSize = New System.Drawing.Size(32, 32)
        Me.imlImage.ImageStream = CType(resources.GetObject("imlImage.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlImage.TransparentColor = System.Drawing.Color.Transparent
        '
        'chkSave
        '
        Me.chkSave.Location = New System.Drawing.Point(10, 382)
        Me.chkSave.Name = "chkSave"
        Me.chkSave.Size = New System.Drawing.Size(104, 17)
        Me.chkSave.TabIndex = 5
        Me.chkSave.Text = "Spara till fil"
        '
        'MessageBoxForm
        '
        Me.AcceptButton = Me.cmdOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdOK
        Me.ClientSize = New System.Drawing.Size(534, 407)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkSave, Me.picIcon, Me.lvwStack, Me.lblMessage, Me.cmdOK, Me.cmdStack})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MessageBoxForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Felmeddelande"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
