'**************************************************************************************************
' ExceptionViewer ShowMode Enumeration:
' Enumeration f�r ExceptionViewer.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum ShowModeEnum
    smAll
    smError
    smStack
End Enum
