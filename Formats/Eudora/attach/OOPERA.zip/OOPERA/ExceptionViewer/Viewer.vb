'**************************************************************************************************
' ExceptionViewer Viewer Class:
' Klass f�r visning av fel med stack.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports System.Xml

Public Class Viewer

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjXMLDocument As XmlDocument

    Private mstrMachineName As String
    Private mstrDomainUser As String
    Private mstrCallingAssembly As String
    Private mstrEntryAssembly As String
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overloads Sub Show(ByVal Exception As Exception)
        '******************************************************************************************
        ' Beskrivning: Visar formul�r med felinformation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim frm As New MessageBoxForm()
        Dim strTempXML As String

        Try
            mstrMachineName = System.Environment.MachineName
            mstrDomainUser = System.Environment.UserDomainName & "\" & System.Environment.UserName
            mstrCallingAssembly = System.Reflection.Assembly.GetCallingAssembly.FullName
            mstrEntryAssembly = System.Reflection.Assembly.GetEntryAssembly.FullName

            mobjXMLDocument = New XmlDocument()

            Try
                mobjXMLDocument.LoadXml(Exception.Message)

                frm.ShowMode = ShowModeEnum.smAll

            Catch objException As Exception
                mExceptionToXML(Exception)

                frm.ShowMode = ShowModeEnum.smError

            End Try

            frm.LoadXML(mobjXMLDocument.OuterXml)

            frm.ShowDialog()

            If frm.Save Then Save(Exception)

            frm = Nothing

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Public Sub ShowStack(ByVal Exception As Exception)
        '******************************************************************************************
        ' Beskrivning: Visar formul�r med felinformation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim frm As New MessageBoxForm()
        Dim strTempXML As String

        Try
            mstrMachineName = System.Environment.MachineName
            mstrDomainUser = System.Environment.UserDomainName & "\" & System.Environment.UserName
            mstrCallingAssembly = System.Reflection.Assembly.GetCallingAssembly.FullName
            mstrEntryAssembly = System.Reflection.Assembly.GetEntryAssembly.FullName

            mobjXMLDocument = New XmlDocument()

            Try
                mobjXMLDocument.LoadXml(Exception.Message)

                frm.ShowMode = ShowModeEnum.smStack

            Catch objException As Exception
                mExceptionToXML(Exception)

                frm.ShowMode = ShowModeEnum.smError

            End Try

            frm.LoadXML(mobjXMLDocument.OuterXml)

            frm.ShowDialog()

            If frm.Save Then Save(Exception)

            frm = Nothing

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Public Sub ShowError(ByVal Exception As Exception)
        '******************************************************************************************
        ' Beskrivning: Visar formul�r med felinformation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim frm As New MessageBoxForm()
        Dim strTempXML As String

        Try
            mstrMachineName = System.Environment.MachineName
            mstrDomainUser = System.Environment.UserDomainName & "\" & System.Environment.UserName
            mstrCallingAssembly = System.Reflection.Assembly.GetCallingAssembly.FullName
            mstrEntryAssembly = System.Reflection.Assembly.GetEntryAssembly.FullName

            mobjXMLDocument = New XmlDocument()

            Try
                mobjXMLDocument.LoadXml(Exception.Message)

                frm.ShowMode = ShowModeEnum.smError

            Catch objException As Exception
                mExceptionToXML(Exception)

                frm.ShowMode = ShowModeEnum.smError

            End Try

            frm.LoadXML(mobjXMLDocument.OuterXml)

            frm.ShowDialog()

            If frm.Save Then Save(Exception)

            frm = Nothing

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Public Overloads Sub Save(ByVal Exception As Exception)
        '******************************************************************************************
        ' Beskrivning: Sparar felet och dess stack till fil.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strFilePath As String
        Dim strFileName As String

        Try
            mstrMachineName = System.Environment.MachineName
            mstrDomainUser = System.Environment.UserDomainName & "\" & System.Environment.UserName
            mstrCallingAssembly = System.Reflection.Assembly.GetCallingAssembly.FullName
            mstrEntryAssembly = System.Reflection.Assembly.GetEntryAssembly.FullName

            strFilePath = System.Environment.GetEnvironmentVariable("TEMP")
            strFileName = "~OOPERAExceptionHandler." & Format(Now(), "YYYYMMDDHHMMSS") & ".tmp"

            Save(Exception, strFilePath, strFileName)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Public Overloads Sub Save(ByVal Exception As Exception, ByVal Filepath As String, ByVal Filename As String)
        '******************************************************************************************
        ' Beskrivning: Sparar felet och dess stack till fil.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As XmlDocument
        Dim strFile As String

        Try
            mstrMachineName = System.Environment.MachineName
            mstrDomainUser = System.Environment.UserDomainName & "\" & System.Environment.UserName
            mstrCallingAssembly = System.Reflection.Assembly.GetCallingAssembly.FullName
            mstrEntryAssembly = System.Reflection.Assembly.GetEntryAssembly.FullName

            mExceptionToXML(Exception)

            strFile = Filepath & "\" & Filename

            mobjXMLDocument.Save(strFile)

        Catch objException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Sub mExceptionToXML(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: Formaterar meddelande f�r loggning.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************        
        Dim objXMLElement As XmlElement

        Try
            mobjXMLDocument = New XmlDocument()

            Try
                mobjXMLDocument.LoadXml(objException.Message)

                If mobjXMLDocument.SelectSingleNode("/Exception") Is Nothing Then
                    mCreateExceptionXMLDocument(objException)
                End If

                objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace")
                objXMLElement.InsertBefore(mobjExceptionToStackEntry(objException), objXMLElement.FirstChild)

            Catch objLocalException As Exception
                mCreateExceptionXMLDocument(objException)

                objXMLElement = mobjXMLDocument.SelectSingleNode("/Exception/StackTrace")
                objXMLElement.InsertBefore(mobjExceptionToStackEntry(objException), objXMLElement.FirstChild)

            End Try

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub

    Private Function mobjExceptionToStackEntry(ByVal objException As Exception) As XmlElement
        '******************************************************************************************
        ' Beskrivning: Formaterar ett undantag till XML.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim objXMLAttribute As XmlAttribute
        Dim strTemp As String
        Dim strTempLeft As String
        Dim strAssembly As String
        Dim strAssemblyComponent As String
        Dim strComponent As String
        Dim strLine As String
        Dim strMethod As String
        Dim strTempRight As String
        Dim strVersion As String

        Try
            strTemp = objException.StackTrace.Substring(objException.StackTrace.LastIndexOf(" at ")).Replace(" at ", "").Trim()

            strTempLeft = strTemp.Substring(0, strTemp.LastIndexOf(")") + 1)
            strTempRight = strTemp.Substring(strTemp.LastIndexOf(")") + 1)

            strAssemblyComponent = strTempLeft.Substring(0, strTempLeft.LastIndexOf("."))
            strAssembly = strAssemblyComponent.Substring(0, strAssemblyComponent.LastIndexOf(".")).Trim()
            strComponent = strAssemblyComponent.Substring(strAssemblyComponent.LastIndexOf(".") + 1).Trim()

            strMethod = strTempLeft.Substring(strTempLeft.LastIndexOf(".") + 1, strTempLeft.LastIndexOf("(") - strTempLeft.LastIndexOf(".") - 1).Trim()

            strLine = strTempRight.Substring(strTempRight.IndexOf(":line")).Replace(":line", "").Trim()

            strVersion = mstrCallingAssembly.Substring(mstrCallingAssembly.IndexOf("Version="))
            strVersion = strVersion.Substring(strVersion.IndexOf("Version="), strVersion.IndexOf(",") - strVersion.IndexOf("Version="))
            strVersion = strVersion.Replace("Version=", "").Trim()

            objXMLElement = mobjXMLDocument.CreateElement("Entry")

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Assembly")
            objXMLAttribute.Value = strAssembly
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Component")
            objXMLAttribute.Value = strComponent
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Method")
            objXMLAttribute.Value = strMethod
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Line")
            objXMLAttribute.Value = strLine
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Version")
            objXMLAttribute.Value = strVersion
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Server")
            objXMLAttribute.Value = mstrMachineName
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("User")
            objXMLAttribute.Value = mstrDomainUser
            objXMLElement.SetAttributeNode(objXMLAttribute)

            Return objXMLElement

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mCreateExceptionXMLDocument(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: Skapar ett XMLDocument av ursprungsfelet.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElement As XmlElement
        Dim objXMLElement2 As XmlElement
        Dim objXMLAttribute As XmlAttribute
        Dim strVersion As String

        Try
            mobjXMLDocument = New XmlDocument()

            objXMLElement = mobjXMLDocument.CreateElement("Exception")

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Source")
            objXMLAttribute.Value = objException.Source
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLAttribute = mobjXMLDocument.CreateAttribute("Message")
            objXMLAttribute.Value = objException.Message
            objXMLElement.SetAttributeNode(objXMLAttribute)

            objXMLElement2 = mobjXMLDocument.CreateElement("StackTrace")

            objXMLElement.AppendChild(objXMLElement2)

            mobjXMLDocument.AppendChild(objXMLElement)

            strVersion = System.Reflection.Assembly.GetExecutingAssembly().FullName
            strVersion = strVersion.Substring(strVersion.IndexOf("Version="))
            strVersion = strVersion.Substring(strVersion.IndexOf("Version="), strVersion.IndexOf(",") - strVersion.IndexOf("Version="))
            strVersion = strVersion.Replace("Version=", "").Trim()

            mobjXMLDocument.InsertBefore(mobjXMLDocument.CreateProcessingInstruction("ooperaexceptionhandler", "version=""" & strVersion & """"), mobjXMLDocument.FirstChild)
            mobjXMLDocument.InsertBefore(mobjXMLDocument.CreateProcessingInstruction("xml", "version='1.0' encoding='ISO-8859-1'"), mobjXMLDocument.FirstChild)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

End Class
