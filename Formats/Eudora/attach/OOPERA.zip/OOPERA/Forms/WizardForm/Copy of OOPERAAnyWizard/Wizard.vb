'**************************************************************************************************
' OOPERASystemDesignerWizard Wizard Class:
' Applikationsklass f�r wizard.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports EnvDTE

Public Class Wizard

#Region "* * * S T A T I S K A   K O N S T A N T E R * * *"
    'Dessa konstanter f�r ej modifieras
    Const WIZARD_DISPLAYNAME As String = "OOPERA SystemDesigner Wizard" '"OOPERA <'WizardDisplayName'> Wizard"
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjVSInstance As DTE
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa metoder f�r ej modifieras
    Public ReadOnly Property DisplayName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar DisplayName.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                DisplayName = WIZARD_DISPLAYNAME

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public Sub Load(ByVal VSInstance As DTE)
        '******************************************************************************************
        ' Beskrivning: Visar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New Form1(VSInstance, WIZARD_DISPLAYNAME)

        Try
            frm.ShowDialog()

        Catch objException As Exception
            Throw objException

        End Try
    End Sub
#End Region

End Class
