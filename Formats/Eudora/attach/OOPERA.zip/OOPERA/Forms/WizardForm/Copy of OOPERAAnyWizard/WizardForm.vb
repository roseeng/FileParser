'**************************************************************************************************
' WizardForm Wizard Form:
' Bas f�r formul�r av wizardtyp.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports EnvDTE
Imports System.Windows.Forms
Imports System.Xml

Friend MustInherit Class WizardForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Private Sub New() 'HB Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdNext As Button
    Friend WithEvents cmdPrevious As Button
    Friend WithEvents cmdCancel As Button
    Friend WithEvents grpStart As GroupBox
    Friend WithEvents picLeftMarginStart As PictureBox
    Friend WithEvents lblStart As Label
    Friend WithEvents grpFinish As GroupBox
    Friend WithEvents lblFinish As Label
    Friend WithEvents picLeftMarginFinish As PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(WizardForm))
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdNext = New System.Windows.Forms.Button()
        Me.cmdPrevious = New System.Windows.Forms.Button()
        Me.grpStart = New System.Windows.Forms.GroupBox()
        Me.lblStart = New System.Windows.Forms.Label()
        Me.picLeftMarginStart = New System.Windows.Forms.PictureBox()
        Me.grpFinish = New System.Windows.Forms.GroupBox()
        Me.lblFinish = New System.Windows.Forms.Label()
        Me.picLeftMarginFinish = New System.Windows.Forms.PictureBox()
        Me.grpStart.SuspendLayout()
        Me.grpFinish.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdCancel.Location = New System.Drawing.Point(942, 737)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.TabIndex = 5
        Me.cmdCancel.Text = "Avbryt"
        '
        'cmdNext
        '
        Me.cmdNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdNext.Location = New System.Drawing.Point(849, 737)
        Me.cmdNext.Name = "cmdNext"
        Me.cmdNext.TabIndex = 6
        Me.cmdNext.Text = "&N�sta >"
        '
        'cmdPrevious
        '
        Me.cmdPrevious.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdPrevious.Location = New System.Drawing.Point(772, 737)
        Me.cmdPrevious.Name = "cmdPrevious"
        Me.cmdPrevious.TabIndex = 7
        Me.cmdPrevious.Text = "< &Bak�t"
        '
        'grpStart
        '
        Me.grpStart.BackColor = System.Drawing.SystemColors.Window
        Me.grpStart.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblStart, Me.picLeftMarginStart})
        Me.grpStart.Location = New System.Drawing.Point(448, 132)
        Me.grpStart.Name = "grpStart"
        Me.grpStart.Size = New System.Drawing.Size(208, 100)
        Me.grpStart.TabIndex = 8
        Me.grpStart.TabStop = False
        Me.grpStart.Text = "start"
        '
        'lblStart
        '
        Me.lblStart.Location = New System.Drawing.Point(156, 50)
        Me.lblStart.Name = "lblStart"
        Me.lblStart.TabIndex = 1
        Me.lblStart.Text = "Label1"
        '
        'picLeftMarginStart
        '
        Me.picLeftMarginStart.Image = CType(resources.GetObject("picLeftMarginStart.Image"), System.Drawing.Bitmap)
        Me.picLeftMarginStart.Location = New System.Drawing.Point(36, 48)
        Me.picLeftMarginStart.Name = "picLeftMarginStart"
        Me.picLeftMarginStart.TabIndex = 0
        Me.picLeftMarginStart.TabStop = False
        '
        'grpFinish
        '
        Me.grpFinish.BackColor = System.Drawing.SystemColors.Window
        Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblFinish, Me.picLeftMarginFinish})
        Me.grpFinish.Location = New System.Drawing.Point(406, 172)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(208, 100)
        Me.grpFinish.TabIndex = 9
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "finish"
        '
        'lblFinish
        '
        Me.lblFinish.Location = New System.Drawing.Point(156, 50)
        Me.lblFinish.Name = "lblFinish"
        Me.lblFinish.TabIndex = 1
        Me.lblFinish.Text = "Label1"
        '
        'picLeftMarginFinish
        '
        Me.picLeftMarginFinish.Image = CType(resources.GetObject("picLeftMarginFinish.Image"), System.Drawing.Bitmap)
        Me.picLeftMarginFinish.Location = New System.Drawing.Point(36, 48)
        Me.picLeftMarginFinish.Name = "picLeftMarginFinish"
        Me.picLeftMarginFinish.TabIndex = 0
        Me.picLeftMarginFinish.TabStop = False
        '
        'WizardForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1026, 771)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpFinish, Me.grpStart, Me.cmdPrevious, Me.cmdNext, Me.cmdCancel})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "WizardForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "WizardForm"
        Me.grpStart.ResumeLayout(False)
        Me.grpFinish.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "* * * S T A T I S K A   K O N S T A N T E R * * *"
    'Dessa konstanter f�r ej modifieras
    Private Const NAVIGATOR_BACK As Long = 2
    Private Const NAVIGATOR_CANCEL As Long = 1
    Private Const NAVIGATOR_NEXT_FINISH As Long = 3

    Private Const STEP_START As Long = 0
#End Region

#Region "* * * D Y N A M I S K A   K O N S T A N T E R * * *"
    '<START ANPASSA KOD>
    'Skapa konstanter f�r varje steg
    Private Const STEP_FINISH As Long = 6 + 1
    '<SLUT ANPASSA KOD>
#End Region

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mblnTerminateSession As Boolean
    Private mcolInstruction As New Collection()
    Private mcolStep As New Collection()
    Private mintCurrentStep As Integer
    Private mobjVSInstance As DTE
    Private mstrDisplayName As String
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Dimensionera egna variabler h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa metoder f�r ej modifieras
    Public Sub New(ByVal VSInstance As DTE, ByVal DisplayName As String)
        '******************************************************************************************
        ' Beskrivning: Overloads Default Constructor.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Me.New()

        Try
            mobjVSInstance = VSInstance
            mstrDisplayName = DisplayName

            Me.Width = 503
            Me.Height = 385
            Me.Text = mstrDisplayName

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        '******************************************************************************************
        ' Beskrivning: Navigerar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mCancel()

        Catch objException As Exception
            mShowError(objException)

        End Try
    End Sub

    Private Sub cmdNext_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNext.Click
        '******************************************************************************************
        ' Beskrivning: Navigerar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Cursor.Current = Cursors.WaitCursor

            If mintCurrentStep = STEP_FINISH Then
                mApply()
            Else
                If mblnValidate(mintCurrentStep) Then
                    mSetVariables(mintCurrentStep)
                    mSetStep(mintCurrentStep + 1)
                End If
            End If

        Catch objException As Exception
            mShowError(objException)

        Finally
            Cursor.Current = Cursors.Default

        End Try
    End Sub

    Private Sub cmdPrevious_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrevious.Click
        '******************************************************************************************
        ' Beskrivning: Navigerar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mSetStep(mintCurrentStep - 1)

        Catch objException As Exception
            mShowError(objException)

        End Try
    End Sub

    Private Sub WizardForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        '******************************************************************************************
        ' Beskrivning: F�rhindrar att formul�ret st�ngs via ControlMenu.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Not mblnTerminateSession Then e.Cancel = True

        Catch objException As Exception
            mShowError(objException)

        End Try
    End Sub

    Private Sub WizardForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: Initieringar.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mInitControls()

            mSetStep(STEP_START)

        Catch objException As Exception
            mShowError(objException)

        End Try
    End Sub

    Private Sub mCancel()
        '******************************************************************************************
        ' Beskrivning: St�nger formul�ret.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mblnTerminateSession = True

            Me.Close()

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mInitControls()
        '******************************************************************************************
        ' Beskrivning: Initiering av kontroller.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim l As Long

        Try
            mCreateGroupBoxCollections()
            mSetInstructionLabels()

            For l = STEP_START + 1 To STEP_FINISH - 1
                With CType(mcolStep.Item(l), GroupBox)
                    .Left = -2
                    .Top = -8
                    .Width = Me.Width
                    .Height = Me.Height - 62

                    .Text = ""
                End With

                With CType(mcolInstruction.Item(l), GroupBox)
                    .Left = -2
                    .Top = -8
                    .Width = Me.Width
                    .Height = Me.Height - 316

                    .Text = ""
                End With
            Next 'l

            With grpStart
                .Left = -2
                .Top = -8
                .Width = Me.Width
                .Height = Me.Height - 62

                .Text = ""
            End With

            With grpFinish
                .Left = -2
                .Top = -8
                .Width = Me.Width
                .Height = Me.Height - 62

                .Text = ""
            End With

            With picLeftMarginStart
                .Left = 0
                .Top = 0
                .Width = 166
                .Height = 321
            End With

            With picLeftMarginFinish
                .Left = 0
                .Top = 0
                .Width = 166
                .Height = 321
            End With

            With lblStart
                .Left = 200
                .Top = 80
                .Width = 264
                .Height = 98

                .Text = "V�lkommen till " & mstrDisplayName
            End With

            With lblFinish
                .Left = 200
                .Top = 80
                .Width = 264
                .Height = 98

                .Text = "Tryck p� Slutf�r f�r att genomf�ra �tg�rderna"
            End With

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mSetFrame(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Hanterar gruppboxar.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim l As Long

        Try
            For l = STEP_START + 1 To STEP_FINISH - 1
                mcolStep.Item(l).Left = -10000
            Next 'l
            grpStart.Left = -10000
            grpFinish.Left = -10000

            Select Case lngStep
                Case STEP_START
                    grpStart.Left = -2
                Case STEP_FINISH
                    grpFinish.Left = -2
                Case Else
                    mcolStep.Item(lngStep).Left = -2
            End Select

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mSetNavigator(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Hanterar navigationsknappar.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case lngStep
                Case STEP_START
                    cmdPrevious.Enabled = False
                    cmdNext.Enabled = True

                    cmdNext.Text = "&N�sta >"
                Case STEP_FINISH
                    cmdPrevious.Enabled = True
                    cmdNext.Enabled = True

                    cmdNext.Text = "&Slutf�r"
                Case Else
                    cmdPrevious.Enabled = True
                    cmdNext.Enabled = True

                    cmdNext.Text = "&N�sta >"
            End Select

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mSetStep(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Hanterar navigeringsf�ruts�ttningar och frames.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mSetNavigator(lngStep)
            mSetFrame(lngStep)

            mintCurrentStep = lngStep

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mShowError(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: Visar felmeddelande.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            MessageBox.Show(Me, "Felet '" & objException.Message & "' intr�ffade i '" & objException.Source & "'", "Felmeddelande")

        Catch objExceptionException As Exception
            'Ingen felhantering i felhanteringen

        End Try
    End Sub
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa metoder f�r modifieras internt
    Private Sub mApply()
        '******************************************************************************************
        ' Beskrivning: Genomf�r �nskade �tg�rder.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSolution As Solution
        Dim i As Integer
        Dim intUseCase As Integer

        Try
            Cursor.Current = Cursors.WaitCursor

            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att genomf�ra �nskade �tg�rder
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        Finally
            Cursor.Current = Cursors.Default

        End Try
    End Sub

    Private Function mblnValidate(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Validering.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att validera indata per lngStep
            Select Case lngStep
                Case Else
            End Select
            '<SLUT ANPASSA KOD>

            Return True

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Private Sub mCreateGroupBoxCollections()
        '******************************************************************************************
        ' Beskrivning: Skapar kontrollarrayer av grpStep och grpInstruction.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'L�gg till alla grpStep och grpInstruction till respektive kollektioner
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mSetInstructionLabels()
        '******************************************************************************************
        ' Beskrivning: S�tter texterna f�r lblInstruction.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'S�tt instruktionstexter till varje steg
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mSetVariables(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: S�tter variabler och kontroller.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av: 
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'S�tt variabel- och kontrollv�rden per lngStep
            Select Case lngStep
                Case STEP_START 's�tt kontroller f�r steg 1

                Case Else
            End Select
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Sub
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner
#End Region

End Class
