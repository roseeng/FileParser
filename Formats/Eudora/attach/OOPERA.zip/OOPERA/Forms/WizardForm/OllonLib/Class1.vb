Public Class Class1
    Shared Sub Main()
        Dim frm As New Form1(New Object(), "Nisse")
    End Sub
End Class
