'**************************************************************************************************
' <'WIZARDNAME'> AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Visual Studio .NET AddIn Wizard Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("<'WIZARDNAME'>")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("<'COMPANYNAME'>")> 
<Assembly: AssemblyProduct("<'PRODUCTNAME'>")> 
<Assembly: AssemblyCopyright("Copyright �2002 <'COMPANYNAME'>")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("33410FA9-1A03-4749-8938-4EA65B397F84")> 
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyKeyFile("..\\..\\<'WIZARDNAME'>.snk")> 
