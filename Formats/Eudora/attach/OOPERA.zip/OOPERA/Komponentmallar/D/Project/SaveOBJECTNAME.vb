'**************************************************************************************************
' <'COMPONENTNAME'>D Save<'OBJECTNAME'> Class:
' Klass som fungerar som sparande datatj�nst f�r objekt.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.Data.SqlClient
Imports System.EnterpriseServices
Imports System.Xml

<JustInTimeActivation(True)> Public Class Save<'OBJECTNAME'>
    Inherits OOPERA.Architecture.DLayer.Save

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Placera egna variabler h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r ej modifieras
    Public Overrides Sub Save(ByVal XMLString As String)
        '******************************************************************************************
        ' Beskrivning: Sparar data.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            MyClass.pExecute("<'SYSTEMNAME'>", "<'OBJECTNAME'>", XMLString)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r modifieras internt
    Protected Overrides Sub pDelete(ByVal objXmlElement As XmlElement)
        '******************************************************************************************
        ' Beskrivning: Sparar data.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strSQL As String

        Try
            '<START ANPASSA KOD>
            'Implementera SQL eller Query 
            If True Then
                With objXmlElement.Attributes
                    strSQL = "DELETE..."
                End With

                MyClass.pobjCommand.CommandText = strSQL
                MyClass.pobjCommand.CommandType = CommandType.Text
            Else
                With objXmlElement.Attributes
                    mCreateDeleteParameters(.GetNamedItem("Id").Value)
                End With

                MyClass.pobjCommand.CommandText = "Procedurnamn"
                MyClass.pobjCommand.CommandType = CommandType.StoredProcedure
            End If
            '<SLUT ANPASSA KOD>

            MyClass.pobjCommand.ExecuteNonQuery()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Protected Overrides Sub pInsert(ByVal objXmlElement As XmlElement)
        '******************************************************************************************
        ' Beskrivning: Sparar data.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strSQL As String

        Try
            '<START ANPASSA KOD>
            'Implementera SQL eller Query 
            If True Then
                With objXmlElement.Attributes
                    strSQL = "INSERT..."
                End With

                MyClass.pobjCommand.CommandText = strSQL
                MyClass.pobjCommand.CommandType = CommandType.Text
            Else
                With objXmlElement.Attributes
                    mCreateInsertParameters(.GetNamedItem("?").Value)
                End With

                MyClass.pobjCommand.CommandText = "Procedurnamn"
                MyClass.pobjCommand.CommandType = CommandType.StoredProcedure
            End If
            '<SLUT ANPASSA KOD>

            MyClass.pobjCommand.ExecuteNonQuery()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Protected Overrides Sub pUpdate(ByVal objXmlElement As XmlElement)
        '******************************************************************************************
        ' Beskrivning: Sparar data.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim strSQL As String

        Try
            '<START ANPASSA KOD>
            'Implementera SQL eller Query 
            If True Then
                With objXmlElement.Attributes
                    strSQL = "UPDATE..."
                End With

                MyClass.pobjCommand.CommandText = strSQL
                MyClass.pobjCommand.CommandType = CommandType.Text
            Else
                With objXmlElement.Attributes
                    mCreateUpdateParameters(.GetNamedItem("?").Value)
                End With

                MyClass.pobjCommand.CommandText = "Procedurnamn"
                MyClass.pobjCommand.CommandType = CommandType.StoredProcedure
            End If
            '<SLUT ANPASSA KOD>

            MyClass.pobjCommand.ExecuteNonQuery()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mCreateDeleteParameters(ByVal strValue1 As String)
        '******************************************************************************************
        ' Beskrivning: Skapar parametrar och s�tter dess v�rden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            With MyBase.pobjCommand.Parameters
                .Clear()

                '<START ANPASSA KOD>
                'Skapa Id parameter
                .Add("Id", strValue1)
                '<SLUT ANPASSA KOD>
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mCreateInsertParameters(ByVal strValue1 As String)
        '******************************************************************************************
        ' Beskrivning: Skapar parametrar och s�tter dess v�rden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            With MyBase.pobjCommand.Parameters
                .Clear()

                '<START ANPASSA KOD>
                'Skapa insert parametrar
                .Add("?", strValue1)
                '<SLUT ANPASSA KOD>
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mCreateUpdateParameters(ByVal strValue1 As String)
        '******************************************************************************************
        ' Beskrivning: Skapar parametrar och s�tter dess v�rden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            With MyBase.pobjCommand.Parameters
                .Clear()

                '<START ANPASSA KOD>
                'Skapa update parametrar
                .Add("?", strValue1)
                '<SLUT ANPASSA KOD>
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner
#End Region

End Class
