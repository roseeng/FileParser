'**************************************************************************************************
' <'SYSTEMNAME'>K AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************

Imports System.EnterpriseServices
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("<'SYSTEMNAME'>.<'SYSTEMNAME'>K")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("<'SYSTEMNAME'>")> 
<Assembly: AssemblyCopyright("Copyright �YYYY OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("24E0A31C-84B4-4A58-98C2-FFABD15E7245")>  'GuidGen /HB
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: ApplicationActivation(ActivationOption.Server)> 
<Assembly: ApplicationID("878595F5-572C-4513-8094-24B4EE7B2AB7")>  'GuidGen /HB
<Assembly: ApplicationName("<'SYSTEMNAME'>")> 
<Assembly: Description("Applikation f�r <'SYSTEMNAME'>")> 
<Assembly: AssemblyKeyFile("../../<'SYSTEMNAME'>.<'COMPONENTNAME'>D.snk")> 
