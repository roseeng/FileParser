'**************************************************************************************************
' <'SYSTEMNAME'>K <'USECASENAME'> Class:
' Klass f�r anv�ndningsfall.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.EnterpriseServices

<JustInTimeActivation(True)> Public Class <'USECASENAME'>
    Inherits OOPERA.Architecture.KLayer.UseCase

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Placera egna variabler h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r ej modifieras
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner

    '<START ANPASSA KOD>
    'Implementera de h�ndelser som utg�r systemets del av anv�ndningsfallets fl�de
    Public Function Handelsenamn1(ByVal Parameternamn1 As String) As String
        '******************************************************************************************
        ' Beskrivning: Utf�r en av systemets delar av anv�ndningsfallet.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return ""

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
    '<SLUT ANPASSA KOD>
#End Region

End Class
