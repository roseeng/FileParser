'**************************************************************************************************
' Support AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("OOPERA.Support")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("OOPERA Support")> 
<Assembly: AssemblyCopyright("Copyright �2002 OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("48761885-3E6D-418F-85EF-C60651A98B68")> 
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyKeyFile("../../OOPERA.Support.snk")> 
