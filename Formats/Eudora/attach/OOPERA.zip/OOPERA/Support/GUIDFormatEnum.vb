'**************************************************************************************************
' Support GUIDFormat Enum:
' Enum f�r komponenten.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg 
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum GUIDFormatEnum
    gfFormat32
    gfFormat36
    gfFormat38
    gfRegistry
End Enum
