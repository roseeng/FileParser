'**************************************************************************************************
' Support GUIDGenerator Class:
' Klass som genererar GUIDs.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public Class GUIDGenerator

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overloads Function CreateGUID() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar ett GUID.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return "{" & System.Guid.NewGuid().ToString() & "}"

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function CreateGUID(ByVal Format As Support.GUIDFormatEnum) As String
        '******************************************************************************************
        ' Beskrivning: Returnerar ett GUID.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Format = GUIDFormatEnum.gfFormat38 Or Format = GUIDFormatEnum.gfRegistry Then
                Return "{" & System.Guid.NewGuid().ToString() & "}"
            ElseIf Format = GUIDFormatEnum.gfFormat32 Then
                Return Replace(System.Guid.NewGuid().ToString(), "-", "")
            Else 'GUIDFormatEnum.gfFormat36 
                Return System.Guid.NewGuid().ToString()
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
