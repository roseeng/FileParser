'**************************************************************************************************
' Support SaveDataFormatter Class:
' Klass som l�gger till SaveStatus i datakollektion inf�r sparande till datak�lla.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg     !!Regelverket �r inte rikigt klart men interfacet �r det!!
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.Xml

Public Class SaveDataFormatter

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjXMLDocument As New XmlDocument()
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public ReadOnly Property XML()
        '******************************************************************************************
        ' Beskrivning: Returnerar XML.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                XML = mobjXMLDocument.OuterXml

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub LoadXML(ByVal XML As String)
        '******************************************************************************************
        ' Beskrivning: Laddar XML.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjXMLDocument.LoadXml(XML)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub FormatData(ByVal SaveStatus As Support.SaveStatusEnum)
        '******************************************************************************************
        ' Beskrivning: Formaterar datakollektionen.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'g�r saker med mobj...
            Select Case SaveStatus
                Case SaveStatusEnum.ssDelete
                Case SaveStatusEnum.ssInsert
                    mFormatInsert(mobjXMLDocument.DocumentElement, True)
                Case SaveStatusEnum.ssNone
                Case SaveStatusEnum.ssUpdate
                Case Else
            End Select

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Sub mFormatInsert(ByVal objXmlElement As XmlElement, ByVal blnIsCollection As Boolean)
        '******************************************************************************************
        ' Beskrivning: Formaterar datakollektionen f�r Insert. Antar Collection/Object/Col../Obj...     !!!Rekursionen ej testad
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLElementChild As XmlElement
        Dim objXMLAttribute As XmlAttribute
        Dim blnSaveStatusSet As Boolean

        Try
            For Each objXMLElementChild In objXmlElement.ChildNodes
                blnSaveStatusSet = False

                If blnIsCollection Then 'objXMLElementChild �r ett objekt
                    For Each objXMLAttribute In objXMLElementChild.Attributes
                        If objXMLAttribute.Name = "SaveStatus" Then 's�tt savestatus
                            objXMLAttribute.Value = CType(SaveStatusEnum.ssInsert, String)

                            blnSaveStatusSet = True

                            Exit For
                        End If
                    Next
                    If Not blnSaveStatusSet Then 'skapa savestatus 
                        objXMLAttribute = mobjXMLDocument.CreateAttribute("SaveStatus")
                        objXMLAttribute.Value = CType(SaveStatusEnum.ssInsert, String)

                        objXMLElementChild.Attributes.Append(objXMLAttribute)
                    End If
                End If

                'rekursivt genom tr�det
                mFormatInsert(objXMLElementChild, Not blnIsCollection)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
