'**************************************************************************************************
' Support SaveStatus Enum:
' Enum f�r komponenten.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg 
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum SaveStatusEnum
    ssNone
    ssInsert
    ssUpdate
    ssDelete
End Enum
