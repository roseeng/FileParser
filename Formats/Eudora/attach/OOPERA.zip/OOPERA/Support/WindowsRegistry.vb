'**************************************************************************************************
' Support WindowsRegistry Class:
' Klass som hanterar gr�nssnittet mot Windows registry.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg     !!Detta �r endast liten del av gr�nssnittet med l�tsasimplementation!! INTE POEs riktiga grejor!! Det finns en liknande klass i .net som jag inte granskat �nnu. Det �r mycket m�jligt att den kapslas 100%
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.Xml

Public Class WindowsRegistry

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Function GetValue(ByVal Path As String, ByVal ValueName As String, ByVal DefaultValue As String, ByVal Hive As Support.WindowsRegistryHiveEnum) As String
        '******************************************************************************************
        ' Beskrivning: Gets a value from the Registry under the Hive key.
        ' Skapad.....: 2000-05-15 Av: Per-Ola Eneroth               HB har pillat!!
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim vRetVal As Object

        Try
            'Select Case Hive
            '    Case RegistryHiveEnum.rhCurrentUser
            '        vRetVal = mvntGetRegValue(HKEY_CURRENT_USER, Path, ValueName, REG_SZ)
            '        Return IIf(IsNull(vRetVal), DefaultValue, vRetVal)
            '    Case RegistryHiveEnum.rhLocalMachine
            '        vRetVal = mvntGetRegValue(HKEY_LOCAL_MACHINE, Path, ValueName, REG_SZ)
            '        Return IIf(IsNull(vRetVal), DefaultValue, vRetVal)
            '    Case Else
            'End Select

            'tillf�lligt()
            Return Leksaksfunktion(Path, ValueName, DefaultValue, Hive)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function Leksaksfunktion(ByVal Path As String, ByVal ValueName As String, ByVal DefaultValue As String, ByVal Hive As Support.WindowsRegistryHiveEnum) As String
        '******************************************************************************************
        ' Beskrivning: Gets a value from the Registry under the Hive key.
        ' Skapad.....: 2000-05-15 Av: Per-Ola Eneroth               HB har pillat!!
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement
        Dim strTemp As String

        Try
            objXMLDocument.Load("C:\Temp\My Documents\Visual Studio Projects\OOPERA\Support\ConnectionString.xml")

            For Each objXMLElement In objXMLDocument.SelectNodes("/ConnectionString")
                strTemp = objXMLElement.Attributes.GetNamedItem(ValueName).Value()
            Next

            Return strTemp

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
