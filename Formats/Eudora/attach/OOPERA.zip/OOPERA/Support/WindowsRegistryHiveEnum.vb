'**************************************************************************************************
' Support WindowsRegistryHive Enum:
' Enum f�r komponenten.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg 
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum WindowsRegistryHiveEnum
    rhLocalMachine
    rhCurrentUser
End Enum
