'**************************************************************************************************
' WinConsole About Form:
' Visar applikations- och systeminformation.
'**************************************************************************************************
' Skapad: YYYY-MM-DD Av: VB About form mall VB6 (n�got modifierad)
' Skapad: 2002-02-29 Av: H�kan Borg     SysInfo fungerar inte med .NET, funkar under 2000? Vet ej.
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Friend Class AboutForm
    Inherits System.Windows.Forms.Form

#Region "* * * K O N S T A N T E R * * *"
    ' Reg Key Security Options...
    Private Const READ_CONTROL = &H20000
    Private Const KEY_QUERY_VALUE = &H1
    Private Const KEY_SET_VALUE = &H2
    Private Const KEY_CREATE_SUB_KEY = &H4
    Private Const KEY_ENUMERATE_SUB_KEYS = &H8
    Private Const KEY_NOTIFY = &H10
    Private Const KEY_CREATE_LINK = &H20
    Private Const KEY_ALL_ACCESS = KEY_QUERY_VALUE + KEY_SET_VALUE + _
                           KEY_CREATE_SUB_KEY + KEY_ENUMERATE_SUB_KEYS + _
                           KEY_NOTIFY + KEY_CREATE_LINK + READ_CONTROL

    ' Reg Key ROOT Types...
    Private Const HKEY_LOCAL_MACHINE = &H80000002
    Private Const ERROR_SUCCESS = 0
    Private Const REG_SZ = 1                         ' Unicode nul terminated string
    Private Const REG_DWORD = 4                      ' 32-bit number

    'Detta kan man ju fundera p� om det fortfarande g�ller....HB 
    Private Const gREGKEYSYSINFOLOC = "SOFTWARE\Microsoft\Shared Tools Location"
    Private Const gREGVALSYSINFOLOC = "MSINFO"
    Private Const gREGKEYSYSINFO = "SOFTWARE\Microsoft\Shared Tools\MSINFO"
    Private Const gREGVALSYSINFO = "PATH"
#End Region

#Region "* * * D E C L A R E S * * *"
    Private Declare Function RegOpenKeyEx Lib "advapi32" Alias "RegOpenKeyExA" (ByVal hKey As Long, ByVal lpSubKey As String, ByVal ulOptions As Long, ByVal samDesired As Long, ByRef phkResult As Long) As Long
    Private Declare Function RegQueryValueEx Lib "advapi32" Alias "RegQueryValueExA" (ByVal hKey As Long, ByVal lpValueName As String, ByVal lpReserved As Long, ByRef lpType As Long, ByVal lpData As String, ByRef lpcbData As Long) As Long
    Private Declare Function RegCloseKey Lib "advapi32" (ByVal hKey As Long) As Long
#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjSystemInfo As SystemInfo
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property SystemInfo() As SystemInfo
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjSystemInfo

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As SystemInfo)
            Try
                mobjSystemInfo = Value

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property
#End Region

#Region "* * * E V E N T S * * *"
    Private Sub cmdOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Me.Close()
    End Sub

    Private Sub cmdSysInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSysInfo.Click
        StartSysInfo()
    End Sub

    Private Sub AboutForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objPen As Pen
        Dim objGraphics As Graphics = Me.CreateGraphics()

        Try
            objPen = New Pen(Color.DarkGray, 1)
            objGraphics.DrawLine(objPen, 6, 163, 377, 163)

            objPen = New Pen(Color.DarkGray, 1)
            objGraphics.DrawLine(objPen, 7, 164, 377, 164)

            If Not mobjSystemInfo.Icon Is Nothing Then
                Me.Icon = mobjSystemInfo.Icon
                picIcon.Image = mobjSystemInfo.Icon.ToBitmap()
            End If

            Me.Text = "Om " & mobjSystemInfo.SystemName
            lblVersion.Text = "Version " & IIf(mobjSystemInfo.Version = "", "Information saknas", mobjSystemInfo.Version)
            lblTitle.Text = mobjSystemInfo.Release
            lblDescription.Text = mobjSystemInfo.Description
            'HB Fixa App        lblDisclaimer.Text = IIf(mobjSystemInfo.Version = "", App.Comments, mobjSystemInfo.Comments)

        Catch objException As Exception
            'HB f�rra versionen gjorde err.clear

        End Try
    End Sub
#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub StartSysInfo()
        On Error GoTo SysInfoErr

        Dim rc As Long
        Dim SysInfoPath As String

        ' Try To Get System Info Program Path\Name From Registry...
        If GetKeyValue(HKEY_LOCAL_MACHINE, gREGKEYSYSINFO, gREGVALSYSINFO, SysInfoPath) Then
            ' Try To Get System Info Program Path Only From Registry...
        ElseIf GetKeyValue(HKEY_LOCAL_MACHINE, gREGKEYSYSINFOLOC, gREGVALSYSINFOLOC, SysInfoPath) Then
            ' Validate Existance Of Known 32 Bit File Version
            If (Dir(SysInfoPath & "\MSINFO32.EXE") <> "") Then
                SysInfoPath = SysInfoPath & "\MSINFO32.EXE"

                ' Error - File Can Not Be Found...
            Else
                GoTo SysInfoErr
            End If
            ' Error - Registry Entry Can Not Be Found...
        Else
            GoTo SysInfoErr
        End If

        Call Shell(SysInfoPath, vbNormalFocus)

        Exit Sub
SysInfoErr:
        MsgBox("Systeminformationen �r otillg�nglig.", vbOKOnly)
    End Sub

    Public Function GetKeyValue(ByVal KeyRoot As Long, ByVal KeyName As String, ByVal SubKeyRef As String, ByRef KeyVal As String) As Boolean
        Dim i As Long                                           ' Loop Counter
        Dim rc As Long                                          ' Return Code
        Dim hKey As Long                                        ' Handle To An Open Registry Key
        Dim hDepth As Long                                      '
        Dim KeyValType As Long                                  ' Data Type Of A Registry Key
        'HB Dim tmpVal As String                                    ' Tempory Storage For A Registry Key Value
        Dim tmpVal As New String(vbNullString, 1024)
        Dim KeyValSize As Long                                  ' Size Of Registry Key Variable
        '------------------------------------------------------------
        ' Open RegKey Under KeyRoot {HKEY_LOCAL_MACHINE...}
        '------------------------------------------------------------
        rc = RegOpenKeyEx(KeyRoot, KeyName, 0, KEY_ALL_ACCESS, hKey) ' Open Registry Key

        If (rc <> ERROR_SUCCESS) Then GoTo GetKeyError ' Handle Error...

        'HB tmpVal = String$(1024, 0)                             ' Allocate Variable Space
        KeyValSize = 1024                                       ' Mark Variable Size

        '------------------------------------------------------------
        ' Retrieve Registry Key Value...
        '------------------------------------------------------------
        rc = RegQueryValueEx(hKey, SubKeyRef, 0, _
                             KeyValType, tmpVal, KeyValSize)    ' Get/Create Key Value

        If (rc <> ERROR_SUCCESS) Then GoTo GetKeyError ' Handle Errors

        If (Asc(Mid(tmpVal, KeyValSize, 1)) = 0) Then           ' Win95 Adds Null Terminated String...
            'HB tmpVal = Left(tmpVal, KeyValSize - 1)               ' Null Found, Extract From String
            tmpVal = tmpVal.Substring(1, KeyValSize - 1)
        Else                                                    ' WinNT Does NOT Null Terminate String...
            'HB tmpVal = Left(tmpVal, KeyValSize)                   ' Null Not Found, Extract String Only
            tmpVal = tmpVal.Substring(1, KeyValSize)
        End If
        '------------------------------------------------------------
        ' Determine Key Value Type For Conversion...
        '------------------------------------------------------------
        Select Case KeyValType                                  ' Search Data Types...
            Case REG_SZ                                             ' String Registry Key Data Type
                KeyVal = tmpVal                                     ' Copy String Value
            Case REG_DWORD                                          ' Double Word Registry Key Data Type
                For i = Len(tmpVal) To 1 Step -1                    ' Convert Each Bit
                    KeyVal = KeyVal + Hex(Asc(Mid(tmpVal, i, 1)))   ' Build Value Char. By Char.
                Next
                KeyVal = Format$("&h" + KeyVal)                     ' Convert Double Word To String
        End Select

        GetKeyValue = True                                      ' Return Success
        rc = RegCloseKey(hKey)                                  ' Close Registry Key
        Exit Function                                           ' Exit

GetKeyError:  ' Cleanup After An Error Has Occured...
        KeyVal = ""                                             ' Set Return Val To Empty String
        GetKeyValue = False                                     ' Return Failure
        rc = RegCloseKey(hKey)                                  ' Close Registry Key
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"

#End Region

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents picIcon As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblDisclaimer As System.Windows.Forms.Label
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cmdSysInfo As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.picIcon = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblDisclaimer = New System.Windows.Forms.Label()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmdSysInfo = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'picIcon
        '
        Me.picIcon.Location = New System.Drawing.Point(16, 16)
        Me.picIcon.Name = "picIcon"
        Me.picIcon.Size = New System.Drawing.Size(32, 32)
        Me.picIcon.TabIndex = 0
        Me.picIcon.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.Location = New System.Drawing.Point(70, 16)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(259, 32)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Application Title"
        '
        'lblVersion
        '
        Me.lblVersion.Location = New System.Drawing.Point(70, 52)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(259, 15)
        Me.lblVersion.TabIndex = 2
        Me.lblVersion.Text = "Version"
        '
        'lblDescription
        '
        Me.lblDescription.Location = New System.Drawing.Point(70, 75)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(259, 78)
        Me.lblDescription.TabIndex = 3
        Me.lblDescription.Text = "Description"
        '
        'lblDisclaimer
        '
        Me.lblDisclaimer.Location = New System.Drawing.Point(16, 175)
        Me.lblDisclaimer.Name = "lblDisclaimer"
        Me.lblDisclaimer.Size = New System.Drawing.Size(259, 55)
        Me.lblDisclaimer.TabIndex = 4
        Me.lblDisclaimer.Text = "Disclaimer"
        '
        'cmdOK
        '
        Me.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdOK.Location = New System.Drawing.Point(286, 175)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(84, 23)
        Me.cmdOK.TabIndex = 5
        Me.cmdOK.Text = "OK"
        '
        'cmdSysInfo
        '
        Me.cmdSysInfo.Location = New System.Drawing.Point(286, 206)
        Me.cmdSysInfo.Name = "cmdSysInfo"
        Me.cmdSysInfo.Size = New System.Drawing.Size(84, 23)
        Me.cmdSysInfo.TabIndex = 6
        Me.cmdSysInfo.Text = "&System Info..."
        '
        'frmAbout
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(382, 237)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdSysInfo, Me.cmdOK, Me.lblDisclaimer, Me.lblDescription, Me.lblVersion, Me.lblTitle, Me.picIcon})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmAbout"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "About"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
