'**************************************************************************************************
' WinConsole Application Class:
' Klass som startar WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.Drawing

Public Class Application

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private WithEvents mfrm As ConsoleForm
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * E V E N T S * * *"
    Public Event Terminate(ByVal sender As Object, ByVal e As System.EventArgs)

    Private Sub mfrm_Terminate(ByVal sender As Object, ByVal e As System.EventArgs) Handles mfrm.Terminate
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mfrm = Nothing

            RaiseEvent Terminate(Me, e)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    'Public Sub Start(ByVal Icon As MSComctlLib.IImage, ByVal Title As String, ByVal Major As String, ByVal Minor As String, ByVal Revision As String, ByVal Comments As String, ByVal LegalCopyright As String, ByVal FileDescription As String, ByVal ProductName As String, ByVal HelpFile As String)
    'Public Sub Start(ByVal Icon As System.Windows.Forms.ImageListxxxxxxxxxxxx, ByVal Title As String, ByVal Major As String, ByVal Minor As String, ByVal Revision As String, ByVal Comments As String, ByVal LegalCopyright As String, ByVal FileDescription As String, ByVal ProductName As String, ByVal HelpFile As String)
    Public Sub Start(ByVal Icon As System.Drawing.Icon, ByVal Title As String, ByVal Major As String, ByVal Minor As String, ByVal Revision As String, ByVal Comments As String, ByVal LegalCopyright As String, ByVal FileDescription As String, ByVal ProductName As String, ByVal HelpFile As String)
        '******************************************************************************************
        ' Beskrivning: Initierar de visuella delarna av WinConsole.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSystemInfo As SystemInfo

        Try
            objSystemInfo = New SystemInfo()

            With objSystemInfo
                .Comments = Comments
                .FileDescription = FileDescription
                .Icon = Icon
                .LegalCopyright = LegalCopyright
                .Major = Major
                .Minor = Minor
                .Revision = Revision
                .Title = Title
                .HelpFile = HelpFile
                .ProductName = ProductName
            End With

            mfrm = New ConsoleForm()

            mfrm.SystemInfo = objSystemInfo

            mfrm.Show()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
