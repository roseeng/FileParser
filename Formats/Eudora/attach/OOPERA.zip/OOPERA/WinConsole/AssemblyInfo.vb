'**************************************************************************************************
' WinConsole AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("OOPERA.WinConsole")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("OOPERA WinConsole")> 
<Assembly: AssemblyCopyright("Copyright �2002 OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("F80DA048-A220-4961-9ADD-C2C3D9FCDDD0")> 
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyKeyFile("../../OOPERA.WinConsole.snk")> 
