'**************************************************************************************************
' WinConsole ConsoleForm Form:
' Applikationens huvudformul�r.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports OOPERA.ExceptionViewer
Imports OOPERA.WinControls.TreeList
Imports System.Xml

Friend Class ConsoleForm
    Inherits System.Windows.Forms.Form

#Region "* * * K O N S T A N T E R * * *"
    'Toolbar
    Private Const TOOLBAR_NEW As Integer = 0
    Private Const TOOLBAR_OPEN As Integer = 1
    Private Const TOOLBAR_DELETE As Integer = 2
    Private Const TOOLBAR_SEP1 As Integer = 3
    Private Const TOOLBAR_PRINT As Integer = 4
    Private Const TOOLBAR_PREVIEW As Integer = 5
    Private Const TOOLBAR_SEP2 As Integer = 6
    Private Const TOOLBAR_CUT As Integer = 7
    Private Const TOOLBAR_COPY As Integer = 8
    Private Const TOOLBAR_PASTE As Integer = 9
    Private Const TOOLBAR_SEP3 As Integer = 10
    Private Const TOOLBAR_SEARCH As Integer = 11
    Private Const TOOLBAR_SEP4 As Integer = 12
    Private Const TOOLBAR_ICON As Integer = 13
    Private Const TOOLBAR_SMALLICON As Integer = 14
    Private Const TOOLBAR_LIST As Integer = 15
    Private Const TOOLBAR_REPORT As Integer = 16
    Private Const TOOLBAR_SEP5 As Integer = 17
    Private Const TOOLBAR_CONTENT As Integer = 18

    'Tree Context
    Private Const CONTEXT_TREE_SHOW As Integer = 0
    Private Const CONTEXT_TREE_SEP1 As Integer = 1
    Private Const CONTEXT_TREE_SEARCH As Integer = 2
    Private Const CONTEXT_TREE_ADD As Integer = 3
    Private Const CONTEXT_TREE_EDIT As Integer = 4
    Private Const CONTEXT_TREE_DELETE As Integer = 5
    Private Const CONTEXT_TREE_REFRESH As Integer = 6
    Private Const CONTEXT_TREE_SEP2 As Integer = 7
    Private Const CONTEXT_TREE_PRINT As Integer = 8
    Private Const CONTEXT_TREE_PREVIEW As Integer = 9
    Private Const CONTEXT_TREE_SEP3 As Integer = 10
    Private Const CONTEXT_TREE_CUT As Integer = 11
    Private Const CONTEXT_TREE_COPY As Integer = 12
    Private Const CONTEXT_TREE_PASTE As Integer = 13
    Private Const CONTEXT_TREE_CONTEXT_SEPARATOR As Integer = 14

    'List Context
    Private Const CONTEXT_LIST_EDIT As Integer = 0
    Private Const CONTEXT_LIST_SEP1 As Integer = 1
    Private Const CONTEXT_LIST_ADD As Integer = 2
    Private Const CONTEXT_LIST_DELETE As Integer = 3
    Private Const CONTEXT_LIST_SEP2 As Integer = 4
    Private Const CONTEXT_LIST_PRINT As Integer = 5
    Private Const CONTEXT_LIST_PREVIEW As Integer = 6
    Private Const CONTEXT_LIST_SEP3 As Integer = 7
    Private Const CONTEXT_LIST_CUT As Integer = 8
    Private Const CONTEXT_LIST_COPY As Integer = 9
    Private Const CONTEXT_LIST_PASTE As Integer = 10
    Private Const CONTEXT_LIST_CONTEXT_SEPARATOR As Integer = 11
#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler
    Private mobjViewer As Viewer

    Private mobjSystemInfo As New SystemInfo()

    Private mstrStateXML As String 'H�ller alla noders motsvarande Tobjekt

    Private mcolExternalApplication As New Collection() 'H�ller alla externa applikationer         ???????
    Private mcolComponent As New Collection() 'H�ller alla instanser av applikationskomponenterna tex AppG.XObject

    Private menmCollectedMenus As WinConsole.MethodEnum
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property SystemInfo() As SystemInfo
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjSystemInfo

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As SystemInfo)
            Try
                mobjSystemInfo = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property
#End Region

#Region "* * * E V E N T S * * *"
    Public Event Terminate(ByVal sender As Object, ByVal e As System.EventArgs)

    Private Sub ConsoleForm_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            RaiseEvent Terminate(Me, e)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub ConsoleForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If MessageBox.Show("Vill du avsluta applikationen?", mobjSystemInfo.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                mPerformOnTerminate()
            Else
                e.Cancel = True
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub ConsoleForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Me.Icon = mobjSystemInfo.Icon
            Me.Text = mobjSystemInfo.ProductName

            mConfigureSystem()

            Select Case TreeListControl1.View
                Case RightPaneViewEnum.rpvIcon
                    mnuViewIcon_Click(sender, e)
                Case RightPaneViewEnum.rpvSmallIcon
                    mnuViewSmallIcon_Click(sender, e)
                Case RightPaneViewEnum.rpvList
                    mnuViewList_Click(sender, e)
                Case RightPaneViewEnum.rpvDetails
                    mnuViewReport_Click(sender, e)
                Case Else
            End Select

            mCreateMenus()

            Me.Show()

            mPerformOnInitialize()

            'lite l�tsasdata
            TreeListControl1.ColumnHeaders.Add("Rubbad", 123, HorizontalAlignmentEnum.haLeft)
            TreeListControl1.ListItems.Add("gr�tboll").Tag = "El Sistema de Test/Mallar"

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_ListClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeListControl1.ListClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mCreateMenus()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_ListDoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeListControl1.ListDoubleClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mCreateMenus()

            'Default metod
            TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_EDIT))

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_ListItemMenuClick(ByVal sender As Object, ByVal e As OOPERA.WinControls.TreeList.TreeListMenuEventArgs) Handles TreeListControl1.ListItemMenuClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case e.Index
                Case CONTEXT_LIST_ADD
                    mRLVLaggTill(TreeListControl1.SelectedNode)
                Case CONTEXT_LIST_DELETE
                    mRLVTaBort(TreeListControl1.SelectedListItems)
                Case CONTEXT_LIST_EDIT
                    mRLVOppna(TreeListControl1.SelectedListItems)
                Case CONTEXT_LIST_PRINT
                    mRLVSkrivUt(TreeListControl1.SelectedListItems)
                Case CONTEXT_LIST_PREVIEW
                    mRLVForhandsgranska(TreeListControl1.SelectedListItems)
                Case CONTEXT_LIST_CUT
                    mRLVKlippUt(TreeListControl1.SelectedListItems)
                Case CONTEXT_LIST_COPY
                    mRLVKopiera(TreeListControl1.SelectedListItems)
                Case CONTEXT_LIST_PASTE
                    mRLVKlistraIn(TreeListControl1.SelectedNode)
                Case Else
                    mExecuteListContextMenu(TreeListControl1.SelectedListItems, e.Index - CONTEXT_LIST_CONTEXT_SEPARATOR)
            End Select

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_NodeMenuClick(ByVal sender As Object, ByVal e As OOPERA.WinControls.TreeList.TreeListMenuEventArgs) Handles TreeListControl1.NodeMenuClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case e.Index
                Case CONTEXT_TREE_ADD
                    mRTVLaggTill(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_DELETE
                    mRTVTaBort(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_EDIT
                    mRTVOppna(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_REFRESH
                    mRTVUppdatera(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_SEARCH
                    mRTVSok(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_SHOW
                    mRTVVisa(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_PRINT
                    mRTVSkrivUt(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_PREVIEW
                    mRTVForhandsgranska(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_CUT
                    mRTVKlippUt(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_COPY
                    mRTVKopiera(TreeListControl1.SelectedNode)
                Case CONTEXT_TREE_PASTE
                    mRTVKlistraIn(TreeListControl1.SelectedNode)
                Case Else
                    mExecuteTreeContextMenu(TreeListControl1.SelectedNode, e.Index - CONTEXT_TREE_CONTEXT_SEPARATOR)
            End Select

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_SpecialKeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TreeListControl1.SpecialKeyUp
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case e.KeyCode
                Case Keys.Delete
                    If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                        TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_DELETE))
                    Else
                        TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_DELETE))
                    End If
                Case Keys.Return
                    If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                        TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_SHOW))
                    Else
                        TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_EDIT))
                    End If
                Case Keys.F1
                    mnuHelpInnehall_Click(Nothing, Nothing)
                Case Keys.F5
                    TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_REFRESH))
                Case Keys.Left, Keys.Up, Keys.Right, Keys.Down, Keys.PageUp, Keys.PageDown
                    TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_SHOW))
                Case Else
            End Select

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_TreeClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeListControl1.TreeClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mCreateMenus()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_TreeDoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeListControl1.TreeDoubleClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mCreateMenus()

            'Default metod
            TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_EDIT))

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub TreeListControl1_TreeMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TreeListControl1.TreeMouseDown
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If e.Button <> MouseButtons.Right Then
                'Default metod...
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_SHOW))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub tbrToolbar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tbrToolbar.ButtonClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case tbrToolbar.Buttons.IndexOf(e.Button)
                Case TOOLBAR_NEW
                    mnuFileNy_Click(sender, e)
                Case TOOLBAR_OPEN
                    mnuFileOppna_Click(sender, e)
                Case TOOLBAR_DELETE
                    mnuFileTaBort_Click(sender, e)
                Case TOOLBAR_PRINT
                    mnuFileSkrivUt_Click(sender, e)
                Case TOOLBAR_PREVIEW
                    mnuFileForhandsgranska_Click(sender, e)
                Case TOOLBAR_CUT
                    mnuEditKlippUt_Click(sender, e)
                Case TOOLBAR_COPY
                    mnuEditKopiera_Click(sender, e)
                Case TOOLBAR_PASTE
                    mnuEditKlistraIn_Click(sender, e)
                Case TOOLBAR_SEARCH
                    mnuToolsSok_Click(sender, e)
                Case TOOLBAR_ICON
                    mnuViewIcon_Click(sender, e)
                Case TOOLBAR_SMALLICON
                    mnuViewSmallIcon_Click(sender, e)
                Case TOOLBAR_LIST
                    mnuViewList_Click(sender, e)
                Case TOOLBAR_REPORT
                    mnuViewReport_Click(sender, e)
                Case TOOLBAR_CONTENT
                    mnuHelpInnehall_Click(sender, e)
            End Select

        Catch objException As Exception
            ' mobjExceptionViewer.Show Err.Number, Err.Source, Err.Description

        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick '1000ms
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            sbrStatusbar.Panels.Item(0).Text = TreeListControl1.ListItems.Count & " objekt"  '" object(s)"
            sbrStatusbar.Panels.Item(1).Text = Now().ToShortDateString
            sbrStatusbar.Panels.Item(2).Text = Now().ToShortTimeString

        Catch objException As Exception
            ' mobjExceptionViewer.Show Err.Number, Err.Source, Err.Description

        End Try
    End Sub

    Private Sub mnuEditKlippUt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditKlippUt.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_CUT))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_CUT))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuEditKlistraIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditKlistraIn.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_PASTE))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_PASTE))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuEditKopiera_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditKopiera.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_COPY))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_COPY))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuFileAvsluta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileAvsluta.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Me.Close()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuFileForhandsgranska_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileForhandsgranska.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_PREVIEW))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_PREVIEW))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuFileNy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileNy.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_ADD))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_ADD))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuFileOppna_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileOppna.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_EDIT))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_EDIT))
            End If

        Catch objException As Exception
            mShowException(objException)
        End Try
    End Sub

    Private Sub mnuFileSkrivUt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSkrivUt.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_PRINT))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_PRINT))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuFileTaBort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileTaBort.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_DELETE))
            Else
                TreeListControl1_ListItemMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_LIST_DELETE))
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuHelp_Click()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuHelpOm.Text = "&Om " & mobjSystemInfo.SystemName & "..."

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuHelpInnehall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpInnehall.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '        cdgHelp.HelpFile = Me.SystemInfo.HelpFile
            '        cdgHelp.HelpCommand = cdgHelpKey
            '        cdgHelp.ShowHelp()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuHelpOm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpOm.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New AboutForm()

        Try
            frm.SystemInfo = mobjSystemInfo
            frm.ShowDialog(Me)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuToolsExternaSystem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsExternaSystem.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icea As IConsoleExternalApplication

        Try
            Icea = mcolExternalApplication(mnuToolsExternaSystem.MenuItems.Item(0).Text) 'Index

            Icea.RunApplication()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuToolsSok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsSok.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_SEARCH))
            Else
                '
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewIcon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewIcon.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuViewIcon.Checked = Not mnuViewIcon.Checked
            mnuViewSmallIcon.Checked = Not mnuViewIcon.Checked
            mnuViewList.Checked = Not mnuViewIcon.Checked
            mnuViewReport.Checked = Not mnuViewIcon.Checked

            With tbrToolbar.Buttons
                .Item(TOOLBAR_ICON).Pushed = True
                .Item(TOOLBAR_SMALLICON).Pushed = False
                .Item(TOOLBAR_LIST).Pushed = False
                .Item(TOOLBAR_REPORT).Pushed = False
            End With

            TreeListControl1.View = RightPaneViewEnum.rpvIcon

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewList.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuViewList.Checked = Not mnuViewList.Checked
            mnuViewIcon.Checked = Not mnuViewList.Checked
            mnuViewSmallIcon.Checked = Not mnuViewList.Checked
            mnuViewReport.Checked = Not mnuViewList.Checked

            With tbrToolbar.Buttons
                .Item(TOOLBAR_ICON).Pushed = False
                .Item(TOOLBAR_SMALLICON).Pushed = False
                .Item(TOOLBAR_LIST).Pushed = True
                .Item(TOOLBAR_REPORT).Pushed = False
            End With

            TreeListControl1.View = RightPaneViewEnum.rpvList

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewReport.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuViewReport.Checked = Not mnuViewReport.Checked
            mnuViewIcon.Checked = Not mnuViewReport.Checked
            mnuViewSmallIcon.Checked = Not mnuViewReport.Checked
            mnuViewList.Checked = Not mnuViewReport.Checked

            With tbrToolbar.Buttons
                .Item(TOOLBAR_ICON).Pushed = False
                .Item(TOOLBAR_SMALLICON).Pushed = False
                .Item(TOOLBAR_LIST).Pushed = False
                .Item(TOOLBAR_REPORT).Pushed = True
            End With

            TreeListControl1.View = RightPaneViewEnum.rpvDetails

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewSmallIcon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewSmallIcon.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuViewSmallIcon.Checked = Not mnuViewSmallIcon.Checked
            mnuViewIcon.Checked = Not mnuViewSmallIcon.Checked
            mnuViewList.Checked = Not mnuViewSmallIcon.Checked
            mnuViewReport.Checked = Not mnuViewSmallIcon.Checked

            With tbrToolbar.Buttons
                .Item(TOOLBAR_ICON).Pushed = False
                .Item(TOOLBAR_SMALLICON).Pushed = True
                .Item(TOOLBAR_LIST).Pushed = False
                .Item(TOOLBAR_REPORT).Pushed = False
            End With

            TreeListControl1.View = RightPaneViewEnum.rpvSmallIcon

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewStatusbar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewStatusbar.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuViewStatusbar.Checked = Not mnuViewStatusbar.Checked
            sbrStatusbar.Visible = mnuViewStatusbar.Checked

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewToolbar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewToolbar.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuViewToolbar.Checked = Not mnuViewToolbar.Checked
            tbrToolbar.Visible = mnuViewToolbar.Checked

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub mnuViewUppdatera_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewUppdatera.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                TreeListControl1_NodeMenuClick(sender, New OOPERA.WinControls.TreeList.TreeListMenuEventArgs(CONTEXT_TREE_REFRESH))
            Else
                '
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"

#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Sub mCollectMenus(ByVal enmMenus As MenuToolbarEnum, ByRef enmCollectedMenus As MenuToolbarEnum)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim lngTemp As Long

        Try
            lngTemp = enmMenus
            If lngTemp - MenuToolbarEnum.mtbRefresh >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbRefresh
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbRefresh
            End If
            If lngTemp - MenuToolbarEnum.mtbSearch >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbSearch
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbSearch
            End If
            If lngTemp - MenuToolbarEnum.mtbPaste >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbPaste
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbPaste
            End If
            If lngTemp - MenuToolbarEnum.mtbCopy >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbCopy
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbCopy
            End If
            If lngTemp - MenuToolbarEnum.mtbCut >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbCut
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbCut
            End If
            If lngTemp - MenuToolbarEnum.mtbPreview >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbPreview
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbPreview
            End If
            If lngTemp - MenuToolbarEnum.mtbPrint >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbPrint
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbPrint
            End If
            If lngTemp - MenuToolbarEnum.mtbDelete >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbDelete
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbDelete
            End If
            If lngTemp - MenuToolbarEnum.mtbOpen >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbOpen
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbOpen
            End If
            If lngTemp - MenuToolbarEnum.mtbAdd >= 0 Then
                lngTemp = lngTemp - MenuToolbarEnum.mtbAdd
                enmCollectedMenus = enmCollectedMenus Or MenuToolbarEnum.mtbAdd
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mCreateMenus()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mInitiateMenus()
            mPrepareMenusAndToolbar(menmCollectedMenus)
            mEnableMenusAndToolbar()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mInitiateMenus()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'Standardalternativ f�r Tree Context
            With TreeListControl1.NodeMenu.MenuItems
                .Clear()

                .Add("Vi&sa").DefaultItem = True
                .Add("-")
                .Add("S�&k...")
                .Add("L�gg till...")
                .Add("&�ppna...")
                .Add("&Ta bort")
                .Add("Uppdate&ra")
                .Add("-")
                .Add("Skriv &ut")
                .Add("F�r&handsgranska")
                .Add("-")
                .Add("&Klipp ut")
                .Add("K&opiera")
                .Add("K&listra in")
            End With

            'Standardalternativ f�r List Context
            With TreeListControl1.ListItemMenu.MenuItems
                .Clear()

                .Add("&�ppna...").DefaultItem = True
                .Add("-")
                .Add("L�&gg till...")
                .Add("&Ta bort")
                .Add("-")
                .Add("Skriv &ut")
                .Add("F�r&handsgranska")
                .Add("-")
                .Add("&Klipp ut")
                .Add("K&opiera")
                .Add("K&listra in")
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareMenusAndToolbar(ByRef enmMenus As MenuToolbarEnum)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mPrepareRLVMenu(enmMenus)
            mPrepareRTVMenu(enmMenus)

            mPrepareEditMenu()
            mPrepareFileMenu()
            mPrepareViewMenu()
            mPrepareToolsMenu()
            mPrepareHelpMenu()

            mPrepareToolbar()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareRTVMenu(ByRef enmMenus As MenuToolbarEnum)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim lngTemp As Long

        Try
            With TreeListControl1.NodeMenu.MenuItems
                lngTemp = enmMenus
                If lngTemp - MenuToolbarEnum.mtbRefresh < 0 Then
                    .Item(CONTEXT_TREE_REFRESH).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbRefresh
                End If
                If lngTemp - MenuToolbarEnum.mtbSearch < 0 Then
                    .Item(CONTEXT_TREE_SEARCH).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbSearch
                End If
                If lngTemp - MenuToolbarEnum.mtbPaste < 0 Then
                    .Item(CONTEXT_TREE_PASTE).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbPaste
                End If
                If lngTemp - MenuToolbarEnum.mtbCopy < 0 Then
                    .Item(CONTEXT_TREE_COPY).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbCopy
                End If
                If lngTemp - MenuToolbarEnum.mtbCut < 0 Then
                    .Item(CONTEXT_TREE_CUT).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbCut
                End If
                If lngTemp - MenuToolbarEnum.mtbPreview < 0 Then
                    .Item(CONTEXT_TREE_PREVIEW).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbPreview
                End If
                If lngTemp - MenuToolbarEnum.mtbPrint < 0 Then
                    .Item(CONTEXT_TREE_PRINT).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbPrint
                End If
                If lngTemp - MenuToolbarEnum.mtbDelete < 0 Then
                    .Item(CONTEXT_TREE_DELETE).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbDelete
                End If
                If lngTemp - MenuToolbarEnum.mtbOpen < 0 Then
                    .Item(CONTEXT_TREE_EDIT).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbOpen
                End If
                If lngTemp - MenuToolbarEnum.mtbAdd < 0 Then
                    .Item(CONTEXT_TREE_ADD).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbAdd
                End If

                If Not .Item(CONTEXT_TREE_ADD).Visible And Not .Item(CONTEXT_TREE_EDIT).Visible And Not .Item(CONTEXT_TREE_DELETE).Visible And Not .Item(CONTEXT_TREE_SEARCH).Visible And Not .Item(CONTEXT_TREE_REFRESH).Visible Then .Item(CONTEXT_TREE_SEP1).Visible = False
                If Not .Item(CONTEXT_TREE_PRINT).Visible And Not .Item(CONTEXT_TREE_PREVIEW).Visible Then .Item(CONTEXT_TREE_SEP2).Visible = False
                If Not .Item(CONTEXT_TREE_CUT).Visible And Not .Item(CONTEXT_TREE_COPY).Visible And Not .Item(CONTEXT_TREE_PASTE).Visible Then .Item(CONTEXT_TREE_SEP3).Visible = False
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareRLVMenu(ByRef enmMenus As MenuToolbarEnum)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim lngTemp As Long

        Try
            With TreeListControl1.ListItemMenu.MenuItems
                lngTemp = enmMenus
                If lngTemp - MenuToolbarEnum.mtbRefresh < 0 Then
                    '.Item(CONTEXT_LIST_REFRESH).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbRefresh
                End If
                If lngTemp - MenuToolbarEnum.mtbSearch < 0 Then
                    '.Item(CONTEXT_LIST_SEARCH).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbSearch
                End If
                If lngTemp - MenuToolbarEnum.mtbPaste < 0 Then
                    .Item(CONTEXT_LIST_PASTE).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbPaste
                End If
                If lngTemp - MenuToolbarEnum.mtbCopy < 0 Then
                    .Item(CONTEXT_LIST_COPY).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbCopy
                End If
                If lngTemp - MenuToolbarEnum.mtbCut < 0 Then
                    .Item(CONTEXT_LIST_CUT).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbCut
                End If
                If lngTemp - MenuToolbarEnum.mtbPreview < 0 Then
                    .Item(CONTEXT_LIST_PREVIEW).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbPreview
                End If
                If lngTemp - MenuToolbarEnum.mtbPrint < 0 Then
                    .Item(CONTEXT_LIST_PRINT).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbPrint
                End If
                If lngTemp - MenuToolbarEnum.mtbDelete < 0 Then
                    .Item(CONTEXT_LIST_DELETE).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbDelete
                End If
                If lngTemp - MenuToolbarEnum.mtbOpen < 0 Then
                    .Item(CONTEXT_LIST_EDIT).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbOpen
                End If
                If lngTemp - MenuToolbarEnum.mtbAdd < 0 Then
                    .Item(CONTEXT_LIST_ADD).Visible = False
                Else
                    lngTemp = lngTemp - MenuToolbarEnum.mtbAdd
                End If

                If Not .Item(CONTEXT_LIST_ADD).Visible And Not .Item(CONTEXT_LIST_DELETE).Visible Then .Item(CONTEXT_LIST_SEP1).Visible = False
                If Not .Item(CONTEXT_LIST_PRINT).Visible And Not .Item(CONTEXT_LIST_PREVIEW).Visible Then .Item(CONTEXT_LIST_SEP2).Visible = False
                If Not .Item(CONTEXT_LIST_CUT).Visible And Not .Item(CONTEXT_LIST_COPY).Visible And Not .Item(CONTEXT_LIST_PASTE).Visible Then .Item(CONTEXT_LIST_SEP3).Visible = False
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareEditMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuEdit.Visible = .Item(CONTEXT_TREE_CUT).Visible Or .Item(CONTEXT_TREE_COPY).Visible Or .Item(CONTEXT_TREE_PASTE).Visible
                    If mnuEdit.Visible Then
                        mnuEditKlippUt.Visible = .Item(CONTEXT_TREE_CUT).Visible
                        mnuEditKlistraIn.Visible = .Item(CONTEXT_TREE_PASTE).Visible
                        mnuEditKopiera.Visible = .Item(CONTEXT_TREE_COPY).Visible
                    End If
                End With
            Else
                With TreeListControl1.ListItemMenu.MenuItems
                    mnuEdit.Visible = .Item(CONTEXT_LIST_CUT).Visible Or .Item(CONTEXT_LIST_COPY).Visible Or .Item(CONTEXT_LIST_PASTE).Visible
                    If mnuEdit.Visible Then
                        mnuEditKlippUt.Visible = .Item(CONTEXT_LIST_CUT).Visible
                        mnuEditKlistraIn.Visible = .Item(CONTEXT_LIST_PASTE).Visible
                        mnuEditKopiera.Visible = .Item(CONTEXT_LIST_COPY).Visible
                    End If
                End With
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareFileMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuFileNy.Visible = .Item(CONTEXT_TREE_ADD).Visible
                    mnuFileOppna.Visible = .Item(CONTEXT_TREE_EDIT).Visible
                    mnuFileTaBort.Visible = .Item(CONTEXT_TREE_DELETE).Visible
                    mnuFileSkrivUt.Visible = .Item(CONTEXT_TREE_PRINT).Visible
                    mnuFileForhandsgranska.Visible = .Item(CONTEXT_TREE_PREVIEW).Visible
                End With
            Else
                With TreeListControl1.ListItemMenu.MenuItems
                    mnuFileNy.Visible = .Item(CONTEXT_LIST_ADD).Visible
                    mnuFileOppna.Visible = .Item(CONTEXT_LIST_EDIT).Visible
                    mnuFileTaBort.Visible = .Item(CONTEXT_LIST_DELETE).Visible
                    mnuFileSkrivUt.Visible = .Item(CONTEXT_LIST_PRINT).Visible
                    mnuFileForhandsgranska.Visible = .Item(CONTEXT_LIST_PREVIEW).Visible
                End With
            End If

            If Not mnuFileNy.Visible And Not mnuFileOppna.Visible And Not mnuFileTaBort.Visible Then mnuFileSep1.Visible = False
            If Not mnuFileSkrivUt.Visible And Not mnuFileForhandsgranska.Visible Then mnuFileSep2.Visible = False

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareHelpMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                mnuHelpInnehall.Enabled = IIf(Me.SystemInfo.HelpFile <> "", True, False)
            Else
                mnuHelpInnehall.Enabled = IIf(Me.SystemInfo.HelpFile <> "", True, False)
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareViewMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuViewUppdatera.Visible = .Item(CONTEXT_TREE_REFRESH).Visible
                End With
            Else
                mnuViewUppdatera.Visible = False
            End If

            If Not mnuViewUppdatera.Visible Then mnuViewSep2.Visible = False

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareToolsMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()
        Dim Icea As IConsoleExternalApplication
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuToolsSok.Visible = .Item(CONTEXT_TREE_SEARCH).Visible
                End With
            Else
                mnuToolsSok.Visible = False
            End If

            If Not mnuToolsSok.Visible Then mnuToolsSep1.Visible = False

            'Externa applikationer
            objXMLDocument.LoadXml(objSupport.ExternalApplications(Me.SystemInfo.SystemName))

            If objXMLDocument.SelectNodes("ExternalApplications/Assembly").Count = 0 Then
                mnuToolsExternaSystem.Visible = False
                'If Not mnuToolsExternaSystem(0).Visible Then mnuToolsSep2.Visible = False
                Exit Sub
            End If

            For Each objXMLElement In objXMLDocument.SelectNodes("ExternalApplications/Assembly")
                Icea = objSupport.CreateObject(objXMLElement.OuterXml)

                mnuToolsExternaSystem.MenuItems.Add(Icea.AssemblyProduct)
                mnuToolsExternaSystem.MenuItems.Item(mnuToolsExternaSystem.MenuItems.Count - 1).Enabled = True

                mcolExternalApplication.Add(Icea, Icea.AssemblyProduct)
            Next 'objXMLElement

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mPrepareToolbar()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            With tbrToolbar.Buttons
                .Item(TOOLBAR_NEW).Visible = mnuFileNy.Visible
                .Item(TOOLBAR_OPEN).Visible = mnuFileOppna.Visible
                .Item(TOOLBAR_DELETE).Visible = mnuFileTaBort.Visible
                .Item(TOOLBAR_PRINT).Visible = mnuFileSkrivUt.Visible
                .Item(TOOLBAR_PREVIEW).Visible = mnuFileForhandsgranska.Visible
                .Item(TOOLBAR_CUT).Visible = IIf(Not mnuEdit.Visible, mnuEdit.Visible, mnuEditKlippUt.Visible)
                .Item(TOOLBAR_COPY).Visible = IIf(Not mnuEdit.Visible, mnuEdit.Visible, mnuEditKopiera.Visible)
                .Item(TOOLBAR_PASTE).Visible = IIf(Not mnuEdit.Visible, mnuEdit.Visible, mnuEditKlistraIn.Visible)
                .Item(TOOLBAR_SEARCH).Visible = mnuToolsSok.Visible
                .Item(TOOLBAR_CONTENT).Visible = mnuHelpInnehall.Visible

                If Not .Item(TOOLBAR_NEW).Visible And Not .Item(TOOLBAR_OPEN).Visible And Not .Item(TOOLBAR_DELETE).Visible Then .Item(TOOLBAR_SEP1).Visible = False
                If Not .Item(TOOLBAR_PRINT).Visible And Not .Item(TOOLBAR_PREVIEW).Visible Then .Item(TOOLBAR_SEP2).Visible = False
                If Not .Item(TOOLBAR_CUT).Visible And Not .Item(TOOLBAR_COPY).Visible And Not .Item(TOOLBAR_PASTE).Visible Then .Item(TOOLBAR_SEP3).Visible = False
                If Not .Item(TOOLBAR_SEARCH).Visible Then .Item(TOOLBAR_SEP4).Visible = False
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableMenusAndToolbar()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mEnableRLVMenu(TreeListControl1.SelectedNode, TreeListControl1.SelectedListItems)
            mEnableRTVMenu(TreeListControl1.SelectedNode)

            mEnableEditMenu()
            mEnableFileMenu()
            mEnableViewMenu()
            mEnableToolsMenu()
            mEnableHelpMenu()

            mEnableToolbar()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableRTVMenu(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icbo As IConsoleBaseObject
        Dim objMenu As New Menu()
        Dim objMenuItem As MenuItem
        Dim objOwnContextSeparator As New MenuItem("-", True, False)

        Try
            If Not objNode Is Nothing Then
                Try
                    Icbo = mcolComponent.Item(objNode.Tag)

                    TreeListControl1.ShowMenus = Icbo.SupportContextMenu

                    If Icbo.SupportContextMenu Then
                        With TreeListControl1.NodeMenu.MenuItems
                            .Item(CONTEXT_TREE_SEP1).Visible = True
                            .Item(CONTEXT_TREE_SEP2).Visible = True
                            .Item(CONTEXT_TREE_SEP3).Visible = True

                            .Item(CONTEXT_TREE_SHOW).Visible = Icbo.GetMethodInfo(MethodEnum.metShow).Supported
                            .Item(CONTEXT_TREE_SEARCH).Visible = Icbo.GetMethodInfo(MethodEnum.metSearch).Supported
                            .Item(CONTEXT_TREE_ADD).Visible = Icbo.GetMethodInfo(MethodEnum.metAdd).Supported
                            .Item(CONTEXT_TREE_EDIT).Visible = Icbo.GetMethodInfo(MethodEnum.metEdit).Supported
                            .Item(CONTEXT_TREE_DELETE).Visible = Icbo.GetMethodInfo(MethodEnum.metDelete).Supported
                            .Item(CONTEXT_TREE_REFRESH).Visible = Icbo.GetMethodInfo(MethodEnum.metRefresh).Supported
                            .Item(CONTEXT_TREE_PRINT).Visible = Icbo.GetMethodInfo(MethodEnum.metPrint).Supported
                            .Item(CONTEXT_TREE_PREVIEW).Visible = Icbo.GetMethodInfo(MethodEnum.metPreview).Supported
                            .Item(CONTEXT_TREE_CUT).Visible = Icbo.GetMethodInfo(MethodEnum.metCut).Supported
                            .Item(CONTEXT_TREE_COPY).Visible = Icbo.GetMethodInfo(MethodEnum.metCopy).Supported
                            .Item(CONTEXT_TREE_PASTE).Visible = Icbo.GetMethodInfo(MethodEnum.metPaste).Supported
                            If Not .Item(CONTEXT_TREE_SEARCH).Visible And Not .Item(CONTEXT_TREE_ADD).Visible And Not .Item(CONTEXT_TREE_EDIT).Visible And Not .Item(CONTEXT_TREE_DELETE).Visible And Not .Item(CONTEXT_TREE_REFRESH).Visible Then .Item(CONTEXT_TREE_SEP1).Visible = False
                            If Not .Item(CONTEXT_TREE_PRINT).Visible And Not .Item(CONTEXT_TREE_PREVIEW).Visible Then .Item(CONTEXT_TREE_SEP2).Visible = False
                            If Not .Item(CONTEXT_TREE_CUT).Visible And Not .Item(CONTEXT_TREE_COPY).Visible And Not .Item(CONTEXT_TREE_PASTE).Visible Then .Item(CONTEXT_TREE_SEP3).Visible = False

                            .Item(CONTEXT_TREE_SHOW).Enabled = Icbo.GetMethodInfo(MethodEnum.metShow).Authorized
                            .Item(CONTEXT_TREE_SEARCH).Enabled = Icbo.GetMethodInfo(MethodEnum.metSearch).Authorized
                            .Item(CONTEXT_TREE_ADD).Enabled = Icbo.GetMethodInfo(MethodEnum.metAdd).Authorized
                            .Item(CONTEXT_TREE_EDIT).Enabled = Icbo.GetMethodInfo(MethodEnum.metEdit).Authorized
                            .Item(CONTEXT_TREE_DELETE).Enabled = Icbo.GetMethodInfo(MethodEnum.metDelete).Authorized
                            .Item(CONTEXT_TREE_REFRESH).Enabled = Icbo.GetMethodInfo(MethodEnum.metRefresh).Authorized
                            .Item(CONTEXT_TREE_PRINT).Enabled = Icbo.GetMethodInfo(MethodEnum.metPrint).Authorized
                            .Item(CONTEXT_TREE_PREVIEW).Enabled = Icbo.GetMethodInfo(MethodEnum.metPreview).Authorized
                            .Item(CONTEXT_TREE_CUT).Enabled = Icbo.GetMethodInfo(MethodEnum.metCut).Authorized
                            .Item(CONTEXT_TREE_COPY).Enabled = Icbo.GetMethodInfo(MethodEnum.metCopy).Authorized
                            .Item(CONTEXT_TREE_PASTE).Enabled = Icbo.GetMethodInfo(MethodEnum.metPaste).Authorized
                        End With
                    End If

                Catch objException As Exception
                    TreeListControl1.ShowMenus = False

                End Try
            End If

            'L�gg till context
            If Not objNode Is Nothing Then
                Try
                    Icbo = mcolComponent.Item(objNode.Tag)

                    Icbo.AddOwnContextMenuItems(objMenu, objNode)

                    If objMenu.MenuItems.Count > 0 Then
                        With TreeListControl1.NodeMenu.MenuItems
                            .Add(objOwnContextSeparator)

                            For Each objMenuItem In objMenu.MenuItems
                                If objMenuItem.Visible Or objOwnContextSeparator.Visible Then objOwnContextSeparator.Visible = True
                                .Add(objMenuItem)
                            Next 'objMenuItem
                        End With
                    End If
                Catch objException As Exception

                End Try
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableRLVMenu(ByVal objNode As Node, ByVal objListItems As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icbo As IConsoleBaseObject
        Dim objListItem As ListItem
        Dim objMenu As New Menu()
        Dim objMenuItem As MenuItem
        Dim objOwnContextSeparator As New MenuItem("-", True, False)

        Try
            With TreeListControl1.ListItemMenu.MenuItems
                .Item(CONTEXT_LIST_SEP1).Visible = True
                .Item(CONTEXT_LIST_SEP2).Visible = True
                .Item(CONTEXT_LIST_SEP3).Visible = True
            End With

            If Not objNode Is Nothing Then
                Try
                    Icbo = mcolComponent.Item(objNode.Tag)

                    With TreeListControl1.ListItemMenu.MenuItems
                        .Item(CONTEXT_LIST_ADD).Visible = Icbo.GetMethodInfo(MethodEnum.metAdd).Supported
                        .Item(CONTEXT_LIST_PASTE).Visible = Icbo.GetMethodInfo(MethodEnum.metPaste).Supported

                        .Item(CONTEXT_LIST_ADD).Enabled = Icbo.GetMethodInfo(MethodEnum.metAdd).Authorized
                        .Item(CONTEXT_LIST_PASTE).Enabled = Icbo.GetMethodInfo(MethodEnum.metPaste).Authorized
                    End With

                Catch objException As Exception
                    With TreeListControl1.ListItemMenu.MenuItems
                        .Item(CONTEXT_LIST_ADD).Visible = False
                        .Item(CONTEXT_LIST_PASTE).Visible = False
                    End With

                End Try
            End If

            If objListItems.Count > 0 Then
                For Each objListItem In objListItems
                    Try
                        Icbo = mcolComponent.Item(mobjNodeFromListItem(objListItem).Tag)

                        With TreeListControl1.ListItemMenu.MenuItems
                            .Item(CONTEXT_LIST_EDIT).Visible = .Item(CONTEXT_LIST_EDIT).Visible And IIf(TreeListControl1.ListItems.Count = 0, False, Icbo.GetMethodInfo(MethodEnum.metEdit).Supported)
                            .Item(CONTEXT_LIST_DELETE).Visible = .Item(CONTEXT_LIST_DELETE).Visible And IIf(TreeListControl1.ListItems.Count = 0, False, Icbo.GetMethodInfo(MethodEnum.metDelete).Supported)
                            .Item(CONTEXT_LIST_PRINT).Visible = .Item(CONTEXT_LIST_PRINT).Visible And Icbo.GetMethodInfo(MethodEnum.metPrint).Supported
                            .Item(CONTEXT_LIST_PREVIEW).Visible = .Item(CONTEXT_LIST_PREVIEW).Visible And Icbo.GetMethodInfo(MethodEnum.metPreview).Supported
                            .Item(CONTEXT_LIST_CUT).Visible = .Item(CONTEXT_LIST_CUT).Visible And Icbo.GetMethodInfo(MethodEnum.metCut).Supported
                            .Item(CONTEXT_LIST_COPY).Visible = .Item(CONTEXT_LIST_COPY).Visible And Icbo.GetMethodInfo(MethodEnum.metCopy).Supported

                            .Item(CONTEXT_LIST_EDIT).Enabled = .Item(CONTEXT_LIST_EDIT).Enabled And Icbo.GetMethodInfo(MethodEnum.metEdit).Authorized
                            .Item(CONTEXT_LIST_DELETE).Enabled = .Item(CONTEXT_LIST_DELETE).Enabled And Icbo.GetMethodInfo(MethodEnum.metDelete).Authorized
                            .Item(CONTEXT_LIST_PRINT).Enabled = .Item(CONTEXT_LIST_PRINT).Enabled And Icbo.GetMethodInfo(MethodEnum.metPrint).Authorized
                            .Item(CONTEXT_LIST_PREVIEW).Enabled = .Item(CONTEXT_LIST_PREVIEW).Enabled And Icbo.GetMethodInfo(MethodEnum.metPreview).Authorized
                            .Item(CONTEXT_LIST_CUT).Enabled = .Item(CONTEXT_LIST_CUT).Enabled And Icbo.GetMethodInfo(MethodEnum.metCut).Authorized
                            .Item(CONTEXT_LIST_COPY).Enabled = .Item(CONTEXT_LIST_COPY).Enabled And Icbo.GetMethodInfo(MethodEnum.metCopy).Authorized
                        End With

                    Catch objException As Exception

                    End Try
                Next 'objListItem
            End If

            If objListItems.Count > 1 Then 'edit och preview �r false om >1 kanske, avancerat �r att fr�ga G om modalt gui, rentav p� metodniv�...En struct MethodInfo med Supported, Authorized, MultiSelectable ers�tter GetMethodInfo!!!...eller...
                For Each objListItem In objListItems
                    Try
                        Icbo = mcolComponent.Item(mobjNodeFromListItem(objListItem).Tag)

                        With TreeListControl1.ListItemMenu.MenuItems
                            .Item(CONTEXT_LIST_EDIT).Enabled = .Item(CONTEXT_LIST_EDIT).Enabled And Icbo.GetMethodInfo(MethodEnum.metEdit).MultiSelectable
                            .Item(CONTEXT_LIST_DELETE).Enabled = .Item(CONTEXT_LIST_DELETE).Enabled And Icbo.GetMethodInfo(MethodEnum.metDelete).MultiSelectable
                            .Item(CONTEXT_LIST_PRINT).Enabled = .Item(CONTEXT_LIST_PRINT).Enabled And Icbo.GetMethodInfo(MethodEnum.metPrint).MultiSelectable
                            .Item(CONTEXT_LIST_PREVIEW).Enabled = .Item(CONTEXT_LIST_PREVIEW).Enabled And Icbo.GetMethodInfo(MethodEnum.metPreview).MultiSelectable
                            .Item(CONTEXT_LIST_CUT).Enabled = .Item(CONTEXT_LIST_CUT).Enabled And Icbo.GetMethodInfo(MethodEnum.metCut).MultiSelectable
                            .Item(CONTEXT_LIST_COPY).Enabled = .Item(CONTEXT_LIST_COPY).Enabled And Icbo.GetMethodInfo(MethodEnum.metCopy).MultiSelectable
                        End With

                    Catch objException As Exception

                    End Try
                Next 'objListItem
            End If

            With TreeListControl1.ListItemMenu.MenuItems
                If Not .Item(CONTEXT_LIST_ADD).Visible And Not .Item(CONTEXT_LIST_DELETE).Visible Then .Item(CONTEXT_LIST_SEP1).Visible = False
                If Not .Item(CONTEXT_LIST_PRINT).Visible And Not .Item(CONTEXT_LIST_PREVIEW).Visible Then .Item(CONTEXT_LIST_SEP2).Visible = False
                If Not .Item(CONTEXT_LIST_CUT).Visible And Not .Item(CONTEXT_LIST_COPY).Visible And Not .Item(CONTEXT_LIST_PASTE).Visible Then .Item(CONTEXT_LIST_SEP3).Visible = False
            End With

            'L�gg till context - inte helt bra, ger summan av alla contexter, kanske en loop till med koll p� menuitem.text, detta m�ste vi fundera p�!!
            If objListItems.Count > 0 Then
                For Each objListItem In objListItems
                    Try
                        Icbo = mcolComponent.Item(mobjNodeFromListItem(objListItem).Tag)

                        Icbo.AddOwnContextMenuItems(objMenu, objNode)

                        If objMenu.MenuItems.Count > 0 Then
                            With TreeListControl1.ListItemMenu.MenuItems
                                .Add(objOwnContextSeparator)

                                For Each objMenuItem In objMenu.MenuItems
                                    If objMenuItem.Visible Or objOwnContextSeparator.Visible Then objOwnContextSeparator.Visible = True

                                    If objListItems.Count > 1 Then objMenuItem.Enabled = objMenuItem.MultiSelectable

                                    .Add(objMenuItem)
                                Next 'objMenuItem
                            End With
                        End If

                    Catch objException As Exception

                    End Try
                Next 'objListItem
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableEditMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.SelectedNode Is Nothing Then Exit Sub

            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuEditKlippUt.Enabled = .Item(CONTEXT_TREE_CUT).Enabled And .Item(CONTEXT_TREE_CUT).Visible
                    mnuEditKlistraIn.Enabled = .Item(CONTEXT_TREE_PASTE).Enabled And .Item(CONTEXT_TREE_PASTE).Visible
                    mnuEditKopiera.Enabled = .Item(CONTEXT_TREE_COPY).Enabled And .Item(CONTEXT_TREE_COPY).Visible
                End With
            Else
                With TreeListControl1.ListItemMenu.MenuItems
                    mnuEditKlippUt.Enabled = .Item(CONTEXT_LIST_CUT).Enabled And .Item(CONTEXT_LIST_CUT).Visible
                    mnuEditKlistraIn.Enabled = .Item(CONTEXT_LIST_PASTE).Enabled And .Item(CONTEXT_LIST_PASTE).Visible
                    mnuEditKopiera.Enabled = .Item(CONTEXT_LIST_COPY).Enabled And .Item(CONTEXT_LIST_COPY).Visible
                End With
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableFileMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.SelectedNode Is Nothing Then Exit Sub

            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuFileNy.Enabled = .Item(CONTEXT_TREE_ADD).Enabled And .Item(CONTEXT_TREE_ADD).Visible
                    mnuFileOppna.Enabled = .Item(CONTEXT_TREE_EDIT).Enabled And .Item(CONTEXT_TREE_EDIT).Visible
                    mnuFileTaBort.Enabled = .Item(CONTEXT_TREE_DELETE).Enabled And .Item(CONTEXT_TREE_DELETE).Visible
                    mnuFileSkrivUt.Enabled = .Item(CONTEXT_TREE_PRINT).Enabled And .Item(CONTEXT_TREE_PRINT).Visible
                    mnuFileForhandsgranska.Enabled = .Item(CONTEXT_TREE_PREVIEW).Enabled And .Item(CONTEXT_TREE_PREVIEW).Visible
                End With
            Else
                With TreeListControl1.ListItemMenu.MenuItems
                    mnuFileNy.Enabled = .Item(CONTEXT_LIST_ADD).Enabled And .Item(CONTEXT_LIST_ADD).Visible
                    mnuFileOppna.Enabled = .Item(CONTEXT_LIST_EDIT).Enabled And .Item(CONTEXT_LIST_EDIT).Visible
                    mnuFileTaBort.Enabled = .Item(CONTEXT_LIST_DELETE).Enabled And .Item(CONTEXT_LIST_DELETE).Visible
                    mnuFileSkrivUt.Enabled = .Item(CONTEXT_LIST_PRINT).Enabled And .Item(CONTEXT_LIST_PRINT).Visible
                    mnuFileForhandsgranska.Enabled = .Item(CONTEXT_LIST_PREVIEW).Enabled And .Item(CONTEXT_LIST_PREVIEW).Visible
                End With
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableHelpMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.SelectedNode Is Nothing Then Exit Sub

            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                mnuHelpInnehall.Enabled = IIf(Me.SystemInfo.HelpFile <> "", True, False)
            Else
                mnuHelpInnehall.Enabled = IIf(Me.SystemInfo.HelpFile <> "", True, False)
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableToolsMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.SelectedNode Is Nothing Then Exit Sub

            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuToolsSok.Enabled = .Item(CONTEXT_TREE_SEARCH).Enabled And .Item(CONTEXT_TREE_SEARCH).Visible
                End With
            Else
                mnuToolsSok.Enabled = False
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableViewMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If TreeListControl1.SelectedNode Is Nothing Then Exit Sub

            If TreeListControl1.ActivePane = PaneEnum.paTreePane Then
                With TreeListControl1.NodeMenu.MenuItems
                    mnuViewUppdatera.Enabled = .Item(CONTEXT_TREE_REFRESH).Enabled And .Item(CONTEXT_TREE_REFRESH).Visible
                End With
            Else
                mnuViewUppdatera.Enabled = False
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mEnableToolbar()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            With tbrToolbar.Buttons
                .Item(TOOLBAR_NEW).Enabled = mnuFileNy.Enabled
                .Item(TOOLBAR_OPEN).Enabled = mnuFileOppna.Enabled
                .Item(TOOLBAR_CUT).Enabled = mnuFileTaBort.Enabled
                .Item(TOOLBAR_PRINT).Enabled = mnuFileSkrivUt.Enabled
                .Item(TOOLBAR_PREVIEW).Enabled = mnuFileForhandsgranska.Enabled
                .Item(TOOLBAR_CUT).Enabled = mnuEditKlippUt.Enabled
                .Item(TOOLBAR_COPY).Enabled = mnuEditKopiera.Enabled
                .Item(TOOLBAR_PASTE).Enabled = mnuEditKlistraIn.Enabled
                .Item(TOOLBAR_SEARCH).Enabled = mnuToolsSok.Enabled
                .Item(TOOLBAR_CONTENT).Enabled = mnuHelpInnehall.Enabled
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub mConfigureSystem()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()
        Dim Icr As IConsoleRoot
        Dim Ica As IConsoleApplication
        Dim Icbo As IConsoleBaseObject
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement
        Dim objXMLElement2 As XmlElement
        Dim objXMLElement3 As XmlElement

        Try
            objXMLDocument.LoadXml(objSupport.SystemConfiguration(Me.SystemInfo.SystemName))

            For Each objXMLElement In objXMLDocument.SelectNodes("ConsoleRootCollection/ConsoleRoot") 'Endast en f�rv�ntas
                Icr = objSupport.CreateObject(objXMLElement.OuterXml)

                Icr.Connect(TreeListControl1.Nodes, TreeListControl1.ListImages)

                mcolComponent.Add(Icr, objXMLElement.Attributes.GetNamedItem("AssemblyType").Value)

                For Each objXMLElement2 In objXMLElement.SelectNodes("ConsoleApplicationCollection/ConsoleApplication")
                    Ica = objSupport.CreateObject(objXMLElement2.OuterXml)

                    Ica.Connect(TreeListControl1.Nodes.Item(TreeListControl1.Nodes.Count - 1).Nodes, TreeListControl1.ListImages)

                    mCollectMenus(Ica.SupportedStandardMenus, menmCollectedMenus)

                    mcolComponent.Add(Ica, objXMLElement2.Attributes.GetNamedItem("AssemblyType").Value)

                    For Each objXMLElement3 In objXMLElement2.SelectNodes("ComponentCollection/Component")
                        Icbo = objSupport.CreateObject(objXMLElement3.OuterXml)

                        mcolComponent.Add(Icbo, objXMLElement3.Attributes.GetNamedItem("AssemblyType").Value)
                    Next 'objXMLElement3
                Next 'objXMLElement2
            Next 'objXMLElement

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub mPerformOnInitialize()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()
        Dim Ici As IConsoleOnInitialize
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLDocument.LoadXml(objSupport.OnInitialize(Me.SystemInfo.SystemName))

            For Each objXMLElement In objXMLDocument.SelectNodes("OnInitialize/Assembly")
                Ici = objSupport.CreateObject(objXMLElement.OuterXml)

                Ici.RunOnConsoleInitialize()
            Next 'objXMLElement

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub mPerformOnTerminate()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()
        Dim Ict As IConsoleOnTerminate
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLDocument.LoadXml(objSupport.OnTerminate(Me.SystemInfo.SystemName))

            For Each objXMLElement In objXMLDocument.SelectNodes("OnTerminate/Assembly")
                Ict = objSupport.CreateObject(objXMLElement.OuterXml)

                Ict.RunOnConsoleTerminate()
            Next 'objXMLElement

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVLaggTill(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mRTVLaggTill(objNode)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVOppna(ByVal colListItem As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mRTVOppna(mobjNodeFromListItem(objListItem))
            Next 'objListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVTaBort(ByVal colListItem As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mRTVTaBort(mobjNodeFromListItem(objListItem))
            Next 'objListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVSkrivUt(ByVal colListItem As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mRTVSkrivUt(mobjNodeFromListItem(objListItem))
            Next 'objListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVForhandsgranska(ByVal colListItem As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mRTVForhandsgranska(mobjNodeFromListItem(objListItem))
            Next 'objListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVKlippUt(ByVal colListItem As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mRTVKlippUt(mobjNodeFromListItem(objListItem))
            Next 'objListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVKopiera(ByVal colListItem As ListItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mRTVKopiera(mobjNodeFromListItem(objListItem))
            Next 'objListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRLVKlistraIn(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            mRTVKlistraIn(objNode)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVVisa(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icbo As IConsoleBaseObject
        Dim Icr As IConsoleRoot

        Try
            Icbo = mcolComponent.Item(objNode.Tag)
            If Icbo.GetMethodInfo(MethodEnum.metShow).Authorized Then
                Icbo.Show(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, TreeListControl1.ColumnHeaders, TreeListControl1.ListImages, mstrStateXML)
            End If

            Icbo = Nothing
        Catch objException As Exception

        End Try

        Try
            Icr = mcolComponent.Item(objNode.Tag)
            TreeListControl1.ListItems.Clear()

            Icr = Nothing
        Catch objException As Exception

        End Try
    End Sub

    Private Sub mRTVUppdatera(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icc As IConsoleCollection

        Try
            Icc = mcolComponent.Item(objNode.Tag)

            If Icc.GetMethodInfo(MethodEnum.metRefresh).Authorized Then
                Icc.Refresh(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, TreeListControl1.ColumnHeaders, TreeListControl1.ListImages, mstrStateXML)
            End If

            Icc = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVSok(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icc As IConsoleCollection

        Try
            Icc = mcolComponent.Item(objNode.Tag)

            If Icc.GetMethodInfo(MethodEnum.metSearch).Authorized Then
                Icc.Search(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, TreeListControl1.ColumnHeaders, TreeListControl1.ListImages, mstrStateXML)
            End If

            Icc = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVLaggTill(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icc As IConsoleCollection

        Try
            Icc = mcolComponent.Item(objNode.Tag)

            If Icc.GetMethodInfo(MethodEnum.metAdd).Authorized Then
                Icc.Add(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, TreeListControl1.ColumnHeaders, TreeListControl1.ListImages, mstrStateXML)
            End If

            Icc = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVOppna(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icc As IConsoleObject

        Try
            Icc = mcolComponent.Item(objNode.Tag)

            If Icc.GetMethodInfo(MethodEnum.metEdit).Authorized Then
                Icc.Edit(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, mstrStateXML)
            End If

            Icc = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVTaBort(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icc As IConsoleCollection
        Dim Ico As IConsoleObject
        Dim nodCurrentNodeToBe As Node

        Try
            Ico = mcolComponent.Item(objNode.Tag)

            nodCurrentNodeToBe = objNode.Parent 'IConsoleObject har alltid f�r�lder

            If Ico.GetMethodInfo(MethodEnum.metDelete).Authorized Then
                Ico.Delete(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, mstrStateXML)
            Else
                Exit Sub
            End If

            Ico = Nothing

            'Visa annan objNode...objNode.Parent �r alltid kollektion
            Icc = mcolComponent.Item(nodCurrentNodeToBe.Tag)

            If Icc.GetMethodInfo(MethodEnum.metShow).Authorized Then
                Icc.Show(nodCurrentNodeToBe, TreeListControl1.Nodes, TreeListControl1.ListItems, TreeListControl1.ColumnHeaders, TreeListControl1.ListImages, mstrStateXML)
            End If

            Icc = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVSkrivUt(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Ico As IConsoleObject

        Try
            Ico = mcolComponent.Item(objNode.Tag)

            If Ico.GetMethodInfo(MethodEnum.metPrint).Authorized Then
                Ico.PrintOut(objNode, mstrStateXML)
            Else
                Exit Sub
            End If

            Ico = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVForhandsgranska(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Ico As IConsoleObject

        Try
            Ico = mcolComponent.Item(objNode.Tag)

            If Ico.GetMethodInfo(MethodEnum.metPreview).Authorized Then
                Ico.Preview(objNode, mstrStateXML)
            Else
                Exit Sub
            End If

            Ico = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVKlippUt(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Ico As IConsoleObject

        Try
            Ico = mcolComponent.Item(objNode.Tag)

            If Ico.GetMethodInfo(MethodEnum.metCut).Authorized Then
                Ico.Cut(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, mstrStateXML)
            Else
                Exit Sub
            End If

            Ico = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVKopiera(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Ico As IConsoleObject

        Try
            Ico = mcolComponent.Item(objNode.Tag)

            If Ico.GetMethodInfo(MethodEnum.metCopy).Authorized Then
                Ico.Copy(objNode, mstrStateXML)
            Else
                Exit Sub
            End If

            Ico = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mRTVKlistraIn(ByVal objNode As Node)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim Icc As IConsoleCollection

        Try
            Icc = mcolComponent.Item(objNode.Tag)

            If Icc.GetMethodInfo(MethodEnum.metPaste).Authorized Then
                Icc.Paste(objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, mstrStateXML)
            Else
                Exit Sub
            End If

            Icc = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mExecuteListContextMenu(ByVal colListItem As ListItemCollection, ByVal Index As Long)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListItem As ListItem

        Try
            For Each objListItem In colListItem
                mExecuteTreeContextMenu(mobjNodeFromListItem(objListItem), Index)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mExecuteTreeContextMenu(ByVal objNode As Node, ByVal Index As Long)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New Support()
        Dim Icbo As IConsoleBaseObject

        Try
            Icbo = mcolComponent.Item(objNode.Tag)

            Icbo.ExecuteOwnContextMethod(Index, objNode, TreeListControl1.Nodes, TreeListControl1.ListItems, TreeListControl1.ColumnHeaders, TreeListControl1.ListImages, mstrStateXML)

            Icbo = Nothing

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjNodeFromListItem(ByVal objListItem As ListItem) As Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objNode As Node

        Try
            For Each objNode In TreeListControl1.Nodes
                If objNode.FullPath = objListItem.Tag Then Return objNode
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mShowException(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjViewer Is Nothing Then mobjViewer = New Viewer()

            mobjViewer.Show(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEdit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuView As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTools As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Friend WithEvents tbrToolbar As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents imlToolbar As System.Windows.Forms.ImageList
    Friend WithEvents mnuMenu As System.Windows.Forms.MainMenu
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton8 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton9 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton10 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton11 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton12 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton13 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton14 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton15 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton16 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton17 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton18 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton19 As System.Windows.Forms.ToolBarButton
    Friend WithEvents mnuFileNy As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileOppna As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileTaBort As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileForhandsgranska As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileSep2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileAvsluta As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEditKlippUt As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEditKopiera As System.Windows.Forms.MenuItem
    Friend WithEvents mnuEditKlistraIn As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewToolbar As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewStatusbar As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewIcon As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewSmallIcon As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewList As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewReport As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewSep2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuViewUppdatera As System.Windows.Forms.MenuItem
    Friend WithEvents mnuToolsSok As System.Windows.Forms.MenuItem
    Friend WithEvents mnuToolsSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelpInnehall As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelpSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelpOm As System.Windows.Forms.MenuItem
    Friend WithEvents sbrPanel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbrPanel2 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbrPanel3 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbrStatusbar As System.Windows.Forms.StatusBar
    Friend WithEvents mnuContextListView As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuContextTreeView As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuToolsExternaSystem As System.Windows.Forms.MenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents mnuFileSkrivUt As System.Windows.Forms.MenuItem
    Friend WithEvents cdgHelp As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents TreeListControl1 As TreeListControl
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ConsoleForm))
        Me.mnuMenu = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFileNy = New System.Windows.Forms.MenuItem()
        Me.mnuFileOppna = New System.Windows.Forms.MenuItem()
        Me.mnuFileTaBort = New System.Windows.Forms.MenuItem()
        Me.mnuFileSep1 = New System.Windows.Forms.MenuItem()
        Me.mnuFileSkrivUt = New System.Windows.Forms.MenuItem()
        Me.mnuFileForhandsgranska = New System.Windows.Forms.MenuItem()
        Me.mnuFileSep2 = New System.Windows.Forms.MenuItem()
        Me.mnuFileAvsluta = New System.Windows.Forms.MenuItem()
        Me.mnuEdit = New System.Windows.Forms.MenuItem()
        Me.mnuEditKlippUt = New System.Windows.Forms.MenuItem()
        Me.mnuEditKopiera = New System.Windows.Forms.MenuItem()
        Me.mnuEditKlistraIn = New System.Windows.Forms.MenuItem()
        Me.mnuView = New System.Windows.Forms.MenuItem()
        Me.mnuViewToolbar = New System.Windows.Forms.MenuItem()
        Me.mnuViewStatusbar = New System.Windows.Forms.MenuItem()
        Me.mnuViewSep1 = New System.Windows.Forms.MenuItem()
        Me.mnuViewIcon = New System.Windows.Forms.MenuItem()
        Me.mnuViewSmallIcon = New System.Windows.Forms.MenuItem()
        Me.mnuViewList = New System.Windows.Forms.MenuItem()
        Me.mnuViewReport = New System.Windows.Forms.MenuItem()
        Me.mnuViewSep2 = New System.Windows.Forms.MenuItem()
        Me.mnuViewUppdatera = New System.Windows.Forms.MenuItem()
        Me.mnuTools = New System.Windows.Forms.MenuItem()
        Me.mnuToolsSok = New System.Windows.Forms.MenuItem()
        Me.mnuToolsSep1 = New System.Windows.Forms.MenuItem()
        Me.mnuToolsExternaSystem = New System.Windows.Forms.MenuItem()
        Me.mnuHelp = New System.Windows.Forms.MenuItem()
        Me.mnuHelpInnehall = New System.Windows.Forms.MenuItem()
        Me.mnuHelpSep1 = New System.Windows.Forms.MenuItem()
        Me.mnuHelpOm = New System.Windows.Forms.MenuItem()
        Me.tbrToolbar = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton8 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton9 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton10 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton11 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton12 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton13 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton14 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton15 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton16 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton17 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton18 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton19 = New System.Windows.Forms.ToolBarButton()
        Me.imlToolbar = New System.Windows.Forms.ImageList(Me.components)
        Me.sbrStatusbar = New System.Windows.Forms.StatusBar()
        Me.sbrPanel1 = New System.Windows.Forms.StatusBarPanel()
        Me.sbrPanel2 = New System.Windows.Forms.StatusBarPanel()
        Me.sbrPanel3 = New System.Windows.Forms.StatusBarPanel()
        Me.mnuContextListView = New System.Windows.Forms.ContextMenu()
        Me.mnuContextTreeView = New System.Windows.Forms.ContextMenu()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cdgHelp = New System.Windows.Forms.OpenFileDialog()
        Me.TreeListControl1 = New OOPERA.WinControls.TreeList.TreeListControl()
        CType(Me.sbrPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbrPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbrPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMenu
        '
        Me.mnuMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuEdit, Me.mnuView, Me.mnuTools, Me.mnuHelp})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileNy, Me.mnuFileOppna, Me.mnuFileTaBort, Me.mnuFileSep1, Me.mnuFileSkrivUt, Me.mnuFileForhandsgranska, Me.mnuFileSep2, Me.mnuFileAvsluta})
        Me.mnuFile.Text = "&Arkiv"
        '
        'mnuFileNy
        '
        Me.mnuFileNy.Index = 0
        Me.mnuFileNy.Shortcut = System.Windows.Forms.Shortcut.CtrlN
        Me.mnuFileNy.Text = "&Ny..."
        '
        'mnuFileOppna
        '
        Me.mnuFileOppna.Index = 1
        Me.mnuFileOppna.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.mnuFileOppna.Text = "&�ppna..."
        '
        'mnuFileTaBort
        '
        Me.mnuFileTaBort.Index = 2
        Me.mnuFileTaBort.Text = "&Ta bort"
        '
        'mnuFileSep1
        '
        Me.mnuFileSep1.Index = 3
        Me.mnuFileSep1.Text = "-"
        '
        'mnuFileSkrivUt
        '
        Me.mnuFileSkrivUt.Index = 4
        Me.mnuFileSkrivUt.Shortcut = System.Windows.Forms.Shortcut.CtrlP
        Me.mnuFileSkrivUt.Text = "Skriv &ut..."
        '
        'mnuFileForhandsgranska
        '
        Me.mnuFileForhandsgranska.Index = 5
        Me.mnuFileForhandsgranska.Text = "F�r&handsgranska"
        '
        'mnuFileSep2
        '
        Me.mnuFileSep2.Index = 6
        Me.mnuFileSep2.Text = "-"
        '
        'mnuFileAvsluta
        '
        Me.mnuFileAvsluta.Index = 7
        Me.mnuFileAvsluta.Text = "Avsluta"
        '
        'mnuEdit
        '
        Me.mnuEdit.Index = 1
        Me.mnuEdit.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuEditKlippUt, Me.mnuEditKopiera, Me.mnuEditKlistraIn})
        Me.mnuEdit.Text = "&Redigera"
        '
        'mnuEditKlippUt
        '
        Me.mnuEditKlippUt.Index = 0
        Me.mnuEditKlippUt.Shortcut = System.Windows.Forms.Shortcut.CtrlX
        Me.mnuEditKlippUt.Text = "&Klipp ut"
        '
        'mnuEditKopiera
        '
        Me.mnuEditKopiera.Index = 1
        Me.mnuEditKopiera.Shortcut = System.Windows.Forms.Shortcut.CtrlC
        Me.mnuEditKopiera.Text = "K&opiera"
        '
        'mnuEditKlistraIn
        '
        Me.mnuEditKlistraIn.Index = 2
        Me.mnuEditKlistraIn.Shortcut = System.Windows.Forms.Shortcut.CtrlV
        Me.mnuEditKlistraIn.Text = "K&listra in"
        '
        'mnuView
        '
        Me.mnuView.Index = 2
        Me.mnuView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuViewToolbar, Me.mnuViewStatusbar, Me.mnuViewSep1, Me.mnuViewIcon, Me.mnuViewSmallIcon, Me.mnuViewList, Me.mnuViewReport, Me.mnuViewSep2, Me.mnuViewUppdatera})
        Me.mnuView.Text = "Vi&sa"
        '
        'mnuViewToolbar
        '
        Me.mnuViewToolbar.Checked = True
        Me.mnuViewToolbar.Index = 0
        Me.mnuViewToolbar.Text = "Ver&ktygsf�lt"
        '
        'mnuViewStatusbar
        '
        Me.mnuViewStatusbar.Checked = True
        Me.mnuViewStatusbar.Index = 1
        Me.mnuViewStatusbar.Text = "S&tatusf�lt"
        '
        'mnuViewSep1
        '
        Me.mnuViewSep1.Index = 2
        Me.mnuViewSep1.Text = "-"
        '
        'mnuViewIcon
        '
        Me.mnuViewIcon.Index = 3
        Me.mnuViewIcon.Text = "&Stora ikoner"
        '
        'mnuViewSmallIcon
        '
        Me.mnuViewSmallIcon.Index = 4
        Me.mnuViewSmallIcon.Text = "S&m� ikoner"
        '
        'mnuViewList
        '
        Me.mnuViewList.Index = 5
        Me.mnuViewList.Text = "&Lista"
        '
        'mnuViewReport
        '
        Me.mnuViewReport.Index = 6
        Me.mnuViewReport.Text = "&Detaljer"
        '
        'mnuViewSep2
        '
        Me.mnuViewSep2.Index = 7
        Me.mnuViewSep2.Text = "-"
        '
        'mnuViewUppdatera
        '
        Me.mnuViewUppdatera.Index = 8
        Me.mnuViewUppdatera.Shortcut = System.Windows.Forms.Shortcut.F5
        Me.mnuViewUppdatera.Text = "&Uppdatera"
        '
        'mnuTools
        '
        Me.mnuTools.Index = 3
        Me.mnuTools.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuToolsSok, Me.mnuToolsSep1, Me.mnuToolsExternaSystem})
        Me.mnuTools.Text = "&Verktyg"
        '
        'mnuToolsSok
        '
        Me.mnuToolsSok.Index = 0
        Me.mnuToolsSok.Text = "&S�k..."
        '
        'mnuToolsSep1
        '
        Me.mnuToolsSep1.Index = 1
        Me.mnuToolsSep1.Text = "-"
        '
        'mnuToolsExternaSystem
        '
        Me.mnuToolsExternaSystem.Index = 2
        Me.mnuToolsExternaSystem.Text = "&Externa system..."
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 4
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpInnehall, Me.mnuHelpSep1, Me.mnuHelpOm})
        Me.mnuHelp.Text = "&Hj�lp"
        '
        'mnuHelpInnehall
        '
        Me.mnuHelpInnehall.Index = 0
        Me.mnuHelpInnehall.Text = "&Inneh�ll"
        '
        'mnuHelpSep1
        '
        Me.mnuHelpSep1.Index = 1
        Me.mnuHelpSep1.Text = "-"
        '
        'mnuHelpOm
        '
        Me.mnuHelpOm.Index = 2
        Me.mnuHelpOm.Text = "&Om Systemnamn..."
        '
        'tbrToolbar
        '
        Me.tbrToolbar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.tbrToolbar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton7, Me.ToolBarButton8, Me.ToolBarButton9, Me.ToolBarButton10, Me.ToolBarButton11, Me.ToolBarButton12, Me.ToolBarButton13, Me.ToolBarButton14, Me.ToolBarButton15, Me.ToolBarButton16, Me.ToolBarButton17, Me.ToolBarButton18, Me.ToolBarButton19})
        Me.tbrToolbar.ButtonSize = New System.Drawing.Size(23, 24)
        Me.tbrToolbar.DropDownArrows = True
        Me.tbrToolbar.ImageList = Me.imlToolbar
        Me.tbrToolbar.Name = "tbrToolbar"
        Me.tbrToolbar.ShowToolTips = True
        Me.tbrToolbar.Size = New System.Drawing.Size(728, 25)
        Me.tbrToolbar.TabIndex = 0
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 1
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 2
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 3
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 4
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton8
        '
        Me.ToolBarButton8.ImageIndex = 5
        '
        'ToolBarButton9
        '
        Me.ToolBarButton9.ImageIndex = 6
        '
        'ToolBarButton10
        '
        Me.ToolBarButton10.ImageIndex = 7
        '
        'ToolBarButton11
        '
        Me.ToolBarButton11.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton12
        '
        Me.ToolBarButton12.ImageIndex = 8
        '
        'ToolBarButton13
        '
        Me.ToolBarButton13.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton14
        '
        Me.ToolBarButton14.ImageIndex = 9
        Me.ToolBarButton14.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        '
        'ToolBarButton15
        '
        Me.ToolBarButton15.ImageIndex = 10
        Me.ToolBarButton15.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        '
        'ToolBarButton16
        '
        Me.ToolBarButton16.ImageIndex = 11
        Me.ToolBarButton16.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        '
        'ToolBarButton17
        '
        Me.ToolBarButton17.ImageIndex = 12
        Me.ToolBarButton17.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        '
        'ToolBarButton18
        '
        Me.ToolBarButton18.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton19
        '
        Me.ToolBarButton19.ImageIndex = 13
        '
        'imlToolbar
        '
        Me.imlToolbar.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlToolbar.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlToolbar.ImageStream = CType(resources.GetObject("imlToolbar.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlToolbar.TransparentColor = System.Drawing.Color.Transparent
        '
        'sbrStatusbar
        '
        Me.sbrStatusbar.Location = New System.Drawing.Point(0, 549)
        Me.sbrStatusbar.Name = "sbrStatusbar"
        Me.sbrStatusbar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbrPanel1, Me.sbrPanel2, Me.sbrPanel3})
        Me.sbrStatusbar.ShowPanels = True
        Me.sbrStatusbar.Size = New System.Drawing.Size(728, 22)
        Me.sbrStatusbar.TabIndex = 1
        '
        'sbrPanel1
        '
        Me.sbrPanel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbrPanel1.Width = 512
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'TreeListControl1
        '
        Me.TreeListControl1.ActivePane = OOPERA.WinControls.TreeList.PaneEnum.paTreePane
        Me.TreeListControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TreeListControl1.Location = New System.Drawing.Point(0, 25)
        Me.TreeListControl1.Name = "TreeListControl1"
        Me.TreeListControl1.ShowInfoBar = True
        Me.TreeListControl1.ShowMenus = True
        Me.TreeListControl1.Size = New System.Drawing.Size(728, 524)
        Me.TreeListControl1.Sorted = True
        Me.TreeListControl1.SplitPosition = 0
        Me.TreeListControl1.TabIndex = 2
        Me.TreeListControl1.View = OOPERA.WinControls.TreeList.RightPaneViewEnum.rpvDetails
        '
        'ConsoleForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(728, 571)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TreeListControl1, Me.sbrStatusbar, Me.tbrToolbar})
        Me.Menu = Me.mnuMenu
        Me.MinimumSize = New System.Drawing.Size(200, 0)
        Me.Name = "ConsoleForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OOPERA WinConsole"
        CType(Me.sbrPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbrPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbrPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
