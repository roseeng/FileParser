'**************************************************************************************************
' DemoAppK AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************

Imports System.EnterpriseServices
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("DemoAppK")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("DemoApp")> 
<Assembly: AssemblyCopyright("Copyright �YYYY OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("CEBD9686-AD4C-45B7-8E82-01231F202825")> 'GuidGen /HB
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: ApplicationActivation(ActivationOption.Server)> 
<Assembly: ApplicationID("021D7099-0F88-474c-BB72-F36D97B95719")>  'GuidGen /HB
<Assembly: ApplicationName("DemoApp")> 
<Assembly: Description("Applikation f�r DemoApp")> 
<Assembly: AssemblyKeyFile("../../DemoAppK.snk")> 
