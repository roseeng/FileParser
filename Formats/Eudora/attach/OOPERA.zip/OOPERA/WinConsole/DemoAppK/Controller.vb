'**************************************************************************************************
' DemoAppK Controller Class:
' Klass f�r beh�righet.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports System.EnterpriseServices

<JustInTimeActivation(True)> Public Class Controller
    Inherits OOPERA.Architecture.KLayer.Controller

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Placera egna variabler h�r, inga restriktioner
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r modifieras internt
    Public Overloads Overrides Function MethodIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String, ByVal MethodName As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till metoden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att auktorisera anropet
            Return MyBase.MethodIsAuthorized(ComponentName, ClassName, MethodName)      'tex
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Overloads Overrides Function MethodIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String, ByVal MethodName As String, ByVal UserName As String, ByVal Password As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till metoden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att auktorisera anropet
            Return MyBase.MethodIsAuthorized(ComponentName, ClassName, MethodName, UserName, Password)      'tex
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Overloads Overrides Function ObjectIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till metoden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att auktorisera anropet
            Return MyBase.ObjectIsAuthorized(ComponentName, ClassName)      'tex
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Overloads Overrides Function ObjectIsAuthorized(ByVal ComponentName As String, ByVal ClassName As String, ByVal UserName As String, ByVal Password As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till metoden.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att auktorisera anropet
            Return MyBase.ObjectIsAuthorized(ComponentName, ClassName, UserName, Password)      'tex
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Overloads Overrides Function UseCaseIsAuthorized(ByVal UseCaseName As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till anv�ndningsfallet.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att auktorisera anropet
            Return MyBase.UseCaseIsAuthorized(UseCaseName)      'tex
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Function

    Public Overloads Overrides Function UseCaseIsAuthorized(ByVal UseCaseName As String, ByVal UserName As String, ByVal Password As String) As Boolean
        '******************************************************************************************
        ' Beskrivning: Returnerar om beh�righet finns till anv�ndningsfallet.
        ' Skapad.....: 2002-02-29 Av: OOPERA Architecture Template 1.0.906.0
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att auktorisera anropet
            Return MyBase.UseCaseIsAuthorized(UseCaseName, UserName, Password)     'tex
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw objException

        End Try
    End Function
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner
#End Region

End Class
