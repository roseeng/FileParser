Imports OOPERA.WinConsole
Imports OOPERA.WinControls.TreeList
Imports System.Drawing

Public Class Application
    Implements OOPERA.WinConsole.IConsoleApplication

    Public ReadOnly Property SupportedStandardMenus() As OOPERA.WinConsole.MenuToolbarEnum Implements OOPERA.WinConsole.IConsoleApplication.SupportedStandardMenus
        Get
            Return MenuToolbarEnum.mtbAdd + MenuToolbarEnum.mtbDelete + MenuToolbarEnum.mtbOpen + MenuToolbarEnum.mtbRefresh
        End Get
    End Property

    Public Sub Connect(ByVal AllNodes As OOPERA.WinControls.TreeList.NodeCollection, ByVal AllListImages As OOPERA.WinControls.TreeList.ListImageCollection) Implements OOPERA.WinConsole.IConsoleApplication.Connect
        Dim objImage As System.Drawing.Image
        Dim frm As New ImagesForm()
        Dim nod As Node

        Try
            AllListImages.Add(frm.ImageList1.Images.Item(0), "nollan")
            AllListImages.Add(frm.ImageList1.Images.Item(1), "ettan")

            nod = AllNodes.Add("Mallar")

            nod.ImageIndex = AllListImages.IndexOf("ettan")
            nod.SelectedImageIndex = AllListImages.IndexOf("ettan")

            nod.Tag = "DemoAppConsole.TheCollection"
            nod.Expand()

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

End Class
