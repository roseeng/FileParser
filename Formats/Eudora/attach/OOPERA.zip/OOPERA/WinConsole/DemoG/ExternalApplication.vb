Imports OOPERA.WinConsole
Imports System.Drawing

Public Class ExternalApplication
    Implements OOPERA.WinConsole.IConsoleExternalApplication

    Public ReadOnly Property AssemblyProduct() As String Implements OOPERA.WinConsole.IConsoleExternalApplication.AssemblyProduct
        '******************************************************************************************
        ' Beskrivning: Returnerar produktnamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return "rajtantajtan"

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public Sub RunApplication() Implements OOPERA.WinConsole.IConsoleExternalApplication.RunApplication
        '******************************************************************************************
        ' Beskrivning: Startar applikationen.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            MessageBox.Show("The externa app ist correr")

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

End Class
