Imports OOPERA.ExceptionHandler
Imports OOPERA.WinConsole
Imports System.Drawing

Public Class OnInitialize
    Implements OOPERA.WinConsole.IConsoleOnInitialize

    Private mobjHandler As Handler

    Public Sub RunOnConsoleInitialize() Implements OOPERA.WinConsole.IConsoleOnInitialize.RunOnConsoleInitialize
        '******************************************************************************************
        ' Beskrivning: Exekverar kod som skall k�ras n�r systemet startas.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'MessageBox.Show("initiering")

            Throw New Exception("Fl�sket �r kokt p� spik")

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

End Class
