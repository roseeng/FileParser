Imports OOPERA.WinConsole
Imports System.Drawing

Public Class OnTerminate
    Implements OOPERA.WinConsole.IConsoleOnTerminate

    Public Sub RunOnConsoleTerminate() Implements OOPERA.WinConsole.IConsoleOnTerminate.RunOnConsoleTerminate
        '******************************************************************************************
        ' Beskrivning: Exekverar kod som skall k�ras n�r systemet avslutas.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'MessageBox.Show("nu vare slut")

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

End Class
