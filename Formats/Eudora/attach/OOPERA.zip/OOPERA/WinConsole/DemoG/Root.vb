Imports OOPERA.WinControls.TreeList
Imports System.Drawing

Public Class Root
    Implements OOPERA.WinConsole.IConsoleRoot

    Public Sub Connect(ByVal AllNodes As OOPERA.WinControls.TreeList.NodeCollection, ByVal AllListImages As OOPERA.WinControls.TreeList.ListImageCollection) Implements OOPERA.WinConsole.IConsoleRoot.Connect
        Dim objImage As System.Drawing.Image
        Dim frm As New ImagesForm()
        Dim nod As Node

        Try
            AllListImages.Add(frm.ImageList1.Images.Item(0), "nollan")
            AllListImages.Add(frm.ImageList1.Images.Item(1), "ettan")

            nod = AllNodes.Add("El Sistema de Test")

            nod.ImageIndex = AllListImages.IndexOf("ettan")
            nod.SelectedImageIndex = AllListImages.IndexOf("fetto3")

            nod.Tag = "DemoAppConsole.Root"

            nod.Expand()

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

End Class
