Imports OOPERA.WinControls.TreeList
Imports OOPERA.WinConsole

Public Class TheCollection
    Implements OOPERA.WinConsole.IConsoleCollection
    Implements OOPERA.WinConsole.IConsoleBaseObject

    Public ReadOnly Property FriendlyName() As String Implements OOPERA.WinConsole.IConsoleCollection.FriendlyName
        Get
            Return "En kollektion"
        End Get
    End Property

    Public Sub Add(ByVal NodeToAddTo As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String) Implements OOPERA.WinConsole.IConsoleCollection.Add

    End Sub

    Public Sub Paste(ByVal NodeToPasteTo As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef StateXML As String) Implements OOPERA.WinConsole.IConsoleCollection.Paste

    End Sub

    Public Sub Refresh(ByVal NodeToRefresh As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String) Implements OOPERA.WinConsole.IConsoleCollection.Refresh

    End Sub

    Public Sub Search(ByVal NodeToSearch As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String) Implements OOPERA.WinConsole.IConsoleCollection.Search

    End Sub

    Public Sub AddOwnContextMenuItems(ByVal ContextMenu As Menu, ByVal SelectedNode As Node) Implements OOPERA.WinConsole.IConsoleBaseObject.AddOwnContextMenuItems

    End Sub

    Public Sub ExecuteOwnContextMethod(ByVal MenuIndex As Integer, ByVal SelectedNode As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String) Implements OOPERA.WinConsole.IConsoleBaseObject.ExecuteOwnContextMethod

    End Sub

    Public Sub Show(ByVal NodeToShow As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String) Implements OOPERA.WinConsole.IConsoleBaseObject.Show

    End Sub

    Public Function GetMethodInfo(ByVal Method As OOPERA.WinConsole.MethodEnum) As MethodInfo Implements OOPERA.WinConsole.IConsoleBaseObject.GetMethodInfo
        Dim objMethodInfo As New MethodInfo()

        With objMethodInfo
            .Authorized = True
            .Supported = True
            .MultiSelectable = False
        End With

        Return objMethodInfo
    End Function

    Public ReadOnly Property SupportContextMenu() As Boolean Implements OOPERA.WinConsole.IConsoleBaseObject.SupportContextMenu
        Get
            Return True
        End Get
    End Property

End Class
