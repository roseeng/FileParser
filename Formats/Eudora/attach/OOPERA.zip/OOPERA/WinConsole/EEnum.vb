'**************************************************************************************************
' Console Enum Enumeration:
' Enumeration f�r Console.
'**************************************************************************************************
' Skapad: 2000-10-01 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum EEnum

    xxx

    'Public Enum FormStatusEnum
    '    fstAdd
    '    fstEdit
    'End Enum

    'Public Enum MethodEnum
    '    metAdd
    '    metCopy
    '    metCut
    '    metDelete
    '    metEdit
    '    metPaste
    '    metPreview
    '    metPrint
    '    metRefresh
    '    metSearch
    '    metShow
    'End Enum

    'Public Enum MenuToolbarEnum
    '    mtbAdd = 1
    '    mtbOpen = 2
    '    mtbDelete = 4
    '    mtbPrint = 8
    '    mtbPreview = 16
    '    mtbCut = 32
    '    mtbCopy = 64
    '    mtbPaste = 128
    '    mtbSearch = 256
    '    mtbRefresh = 512
    'End Enum

End Enum
