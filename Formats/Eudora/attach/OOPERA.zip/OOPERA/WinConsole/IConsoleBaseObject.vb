'**************************************************************************************************
' WinConsole ConsoleBaseObject Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.WinControls.TreeList

Public Interface IConsoleBaseObject

    Sub AddOwnContextMenuItems(ByVal ContextMenu As Menu, ByVal SelectedNode As Node)

    Sub ExecuteOwnContextMethod(ByVal MenuIndex As Integer, ByVal SelectedNode As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String)

    Sub Show(ByVal NodeToShow As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String)

    ReadOnly Property SupportContextMenu() As Boolean

    'Function SupportFunction(ByVal Method As WinConsole.MethodEnum) As Boolean 'Papper med b�ttre t�nk finns

    Function GetMethodInfo(ByVal Method As WinConsole.MethodEnum) As MethodInfo

End Interface
