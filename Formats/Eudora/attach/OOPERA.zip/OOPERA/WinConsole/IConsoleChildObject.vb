'**************************************************************************************************
' WinConsole ConsoleChildObject Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.WinControls.TreeList

Public Interface IConsoleChildObject

    Sub Add(ByVal NodeToAddTo As Node, ByRef AllNodes As NodeCollection, ByRef AllListImages As ListImageCollection, ByVal NewNode As Object, ByRef StateXML As String)

    Sub Delete(ByVal NodeToDelete As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef StateXML As String)

    'Function SupportFunction(ByVal Method As WinConsole.MethodEnum) As Boolean 'Papper med b�ttre t�nk finns

    Function GetMethodInfo(ByVal Method As WinConsole.MethodEnum) As MethodInfo

End Interface
