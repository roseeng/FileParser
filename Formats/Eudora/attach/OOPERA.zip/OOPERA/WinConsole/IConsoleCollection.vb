'**************************************************************************************************
' WinConsole ConsoleCollection Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.WinControls.TreeList

Public Interface IConsoleCollection
    Inherits OOPERA.WinConsole.IConsoleBaseObject

    Sub Add(ByVal NodeToAddTo As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String)

    ReadOnly Property FriendlyName() As String

    Sub Paste(ByVal NodeToPasteTo As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef StateXML As String)

    Sub Refresh(ByVal NodeToRefresh As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String)

    Sub Search(ByVal NodeToSearch As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef ListViewColumnHeaders As ColumnHeaderCollection, ByRef AllListImages As ListImageCollection, ByRef StateXML As String)

End Interface
