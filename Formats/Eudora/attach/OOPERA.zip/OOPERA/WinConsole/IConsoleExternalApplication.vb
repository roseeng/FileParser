'**************************************************************************************************
' WinConsole ConsoleExternalApplication Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Interface IConsoleExternalApplication

    ReadOnly Property AssemblyProduct() As String

    Sub RunApplication()

End Interface
