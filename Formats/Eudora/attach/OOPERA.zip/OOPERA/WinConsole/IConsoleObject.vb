'**************************************************************************************************
' WinConsole ConsoleObject Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.WinControls.TreeList

Public Interface IConsoleObject
    Inherits OOPERA.WinConsole.IConsoleBaseObject

    Sub Copy(ByVal NodeToCopy As Node, ByRef StateXML As String)

    Sub Cut(ByVal NodeToCut As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef StateXML As String)

    Sub Delete(ByVal NodeToDelete As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef StateXML As String)

    Sub Edit(ByVal NodeToEdit As Node, ByRef AllNodes As NodeCollection, ByRef AllListItems As ListItemCollection, ByRef StateXML As String)

    Sub Preview(ByVal NodeToPreview As Node, ByRef StateXML As String)

    Sub PrintOut(ByVal NodeToPrintOut As Node, ByRef StateXML As String)

End Interface
