'**************************************************************************************************
' WinConsole ConsoleOnInitialize Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Interface IConsoleOnInitialize

    Sub RunOnConsoleInitialize()

End Interface
