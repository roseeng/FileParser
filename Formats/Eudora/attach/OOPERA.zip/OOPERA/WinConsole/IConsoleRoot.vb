'**************************************************************************************************
' WinConsole ConsoleRoot Interface:
' Interface f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.WinControls.TreeList

Public Interface IConsoleRoot

    Sub Connect(ByVal AllNodes As NodeCollection, ByVal AllListImages As ListImageCollection)

End Interface
