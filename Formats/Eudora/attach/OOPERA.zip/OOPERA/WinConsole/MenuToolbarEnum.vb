'**************************************************************************************************
' WinConsole MenuToolbar Enumeration:
' Enumeration f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum MenuToolbarEnum
    mtbAdd = 1
    mtbOpen = 2
    mtbDelete = 4
    mtbPrint = 8
    mtbPreview = 16
    mtbCut = 32
    mtbCopy = 64
    mtbPaste = 128
    mtbSearch = 256
    mtbRefresh = 512
End Enum
