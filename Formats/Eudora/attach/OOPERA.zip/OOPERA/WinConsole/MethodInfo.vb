'**************************************************************************************************
' WinConsole MethodInfo Structure:
' Struktur f�r WinConsole.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Structure MethodInfo
    Public Supported As Boolean
    Public Authorized As Boolean
    Public MultiSelectable As Boolean
End Structure
