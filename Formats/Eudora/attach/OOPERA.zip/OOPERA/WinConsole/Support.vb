'**************************************************************************************************
' WinConsole Support Class:
' St�dfunktioner f�r komponenten.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports System.Xml

Friend Class Support 'Ska g�ras om en del f�r bla registrykomponenten...

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler
#End Region

#Region "* * * P R O P E R T I E S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Function CreateObject(ByVal AssemblyXML As String) As Object
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx. Kanske ska jag v�nda p� ordningen, alltid 4:e
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New XmlDocument()

        Try
            objXMLDocument.LoadXml(AssemblyXML)

            Return Activator.CreateInstance(objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyName").Value, objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyType").Value)

        Catch objException1 As Exception
            Try
                Return Activator.CreateInstanceFrom(objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyName").Value, objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyType").Value).Unwrap()

            Catch objException2 As Exception
                Try
                    Return Activator.CreateInstance(objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyFile").Value, objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyType").Value)

                Catch objException3 As Exception
                    Try
                        Return Activator.CreateInstanceFrom(objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyFile").Value, objXMLDocument.DocumentElement.Attributes.GetNamedItem("AssemblyType").Value).Unwrap()

                    Catch objException As Exception
                        Throw mobjFormatException(objException)

                    End Try
                End Try
            End Try
        End Try
    End Function

    Public Function SystemConfiguration(ByVal SystemName As String) As String
        '******************************************************************************************
        ' Beskrivning: Returnerar vilka applikationer som kan fungera som TreeListrot f�r ett visst 
        '              system.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New Xml.XmlDocument()
        Dim objXMLElement As Xml.XmlElement

        Try
            objXMLDocument.Load("C:\Temp\My Documents\Visual Studio Projects\OOPERA\WinConsole\El Sistema de Test.WinConsole.config") 'fr�n registry

            Return objXMLDocument.SelectSingleNode("WinConsoleConfiguration/ConsoleRootCollection").OuterXml

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function OnInitialize(ByVal SystemName As String) As String
        '******************************************************************************************
        ' Beskrivning: Returnerar vilka applikationer som eventuellt skall k�ras n�r
        '              under initiering av TreeList f�r ett visst system.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'Return "<OnInitialize><Assembly AssemblyName='DemoAppConsole' AssemblyType='DemoAppConsole.OnInitialize' /></OnInitialize>"
            Return "<OnInitialize><Assembly AssemblyFile='C:\Temp\My Documents\Visual Studio Projects\OOPERA\WinConsole\DemoG\bin\DemoAppConsole.dll' AssemblyType='DemoAppConsole.OnInitialize' /></OnInitialize>"

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function OnTerminate(ByVal SystemName As String) As String
        '******************************************************************************************
        ' Beskrivning: Returnerar vilka applikationer som eventuellt skall k�ras n�r
        '              under initiering av TreeList f�r ett visst system.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'Return "<OnTerminate><Assembly AssemblyName='DemoAppConsole' AssemblyType='DemoAppConsole.OnTerminate' /></OnTerminate>"
            Return "<OnTerminate><Assembly AssemblyFile='C:\Temp\My Documents\Visual Studio Projects\OOPERA\WinConsole\DemoG\bin\DemoAppConsole.dll' AssemblyType='DemoAppConsole.OnTerminate' /></OnTerminate>"

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function ExternalApplications(ByVal SystemName As String) As String
        '******************************************************************************************
        ' Beskrivning: Returnerar vilka applikationer som eventuellt skall k�ras n�r
        '              under initiering av TreeList f�r ett visst system.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'Return "<ExternalApplications><Assembly AssemblyName='DemoAppConsole' AssemblyType='DemoAppConsole.ExternalApplication' /></ExternalApplications>"
            Return "<ExternalApplications><Assembly AssemblyFile='C:\Temp\My Documents\Visual Studio Projects\OOPERA\WinConsole\DemoG\bin\DemoAppConsole.dll' AssemblyType='DemoAppConsole.ExternalApplication' /></ExternalApplications>"

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
