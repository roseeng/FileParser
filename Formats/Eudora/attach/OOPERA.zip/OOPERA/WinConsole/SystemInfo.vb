'**************************************************************************************************
' WinConsole SystemInfo Class:
' Klass som h�ller information om aktuellt system.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Friend Class SystemInfo

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjImage As System.Drawing.Icon
    Private mstrTitle As String
    Private mstrMajor As String
    Private mstrMinor As String
    Private mstrRevision As String
    Private mstrReleaseText As String
    Private mstrFileDescription As String
    Private mstrLegalCopyright As String
    Private mstrComments As String
    Private mstrHelpFile As String
    Private mstrProductName As String
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property Comments() As String
        '******************************************************************************************
        ' Beskrivning: S�tter/Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrComments

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As String)
            Try
                mstrComments = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Description() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrFileDescription & vbCrLf & mstrLegalCopyright

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public WriteOnly Property FileDescription() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrFileDescription = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property HelpFile() As String
        '******************************************************************************************
        ' Beskrivning: S�tter/Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrHelpFile

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As String)
            Try
                mstrHelpFile = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Icon() As System.Drawing.Icon 'MSComctlLib.IImage
        '**************************************************************************************************************
        ' Beskrivning: S�tter/Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '**************************************************************************************************************
        Get
            Try
                Return mobjImage

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Icon)  'MSComctlLib.IImage)
            Try
                mobjImage = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public WriteOnly Property LegalCopyright() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrLegalCopyright = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public WriteOnly Property Major() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrMajor = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public WriteOnly Property Minor() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrMinor = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property ProductName() As String
        '******************************************************************************************
        ' Beskrivning: S�tter/Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrProductName

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As String)
            Try
                mstrProductName = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Release() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrTitle & " " & mstrMajor & "." & mstrMinor & " " & mstrReleaseText

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public WriteOnly Property ReleaseText() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrReleaseText = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public WriteOnly Property Revision() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrRevision = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property SystemName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************        
        Get
            Try
                Return "DemoAppConsole" 'mstrTitle

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public WriteOnly Property Title() As String
        '******************************************************************************************
        ' Beskrivning: S�tter <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Set(ByVal Value As String)
            Try
                mstrTitle = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Version() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar <Property>.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrMajor & "." & mstrMinor & "." & mstrRevision

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"

#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
