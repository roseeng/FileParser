Public Class Form1
    Inherits System.Windows.Forms.Form

    Private WithEvents mobj As New OOPERA.WinConsole.Application()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Location = New System.Drawing.Point(-1000, -1000)
        Me.Name = "Form1"
        Me.Text = "Ugga Bugga"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: Startar en TreeList applikation.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New ImagesForm()

        Try

            mobj.Start(Me.Icon, "App.Title", "App.Major", "App.Minor", "App.Revision", "App.Comments", "App.LegalCopyright", "App.FileDescription", "App.ProductName", "App.HelpFile")

            frm.close()

        Catch objException As exception
            MsgBox("Felet: " & Err.Number & " '" & Err.Description & "' intr�ffade i: " & Err.Source & "!", vbCritical)
        End Try
    End Sub

    Private Sub mobj_Terminate(ByVal sender As Object, ByVal e As System.EventArgs) Handles mobj.Terminate
        '******************************************************************************************
        ' Beskrivning: Sl�pper applikationens process n�r OOConsole avslutas.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try

            Me.Close()

        Catch objException As exception
            MsgBox("Felet: " & Err.Number & " '" & Err.Description & "' intr�ffade i: " & Err.Source & "!", vbCritical)
        End Try
    End Sub
End Class
