'**************************************************************************************************
' TreeList AssemblyInfo:
' Komponentens assemblyinformation.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("OOPERA.WinControls.TreeList")> 
<Assembly: AssemblyDescription("Varning: Denna applikation �r skyddad av upphovsr�ttslagen och internationella regler. Olovlig kopiering och distribution av denna applikation beivras.")> 
<Assembly: AssemblyCompany("OOPERA Konsult AB")> 
<Assembly: AssemblyProduct("OOPERA WinControls TreeList")> 
<Assembly: AssemblyCopyright("Copyright �2002 OOPERA Konsult AB")> 
<Assembly: AssemblyTrademark("Alla r�ttigheter")> 
<Assembly: CLSCompliant(True)> 
<Assembly: Guid("FF39C05E-8924-4678-9AA6-24116513D856")> 
<Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyKeyFile("../../OOPERA.WinControls.TreeList.snk")> 
