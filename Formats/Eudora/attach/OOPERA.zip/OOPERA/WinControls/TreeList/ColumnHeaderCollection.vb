'**************************************************************************************************
' TreeList ColumnHeaderCollection Class:
' Kollektionsklass f�r objekt av typen ColumnHeader.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class ColumnHeaderCollection
#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjColumnHeaderCollection As System.Windows.Forms.ListView.ColumnHeaderCollection
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public ReadOnly Property Count() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjColumnHeaderCollection.Count

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsReadOnly() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjColumnHeaderCollection.IsReadOnly()

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Default Public ReadOnly Property Item(ByVal Index As Integer) As OOPERA.WinControls.TreeList.ColumnHeader
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return New TreeList.ColumnHeader(mobjColumnHeaderCollection.Item(Index))

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overloads Function Add(ByVal Text As String, ByVal Width As Integer, ByVal TextAlign As HorizontalAlignmentEnum) As OOPERA.WinControls.TreeList.ColumnHeader
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return New TreeList.ColumnHeader(mobjColumnHeaderCollection.Add(Text, Width, TextAlign))

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function Add(ByVal ColumnHeader As ColumnHeader) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjColumnHeaderCollection.Add(ColumnHeader.ColunmHeader)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub AddRange(ByVal ColumnHeaders As OOPERA.WinControls.TreeList.ColumnHeader())
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim objColumnHeader As OOPERA.WinControls.TreeList.ColumnHeader

            For Each objColumnHeader In ColumnHeaders
                mobjColumnHeaderCollection.Add(objColumnHeader.ColunmHeader)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Clear()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjColumnHeaderCollection.Clear()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Function Contains(ByVal ColumnHeader As OOPERA.WinControls.TreeList.ColumnHeader) As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjColumnHeaderCollection.Contains(ColumnHeader.ColunmHeader)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function GetEnumerator() As System.Collections.IEnumerator
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objColumnHeader As System.Windows.Forms.ColumnHeader
        Dim col = New Microsoft.VisualBasic.Collection()

        Try
            For Each objColumnHeader In mobjColumnHeaderCollection
                col.Add(New TreeList.ColumnHeader(objColumnHeader))
            Next 'objColumnHeader

            Return col.GetEnumerator

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function IndexOf(ByVal ColumnHeader As OOPERA.WinControls.TreeList.ColumnHeader) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjColumnHeaderCollection.IndexOf(ColumnHeader.ColunmHeader)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Sub Insert(ByVal Index As Integer, ByVal Text As String, ByVal Width As Integer, ByVal TextAlign As OOPERA.WinControls.TreeList.HorizontalAlignmentEnum)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjColumnHeaderCollection.Insert(Index, Text, Width, TextAlign)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Sub Insert(ByVal Index As Integer, ByVal ColumnHeader As OOPERA.WinControls.TreeList.ColumnHeader)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjColumnHeaderCollection.Insert(Index, ColumnHeader.ColunmHeader)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Remove(ByVal ColumnHeader As OOPERA.WinControls.TreeList.ColumnHeader)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjColumnHeaderCollection.Remove(ColumnHeader.ColunmHeader)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub RemoveAt(ByVal Index As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjColumnHeaderCollection.RemoveAt(Index)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Friend Sub New(ByVal ColumnHeaderCollection As System.Windows.Forms.ListView.ColumnHeaderCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjColumnHeaderCollection = ColumnHeaderCollection

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
