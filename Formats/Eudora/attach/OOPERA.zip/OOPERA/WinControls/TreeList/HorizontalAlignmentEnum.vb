'**************************************************************************************************
' TreeList HorizontalAlignment Enumeration:
' Enumeration f�r TreeList.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum HorizontalAlignmentEnum
    haCenter = 2 'inte klar
    haLeft = 0 'inte klar
    haRight = 1 'inte klar
End Enum
