Public Enum ListColumnAlignmentEnum
    lcaColumnLeft
    lcaColumnRight
    lcaColumnCenter
End Enum
