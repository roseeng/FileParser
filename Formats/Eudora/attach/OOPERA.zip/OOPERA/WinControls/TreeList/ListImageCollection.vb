'**************************************************************************************************
' TreeList ListImageCollection Class:
' Kollektionsklass f�r objekt av typen System.Drawing.Image.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class ListImageCollection

    Private Structure ImageStructure
        Public Index As Integer
        Public Key As String
    End Structure

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjListImageCollection As System.Windows.Forms.ImageList.ImageCollection
    Private mobjSmallListImageCollection As System.Windows.Forms.ImageList.ImageCollection

    'Pga viss underl�tenhet fr�n ImageCollection att st�dja all f�rv�ntad funktionalitet s� tar vi hj�lp av en collection /HB
    Private mobjCollection As New Microsoft.VisualBasic.Collection()
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public ReadOnly Property Count() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListImageCollection.Count

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property Empty() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListImageCollection.Empty

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsReadOnly() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListImageCollection.IsReadOnly()

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Default Public ReadOnly Property Item(ByVal Index As Integer) As System.Drawing.Image
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListImageCollection.Item(Index)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overloads Sub Add(ByVal Icon As System.Drawing.Icon)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjSmallListImageCollection.Add(Icon)

            mobjListImageCollection.Add(Icon)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Sub Add(ByVal Icon As System.Drawing.Icon, ByVal Key As String)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim structImageStructure As New ImageStructure()

            mobjSmallListImageCollection.Add(Icon)

            mobjListImageCollection.Add(Icon)

            structImageStructure.Index = mobjListImageCollection.Count - 1
            structImageStructure.Key = Key
            mobjCollection.Add(structImageStructure, Key)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Sub Add(ByVal Image As System.Drawing.Image)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjSmallListImageCollection.Add(Image)

            mobjListImageCollection.Add(Image)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Sub Add(ByVal Image As System.Drawing.Image, ByVal Key As String)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim structImageStructure As New ImageStructure()

            Try
                structImageStructure = mobjCollection.Item(Key) 'om key finns s� kan inte bilden l�ggas till

            Catch objException As Exception
                mobjSmallListImageCollection.Add(Image)

                mobjListImageCollection.Add(Image)

                structImageStructure.Index = mobjListImageCollection.Count - 1
                structImageStructure.Key = Key
                mobjCollection.Add(structImageStructure, Key)

            End Try

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Function Add(ByVal Image As System.Drawing.Image, ByVal TransparentColor As System.Drawing.Color) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjSmallListImageCollection.Add(Image, TransparentColor)

            Return mobjListImageCollection.Add(Image, TransparentColor)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function Add(ByVal Image As System.Drawing.Image, ByVal TransparentColor As System.Drawing.Color, ByVal Key As String) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim structImageStructure As New ImageStructure()

            mobjSmallListImageCollection.Add(Image, TransparentColor)

            Return mobjListImageCollection.Add(Image, TransparentColor)

            structImageStructure.Index = mobjListImageCollection.Count - 1
            structImageStructure.Key = Key
            mobjCollection.Add(structImageStructure, Key)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function AddStrip(ByVal Image As System.Drawing.Image) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjSmallListImageCollection.AddStrip(Image)

            Return mobjListImageCollection.AddStrip(Image)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function AddStrip(ByVal Image As System.Drawing.Image, ByVal Key As String) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim structImageStructure As New ImageStructure()

            mobjSmallListImageCollection.AddStrip(Image)

            Return mobjListImageCollection.AddStrip(Image)

            structImageStructure.Index = mobjListImageCollection.Count - 1
            structImageStructure.Key = Key
            mobjCollection.Add(structImageStructure, Key)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub Clear()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjSmallListImageCollection.Clear()

            mobjListImageCollection.Clear()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    '.NET: Not supported
    'Public Function Contains(ByVal Image As System.Drawing.Image) As Boolean
    '    Return mobjListImageCollection.Contains(Image)
    'End Function

    Public Function GetEnumerator() As System.Collections.IEnumerator
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjListImageCollection.GetEnumerator()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    '.NET: Not supported
    'Public Function IndexOf(ByVal Image As System.Drawing.Image) As Integer 
    '    'Return mobjListImageCollection.IndexOf(Image)
    'End Function

    '.NET: Not supported men H�kan implementerar detta
    Public Function IndexOf(ByVal Key As String) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        'Denna implementation fungerar b�st f�r Add...(Key,....) . Objekt inlagda utan Key f�r alltid IndexOf=-1
        Dim structImageStructure As ImageStructure

        Try
            structImageStructure = mobjCollection.Item(Key)

            Return structImageStructure.Index

        Catch objException As Exception
            Return -1

        End Try
    End Function

    '.NET: Not supported
    'Public Sub Remove(ByVal Image As System.Drawing.Image)
    '    mobjSmallListImageCollection.Remove(Image)

    '    mobjListImageCollection.Remove(Image)
    'End Sub

    Public Sub RemoveAt(ByVal Index As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim i As Integer
        Dim blnCollectionIndex As Integer

        Try
            mobjSmallListImageCollection.RemoveAt(Index)

            mobjListImageCollection.RemoveAt(Index)

            'Om objektet p� index=index lagts till med Add...(Key,....) s� tas det bort ur min tempor�ra kollektion
            For i = 1 To mobjCollection.Count
                If mobjCollection.Item(i).index = Index Then
                    blnCollectionIndex = i
                    Exit For
                End If
            Next

            If blnCollectionIndex = 0 Then
                mobjListImageCollection.RemoveAt(Index)
                mobjSmallListImageCollection.RemoveAt(Index)
            Else
                mobjListImageCollection.RemoveAt(Index)
                mobjSmallListImageCollection.RemoveAt(Index)

                mobjCollection.Remove(blnCollectionIndex)

                For i = blnCollectionIndex To mobjCollection.Count
                    mobjCollection.Item(i).index -= 1
                Next
            End If

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Friend Sub New(ByVal SmallListItemCollection As System.Windows.Forms.ImageList.ImageCollection, ByVal ListItemCollection As System.Windows.Forms.ImageList.ImageCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjSmallListImageCollection = SmallListItemCollection

            mobjListImageCollection = ListItemCollection

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
