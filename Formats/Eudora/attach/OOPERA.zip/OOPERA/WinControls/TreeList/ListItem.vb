'**************************************************************************************************
' TreeList ListItem Class:
' Objektsklass f�r objekt av typen ListItem.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class ListItem
#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjListViewItem As System.Windows.Forms.ListViewItem
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property BackColor() As System.Drawing.Color
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.BackColor

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Color)
            Try
                mobjListViewItem.BackColor = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Bounds() As System.Drawing.Rectangle
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Bounds

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property Checked() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Checked

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mobjListViewItem.Checked = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property


    Public Property Focused() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Focused

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mobjListViewItem.Focused = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Font() As System.Drawing.Font
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Font

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Font)
            Try
                mobjListViewItem.Font = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property ForeColor() As System.Drawing.Color
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.ForeColor

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Color)
            Try
                mobjListViewItem.ForeColor = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property ImageIndex() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.ImageIndex

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Integer)
            Try
                mobjListViewItem.ImageIndex = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Index() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Index

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property Selected() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Selected

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mobjListViewItem.Selected = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property StateImageIndex() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.StateImageIndex

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Integer)
            Try
                mobjListViewItem.StateImageIndex = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property SubItems() As OOPERA.WinControls.TreeList.ListSubItemCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return New TreeList.ListSubItemCollection(mobjListViewItem.SubItems)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property Tag() As Object
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Tag

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Object)
            Try
                mobjListViewItem.Tag = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Text() As String
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.Text

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As String)
            Try
                mobjListViewItem.Text = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property UseItemstyleForSubItems() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem.UseItemStyleForSubItems

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mobjListViewItem.UseItemStyleForSubItems = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Friend ReadOnly Property ListViewItem() As System.Windows.Forms.ListViewItem
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListViewItem

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub BeginEdit()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem.BeginEdit()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Function Clone() As Object
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjListViewItem.Clone()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub EnsureVisible()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem.EnsureVisible()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Function GetBounds(ByVal Portion As System.Windows.Forms.ItemBoundsPortion) As System.Drawing.Rectangle
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem.GetBounds(Portion)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub New()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = New System.Windows.Forms.ListViewItem()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Items As String())
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = New System.Windows.Forms.ListViewItem(Items)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = New System.Windows.Forms.ListViewItem(Text)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Items As String(), ByVal ImageIndex As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = New System.Windows.Forms.ListViewItem(Items, ImageIndex)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String, ByVal ImageIndex As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = New System.Windows.Forms.ListViewItem(Text, ImageIndex)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Items As String(), ByVal ImageIndex As Integer, ByVal ForeColor As System.Drawing.Color, ByVal BackColor As System.Drawing.Color, ByVal Font As System.Drawing.Font)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = New System.Windows.Forms.ListViewItem(Items, ImageIndex, ForeColor, BackColor, Font)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal SubItems As OOPERA.WinControls.TreeList.ListSubItem(), ByVal ImageIndex As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim objListSubItem As TreeList.ListSubItem

            mobjListViewItem = New System.Windows.Forms.ListViewItem()
            mobjListViewItem.ImageIndex = ImageIndex

            For Each objListSubItem In SubItems
                mobjListViewItem.SubItems.Add(objListSubItem.ListViewSubItem)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Remove()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem.Remove()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overrides Function ToString() As String
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjListViewItem.ToString()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Friend Sub New(ByVal ListItem As System.Windows.Forms.ListViewItem)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListViewItem = ListItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
