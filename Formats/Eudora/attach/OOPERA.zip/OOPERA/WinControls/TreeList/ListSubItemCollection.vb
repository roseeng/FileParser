'**************************************************************************************************
' TreeList ListSubItemCollection Class:
' Kollektionsklass f�r objekt av typen ListSubItem.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class ListSubItemCollection
#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjListSubItemCollection As System.Windows.Forms.ListViewItem.ListViewSubItemCollection
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public ReadOnly Property Count() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListSubItemCollection.Count

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsReadOnly() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListSubItemCollection.IsReadOnly

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Default Public ReadOnly Property Item(ByVal Index As Integer) As OOPERA.WinControls.TreeList.ListSubItem
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return New TreeList.ListSubItem(mobjListSubItemCollection.Item(Index))

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Overloads Function Add(ByVal Text As String) As OOPERA.WinControls.TreeList.ListSubItem
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return New TreeList.ListSubItem(mobjListSubItemCollection.Add(Text))

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function Add(ByVal Text As String, ByVal ForeColor As System.Drawing.Color, ByVal BackColor As System.Drawing.Color, ByVal Font As System.Drawing.Font) As OOPERA.WinControls.TreeList.ListSubItem
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return New TreeList.ListSubItem(mobjListSubItemCollection.Add(Text, ForeColor, BackColor, Font))

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Function Add(ByVal ListSubItem As OOPERA.WinControls.TreeList.ListSubItem) As OOPERA.WinControls.TreeList.ListSubItem
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.Add(ListSubItem.ListViewSubItem)

            Return ListSubItem

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Overloads Sub AddRange(ByVal ListSubItems As String())
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.AddRange(ListSubItems)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Sub AddRange(ByVal ListSubItems As String(), ByVal ForeColor As System.Drawing.Color, ByVal BackColor As System.Drawing.Color, ByVal Font As System.Drawing.Font)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.AddRange(ListSubItems, ForeColor, BackColor, Font)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overloads Sub AddRange(ByVal ListSubItems As OOPERA.WinControls.TreeList.ListSubItem())
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Dim objListSubItem As TreeList.ListSubItem

            For Each objListSubItem In ListSubItems
                mobjListSubItemCollection.Add(objListSubItem.ListViewSubItem)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Clear()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.Clear()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Function Contains(ByVal ListSubItem As OOPERA.WinControls.TreeList.ListSubItem) As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjListSubItemCollection.Contains(ListSubItem.ListViewSubItem)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function GetEnumerator() As System.Collections.IEnumerator
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjListSubItemCollection.GetEnumerator

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Function IndexOf(ByVal ListSubItem As OOPERA.WinControls.TreeList.ListSubItem) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjListSubItemCollection.IndexOf(ListSubItem.ListViewSubItem)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub Insert(ByVal Index As Integer, ByVal ListSubItem As OOPERA.WinControls.TreeList.ListSubItem)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.Insert(Index, ListSubItem.ListViewSubItem)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Owner As OOPERA.WinControls.TreeList.ListItem)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection = New System.Windows.Forms.ListViewItem.ListViewSubItemCollection(Owner.ListViewItem)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub RemoveAt(ByVal Index As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.RemoveAt(Index)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Remove(ByVal ListSubItem As OOPERA.WinControls.TreeList.ListSubItem)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection.Remove(ListSubItem.ListViewSubItem)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Friend Sub New(ByVal ListSubItemCollection As System.Windows.Forms.ListViewItem.ListViewSubItemCollection)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjListSubItemCollection = ListSubItemCollection

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
