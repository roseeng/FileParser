'**************************************************************************************************
' TreeList Menu Class:
' Objektsklass f�r objekt av typen Menu.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class Menu
#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjMenuItemCollection As TreeList.MenuItemCollection
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public ReadOnly Property MenuItems() As TreeList.MenuItemCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjMenuItemCollection

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub New()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjMenuItemCollection = New TreeList.MenuItemCollection()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
