'**************************************************************************************************
' TreeList MenuItem Class:
' Objektsklass f�r objekt av typen MenuItem.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class MenuItem
#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mblnDefaultItem As Boolean
    Private mblnEnabled As Boolean
    Private mblnMultiSelectable As Boolean
    Private mblnVisible As Boolean
    Private mobjMenuItemCollection As New TreeList.MenuItemCollection()
    Private mstrText As String
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property DefaultItem() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnDefaultItem

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnDefaultItem = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Enabled() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnEnabled

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnEnabled = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property MultiSelectable() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnMultiSelectable

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnMultiSelectable = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    'hm...kaxigt...klarar jag att fixa detta...
    Public Property MenuItems() As TreeList.MenuItemCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjMenuItemCollection

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As TreeList.MenuItemCollection)
            Try
                mobjMenuItemCollection = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Text() As String
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mstrText

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As String)
            Try
                mstrText = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Visible() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnVisible

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnVisible = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub New(ByVal Text As String)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mstrText = Text
            mblnEnabled = True
            mblnVisible = True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String, ByVal Enabled As Boolean, ByVal Visible As Boolean)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mstrText = Text
            mblnEnabled = Enabled
            mblnVisible = Visible

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
