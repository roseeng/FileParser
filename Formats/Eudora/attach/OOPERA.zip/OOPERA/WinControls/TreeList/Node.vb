'**************************************************************************************************
' TreeList Node Class:
' Objektsklass f�r objekt av typen Node.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public NotInheritable Class Node
    Inherits System.MarshalByRefObject

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mobjTreeNode As System.Windows.Forms.TreeNode
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property BackColor() As System.Drawing.Color
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.BackColor

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Color)
            Try
                mobjTreeNode.BackColor = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Bounds() As System.Drawing.Rectangle
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.Bounds

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property Checked() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.Checked

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mobjTreeNode.Checked = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property FirstNode() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.FirstNode Is Nothing Then Return New TreeList.Node(mobjTreeNode.FirstNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property ForeColor() As System.Drawing.Color
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.ForeColor

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Color)
            Try
                mobjTreeNode.ForeColor = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property FullPath() As String
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.FullPath

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property Handle() As IntPtr
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.Handle

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property ImageIndex() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.ImageIndex

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Integer)
            Try
                mobjTreeNode.ImageIndex = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Index() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.Index

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsEditing() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.IsEditing

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsExpanded() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.IsExpanded

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsSelected() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.IsSelected

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property IsVisible() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.IsVisible

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property LastNode() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.LastNode Is Nothing Then Return New TreeList.Node(mobjTreeNode.LastNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property NextNode() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.NextNode Is Nothing Then Return New TreeList.Node(mobjTreeNode.NextNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property NextVisibleNode() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.NextVisibleNode Is Nothing Then Return New TreeList.Node(mobjTreeNode.NextVisibleNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property NodeFont() As System.Drawing.Font
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.NodeFont

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As System.Drawing.Font)
            Try
                mobjTreeNode.NodeFont = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public ReadOnly Property Nodes() As NodeCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return New TreeList.NodeCollection(mobjTreeNode.Nodes)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property Parent() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.Parent Is Nothing Then Return New TreeList.Node(mobjTreeNode.Parent)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property PrevNode() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.PrevNode Is Nothing Then Return New TreeList.Node(mobjTreeNode.PrevNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property PrevVisibleNode() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not mobjTreeNode.PrevVisibleNode Is Nothing Then Return New TreeList.Node(mobjTreeNode.PrevVisibleNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public ReadOnly Property Root() As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Dim objTreeNode As System.Windows.Forms.TreeNode

            Try
                objTreeNode = mobjTreeNode

                While Not objTreeNode.Parent Is Nothing
                    objTreeNode = objTreeNode.Parent
                End While

                Return New TreeList.Node(objTreeNode)

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Property SelectedImageIndex() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.SelectedImageIndex

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Integer)
            Try
                mobjTreeNode.SelectedImageIndex = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Tag() As Object
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.Tag

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Object)
            Try
                mobjTreeNode.Tag = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Public Property Text() As String
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode.Text

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As String)
            Try
                mobjTreeNode.Text = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property

    Friend ReadOnly Property TreeNode() As System.Windows.Forms.TreeNode
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeNode

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub BeginEdit()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.BeginEdit()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Function Clone() As Object
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjTreeNode.Clone()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub Collapse()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.Collapse()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub EndEdit(ByVal Cancel As Boolean)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.EndEdit(Cancel)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub EnsureVisible()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.EnsureVisible()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Expand()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.Expand()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub ExpandAll()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.ExpandAll()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Shared Function FromHandle(ByVal Tree As System.Windows.Forms.TreeView, ByVal Handle As IntPtr) As OOPERA.WinControls.TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return New TreeList.Node(System.Windows.Forms.TreeNode.FromHandle(Tree, Handle))

        Catch objException As Exception
            'Throw mobjFormatException(objException)
            Throw objException

        End Try
    End Function

    Public Function GetNodeCount(ByVal IncludeSubTrees As Boolean) As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjTreeNode.GetNodeCount(IncludeSubTrees)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Public Sub New()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode = New System.Windows.Forms.TreeNode()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode = New System.Windows.Forms.TreeNode(Text)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String, ByVal Children As OOPERA.WinControls.TreeList.Node())
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objNode As TreeList.Node

        Try
            mobjTreeNode = New System.Windows.Forms.TreeNode(Text)

            For Each objNode In Children
                mobjTreeNode.Nodes.Add(objNode.TreeNode)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String, ByVal ImageIndex As Integer, ByVal SelectedImageIndex As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode = New System.Windows.Forms.TreeNode(Text, ImageIndex, SelectedImageIndex)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub New(ByVal Text As String, ByVal ImageIndex As Integer, ByVal SelectedImageIndex As Integer, ByVal Children As OOPERA.WinControls.TreeList.Node())
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objNode As TreeList.Node

        Try
            mobjTreeNode = New System.Windows.Forms.TreeNode(Text, ImageIndex, SelectedImageIndex)

            For Each objNode In Children
                mobjTreeNode.Nodes.Add(objNode.TreeNode)
            Next

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Remove()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.Remove()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Sub Toggle()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode.Toggle()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Public Overrides Function ToString() As String
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Return mobjTreeNode.ToString()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Friend Sub New(ByVal TreeNode As System.Windows.Forms.TreeNode)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mobjTreeNode = TreeNode

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
