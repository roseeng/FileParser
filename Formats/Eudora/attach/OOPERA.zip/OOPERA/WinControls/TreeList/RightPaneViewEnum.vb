'**************************************************************************************************
' TreeList RightPaneView Enumeration:
' Enumeration f�r TreeList.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Enum RightPaneViewEnum
    rpvIcon = System.Windows.Forms.View.LargeIcon
    rpvSmallIcon = System.Windows.Forms.View.SmallIcon
    rpvList = System.Windows.Forms.View.List
    rpvDetails = System.Windows.Forms.View.Details
End Enum
