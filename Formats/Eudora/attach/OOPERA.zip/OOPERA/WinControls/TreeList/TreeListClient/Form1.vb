Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TreeListControl1 As OOPERA.WinControl.TreeList.TreeListControl
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TreeListControl1 = New OOPERA.WinControl.TreeList.TreeListControl()
        Me.SuspendLayout()
        '
        'TreeListControl1
        '
        Me.TreeListControl1.ActivePane = OOPERA.WinControl.TreeList.PaneEnum.paLeftPane
        Me.TreeListControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TreeListControl1.Name = "TreeListControl1"
        Me.TreeListControl1.RightPaneType = OOPERA.WinControl.TreeList.RightPaneTypeEnum.rptListview
        Me.TreeListControl1.ShowInfoBar = True
        Me.TreeListControl1.ShowMenus = True
        Me.TreeListControl1.Size = New System.Drawing.Size(292, 273)
        Me.TreeListControl1.Sorted = True
        Me.TreeListControl1.SplitPosition = 100
        Me.TreeListControl1.TabIndex = 0
        Me.TreeListControl1.View = OOPERA.WinControl.TreeList.RightPaneViewEnum.rpvReport
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TreeListControl1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub TreeListControl1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TreeListControl1.Load

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim nodes() As OOPERA.WinControl.TreeList.Node = {New OOPERA.WinControl.TreeList.Node("Ricard"), New OOPERA.WinControl.TreeList.Node("Paul")}
        Dim nod As New OOPERA.WinControl.TreeList.Node("Retard", nodes)

        nod.Nodes.Add("MusTig").BackColor = Color.LightCoral

        TreeListControl1.Left = 0
        TreeListControl1.Top = 0
        TreeListControl1.Width = Me.Width
        TreeListControl1.Height = Me.Height

        TreeListControl1.Nodes.Add("Qksugare")
        TreeListControl1.Nodes.Add(nod)

        TreeListControl1.Nodes.Insert(2, New OOPERA.WinControl.TreeList.Node("Knarkarsvin"))

        Dim nod2 As OOPERA.WinControl.TreeList.Node
        For Each nod2 In TreeListControl1.Nodes
            'MessageBox.Show(nod2.Text)
        Next


    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Me.WindowState = FormWindowState.Minimized Then Exit Sub

        If Me.Width < 200 Then Me.Width = 200
    End Sub

End Class
