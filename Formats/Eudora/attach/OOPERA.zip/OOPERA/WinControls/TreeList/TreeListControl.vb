'**************************************************************************************************
' TreeList TreeList Control:
' Kontroll f�r TreeList funktionalitet.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Public Class TreeListControl
    Inherits System.Windows.Forms.UserControl

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mblnKeyUp As Boolean
    Private mblnListItemRightClick As Boolean
    Private mblnNodeRightClick As Boolean
    Private menmContextMenu As TreeList.ContextMenuTypeEnum

    Private mblnSorted As Boolean
    Private mblnShowInfoBar As Boolean
    Private mblnShowMenus As Boolean
    Private mpaPane As PaneEnum
    Private mrpvView As RightPaneViewEnum
    Private mintSplitPosition As Integer

    Private mobjListItemMenu As TreeList.Menu
    Private mobjListMenu As TreeList.Menu
    Private mobjNodeMenu As TreeList.Menu
    Private mobjTreeMenu As TreeList.Menu

    Private mobjColumnHeaderCollection As TreeList.ColumnHeaderCollection
    Private mobjListImageCollection As TreeList.ListImageCollection
    Private mobjListItemCollection As TreeList.ListItemCollection
    Private mobjListSubItemCollection As TreeList.ListSubItemCollection
    Private mobjNodesCollection As TreeList.NodeCollection
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property ActivePane() As TreeList.PaneEnum
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mpaPane

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As TreeList.PaneEnum)
            Try
                mpaPane = Value

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property

    Public ReadOnly Property ColumnHeaders() As TreeList.ColumnHeaderCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return (mobjColumnHeaderCollection)

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property ListImages() As TreeList.ListImageCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return (mobjListImageCollection)

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property ListItemMenu() As TreeList.Menu
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListItemMenu

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property ListItems() As TreeList.ListItemCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListItemCollection

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property ListMenu() As TreeList.Menu
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return (mobjListMenu)

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property ListSubItems() As TreeList.ListSubItemCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjListSubItemCollection

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property Nodes() As TreeList.NodeCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjNodesCollection

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property NodeMenu() As TreeList.Menu
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjNodeMenu

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property SelectedListItems() As TreeList.ListItemCollection
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Dim lvwListViewTemp As New System.Windows.Forms.ListView()
            Dim objListViewItem As System.Windows.Forms.ListViewItem

            Try
                If lvwListView.SelectedItems.Count > 0 Then
                    For Each objListViewItem In lvwListView.SelectedItems
                        lvwListViewTemp.Items.Add(objListViewItem.Clone())
                    Next 'objListViewItem
                End If

                Return New TreeList.ListItemCollection(lvwListViewTemp.Items)

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public ReadOnly Property SelectedNode() As TreeList.Node
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                If Not tvwTreeView.SelectedNode Is Nothing Then Return New Node(tvwTreeView.SelectedNode)

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public Property ShowMenus() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnShowMenus

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnShowMenus = Value

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property

    Public Property ShowInfoBar() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnShowInfoBar

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnShowInfoBar = Value
                lblTreeView.Visible = Value
                lblListView.Visible = Value

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property

    Public Property Sorted() As Boolean
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mblnSorted

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As Boolean)
            Try
                mblnSorted = Value
                lvwListView.Sorting = IIf(mblnSorted, SortOrder.Descending, SortOrder.None)
                tvwTreeView.Sorted = mblnSorted

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property

    Public Property SplitPosition() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mintSplitPosition

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As Integer)
            Try
                mintSplitPosition = Value

                splSplitter.Left = Value

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property

    Public ReadOnly Property TreeMenu() As TreeList.Menu
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mobjTreeMenu

            Catch objException As Exception
                Throw objException

            End Try
        End Get
    End Property

    Public Property View() As TreeList.RightPaneViewEnum
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mrpvView

            Catch objException As Exception
                Throw objException

            End Try
        End Get
        Set(ByVal Value As TreeList.RightPaneViewEnum)
            Try
                mrpvView = Value
                lvwListView.View = Value

            Catch objException As Exception
                Throw objException

            End Try
        End Set
    End Property
#End Region

#Region "* * * E V E N T S * * *"
    Public Event ListClick(ByVal sender As Object, ByVal e As System.EventArgs)
    Public Event ListDoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
    Public Event ListItemMenuClick(ByVal sender As Object, ByVal e As OOPERA.WinControls.TreeList.TreeListMenuEventArgs)
    Public Event ListMenuClick(ByVal sender As Object, ByVal e As OOPERA.WinControls.TreeList.TreeListMenuEventArgs)
    Public Event NodeMenuClick(ByVal sender As Object, ByVal e As OOPERA.WinControls.TreeList.TreeListMenuEventArgs)
    Public Event SpecialKeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
    Public Event TreeClick(ByVal sender As Object, ByVal e As System.EventArgs)
    Public Event TreeDoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
    Public Event TreeMenuClick(ByVal sender As Object, ByVal e As OOPERA.WinControls.TreeList.TreeListMenuEventArgs)
    Public Event TreeMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)

    Private Sub lvwListView_ColumnClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs) Handles lvwListView.ColumnClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'borde kunna redas ut men det verkar ju jobbigt nu
            lvwListView.Sorting = SortOrder.Ascending

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub lvwListView_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwListView.DoubleClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            RaiseEvent ListDoubleClick(Me, e)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub lvwListView_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwListView.Enter
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mpaPane = PaneEnum.paListPane

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub lvwListView_ItemActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwListView.ItemActivate
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            RaiseEvent ListClick(Me, e)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub lvwListView_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles lvwListView.KeyUp
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case e.KeyCode
                Case Keys.Delete, Keys.Return, Keys.F1, Keys.F5
                    RaiseEvent SpecialKeyUp(Me, e)
                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub lvwListView_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvwListView.MouseDown
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Not lvwListView.GetItemAt(e.X, e.Y) Is Nothing Then
                menmContextMenu = ContextMenuTypeEnum.ListItemMenu
            Else
                menmContextMenu = ContextMenuTypeEnum.ListMenu
            End If

            mpaPane = PaneEnum.paListPane

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mnuContext_Popup(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuContext.Popup
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Not mblnShowMenus Then menmContextMenu = ContextMenuTypeEnum.DisabledMenu

            Select Case menmContextMenu
                Case ContextMenuTypeEnum.DisabledMenu
                    mDisableContextMenu()
                Case ContextMenuTypeEnum.ListItemMenu
                    mPrepareRLVListItemMenu()
                Case ContextMenuTypeEnum.ListMenu
                    mPrepareRLVListMenu()
                Case ContextMenuTypeEnum.NodeMenu
                    mPrepareRTVNodeMenu()
                Case ContextMenuTypeEnum.TreeMenu
                    mPrepareRTVTreeMenu()
                Case Else
            End Select

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub TreeListControl_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Not tvwTreeView.SelectedNode Is Nothing Then lblListView.Text = tvwTreeView.SelectedNode.FullPath

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub TreeListControl_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Me.Width < 200 Then Me.Width = 200

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub tvwTreeView_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tvwTreeView.Click
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            RaiseEvent TreeClick(Me, e)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub tvwTreeView_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tvwTreeView.DoubleClick
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            RaiseEvent TreeDoubleClick(Me, e)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub tvwTreeView_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tvwTreeView.Enter
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mpaPane = PaneEnum.paTreePane

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub tvwTreeView_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tvwTreeView.KeyUp
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case e.KeyCode
                Case Keys.Delete, Keys.Return, Keys.F1, Keys.F5, Keys.Left, Keys.Right, Keys.Down, Keys.PageDown, Keys.PageUp
                    RaiseEvent SpecialKeyUp(Me, e)
                Case Else
            End Select

            lblListView.Text = tvwTreeView.SelectedNode.FullPath

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub tvwTreeView_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tvwTreeView.MouseDown
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Not tvwTreeView.GetNodeAt(e.X, e.Y) Is Nothing Then
                menmContextMenu = ContextMenuTypeEnum.NodeMenu

                RaiseEvent TreeMouseDown(Me, e)
            Else
                menmContextMenu = ContextMenuTypeEnum.TreeMenu
            End If

            mpaPane = PaneEnum.paTreePane

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub tvwTreeView_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tvwTreeView.MouseUp
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            lblListView.Text = tvwTreeView.SelectedNode.FullPath

        Catch objException As Exception
            Throw objException

        End Try
    End Sub
#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"

#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Sub mDisableContextMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mnuContext.MenuItems.Clear()

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mPrepareRLVListItemMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objMenuItem As System.Windows.Forms.MenuItem
        Dim objMenuItemTemp As TreeList.MenuItem

        Try
            mnuContext.MenuItems.Clear()

            For Each objMenuItemTemp In mobjListItemMenu.MenuItems
                objMenuItem = mnuContext.MenuItems.Add(objMenuItemTemp.Text)

                objMenuItem.Enabled = objMenuItemTemp.Enabled
                objMenuItem.Visible = objMenuItemTemp.Visible
                objMenuItem.DefaultItem = objMenuItemTemp.DefaultItem

                AddHandler objMenuItem.Click, AddressOf EventHandlerForListItemMenuClick
            Next 'objMenuItemTemp

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mPrepareRLVListMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objMenuItem As System.Windows.Forms.MenuItem
        Dim objMenuItemTemp As TreeList.MenuItem

        Try
            mnuContext.MenuItems.Clear()

            For Each objMenuItemTemp In mobjListMenu.MenuItems
                objMenuItem = mnuContext.MenuItems.Add(objMenuItemTemp.Text)

                objMenuItem.Enabled = objMenuItemTemp.Enabled
                objMenuItem.Visible = objMenuItemTemp.Visible
                objMenuItem.DefaultItem = objMenuItemTemp.DefaultItem

                AddHandler objMenuItem.Click, AddressOf EventHandlerForListMenuClick
            Next 'objMenuItemTemp

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mPrepareRTVNodeMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objMenuItem As System.Windows.Forms.MenuItem
        Dim objMenuItemTemp As TreeList.MenuItem

        Try
            mnuContext.MenuItems.Clear()

            For Each objMenuItemTemp In mobjNodeMenu.MenuItems
                objMenuItem = mnuContext.MenuItems.Add(objMenuItemTemp.Text)

                objMenuItem.Enabled = objMenuItemTemp.Enabled
                objMenuItem.Visible = objMenuItemTemp.Visible
                objMenuItem.DefaultItem = objMenuItemTemp.DefaultItem

                AddHandler objMenuItem.Click, AddressOf EventHandlerForNodeMenuClick
            Next 'objMenuItemTemp

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub mPrepareRTVTreeMenu()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objMenuItem As System.Windows.Forms.MenuItem
        Dim objMenuItemTemp As TreeList.MenuItem

        Try
            mnuContext.MenuItems.Clear()

            For Each objMenuItemTemp In mobjTreeMenu.MenuItems
                objMenuItem = mnuContext.MenuItems.Add(objMenuItemTemp.Text)

                objMenuItem.Enabled = objMenuItemTemp.Enabled
                objMenuItem.Visible = objMenuItemTemp.Visible
                objMenuItem.DefaultItem = objMenuItemTemp.DefaultItem

                AddHandler objMenuItem.Click, AddressOf EventHandlerForTreeMenuClick
            Next 'objMenuItemTemp

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub EventHandlerForListItemMenuClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objTreeListMenuEventArgs As New TreeList.TreeListMenuEventArgs(sender.index)

        Try
            RaiseEvent ListItemMenuClick(Me, objTreeListMenuEventArgs)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub EventHandlerForListMenuClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objTreeListMenuEventArgs As New TreeList.TreeListMenuEventArgs(sender.index)

        Try
            RaiseEvent ListMenuClick(Me, objTreeListMenuEventArgs)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub EventHandlerForNodeMenuClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objTreeListMenuEventArgs As New TreeList.TreeListMenuEventArgs(sender.index)

        Try
            RaiseEvent NodeMenuClick(Me, objTreeListMenuEventArgs)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

    Private Sub EventHandlerForTreeMenuClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objTreeListMenuEventArgs As New TreeList.TreeListMenuEventArgs(sender.index)

        Try
            RaiseEvent TreeMenuClick(Me, objTreeListMenuEventArgs)

        Catch objException As Exception
            Throw objException

        End Try
    End Sub

#End Region

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

        'HB
        mobjListItemMenu = New TreeList.Menu()
        mobjListMenu = New TreeList.Menu()
        mobjNodeMenu = New TreeList.Menu()
        mobjTreeMenu = New TreeList.Menu()

        mobjColumnHeaderCollection = New TreeList.ColumnHeaderCollection(lvwListView.Columns)
        mobjListImageCollection = New TreeList.ListImageCollection(imlImageList16.Images, imlImageList32.Images)
        mobjListItemCollection = New TreeList.ListItemCollection(lvwListView.Items)
        mobjNodesCollection = New TreeList.NodeCollection(tvwTreeView.Nodes)
        '/HB
    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents imlImageList16 As System.Windows.Forms.ImageList
    Friend WithEvents imlImageList32 As System.Windows.Forms.ImageList
    Friend WithEvents lblTreeView As System.Windows.Forms.Label
    Friend WithEvents tvwTreeView As System.Windows.Forms.TreeView
    Friend WithEvents lblListView As System.Windows.Forms.Label
    Friend WithEvents lvwListView As System.Windows.Forms.ListView
    Friend WithEvents panLeft As System.Windows.Forms.Panel
    Friend WithEvents panRight As System.Windows.Forms.Panel
    Friend WithEvents splSplitter As System.Windows.Forms.Splitter
    Friend WithEvents mnuContext As System.Windows.Forms.ContextMenu
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.imlImageList16 = New System.Windows.Forms.ImageList(Me.components)
        Me.imlImageList32 = New System.Windows.Forms.ImageList(Me.components)
        Me.panLeft = New System.Windows.Forms.Panel()
        Me.tvwTreeView = New System.Windows.Forms.TreeView()
        Me.mnuContext = New System.Windows.Forms.ContextMenu()
        Me.lblTreeView = New System.Windows.Forms.Label()
        Me.panRight = New System.Windows.Forms.Panel()
        Me.lvwListView = New System.Windows.Forms.ListView()
        Me.lblListView = New System.Windows.Forms.Label()
        Me.splSplitter = New System.Windows.Forms.Splitter()
        Me.panLeft.SuspendLayout()
        Me.panRight.SuspendLayout()
        Me.SuspendLayout()
        '
        'imlImageList16
        '
        Me.imlImageList16.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlImageList16.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlImageList16.TransparentColor = System.Drawing.Color.Transparent
        '
        'imlImageList32
        '
        Me.imlImageList32.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlImageList32.ImageSize = New System.Drawing.Size(32, 32)
        Me.imlImageList32.TransparentColor = System.Drawing.Color.Transparent
        '
        'panLeft
        '
        Me.panLeft.Controls.AddRange(New System.Windows.Forms.Control() {Me.tvwTreeView, Me.lblTreeView})
        Me.panLeft.Dock = System.Windows.Forms.DockStyle.Left
        Me.panLeft.Name = "panLeft"
        Me.panLeft.Size = New System.Drawing.Size(200, 612)
        Me.panLeft.TabIndex = 9
        '
        'tvwTreeView
        '
        Me.tvwTreeView.ContextMenu = Me.mnuContext
        Me.tvwTreeView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tvwTreeView.ImageList = Me.imlImageList16
        Me.tvwTreeView.Location = New System.Drawing.Point(0, 19)
        Me.tvwTreeView.Name = "tvwTreeView"
        Me.tvwTreeView.ShowRootLines = False
        Me.tvwTreeView.Size = New System.Drawing.Size(200, 593)
        Me.tvwTreeView.TabIndex = 12
        '
        'mnuContext
        '
        '
        'lblTreeView
        '
        Me.lblTreeView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTreeView.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblTreeView.Name = "lblTreeView"
        Me.lblTreeView.Size = New System.Drawing.Size(200, 19)
        Me.lblTreeView.TabIndex = 11
        Me.lblTreeView.Text = "All Data:"
        Me.lblTreeView.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'panRight
        '
        Me.panRight.Controls.AddRange(New System.Windows.Forms.Control() {Me.lvwListView, Me.lblListView})
        Me.panRight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panRight.Location = New System.Drawing.Point(200, 0)
        Me.panRight.Name = "panRight"
        Me.panRight.Size = New System.Drawing.Size(546, 612)
        Me.panRight.TabIndex = 12
        '
        'lvwListView
        '
        Me.lvwListView.BackColor = System.Drawing.SystemColors.Window
        Me.lvwListView.ContextMenu = Me.mnuContext
        Me.lvwListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lvwListView.FullRowSelect = True
        Me.lvwListView.LargeImageList = Me.imlImageList32
        Me.lvwListView.Location = New System.Drawing.Point(0, 19)
        Me.lvwListView.Name = "lvwListView"
        Me.lvwListView.Size = New System.Drawing.Size(546, 593)
        Me.lvwListView.SmallImageList = Me.imlImageList16
        Me.lvwListView.TabIndex = 13
        Me.lvwListView.View = System.Windows.Forms.View.Details
        '
        'lblListView
        '
        Me.lblListView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblListView.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblListView.Name = "lblListView"
        Me.lblListView.Size = New System.Drawing.Size(546, 19)
        Me.lblListView.TabIndex = 12
        Me.lblListView.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'splSplitter
        '
        Me.splSplitter.Location = New System.Drawing.Point(200, 0)
        Me.splSplitter.MinExtra = 75
        Me.splSplitter.MinSize = 75
        Me.splSplitter.Name = "splSplitter"
        Me.splSplitter.Size = New System.Drawing.Size(3, 612)
        Me.splSplitter.TabIndex = 13
        Me.splSplitter.TabStop = False
        '
        'TreeListControl
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.splSplitter, Me.panRight, Me.panLeft})
        Me.Name = "TreeListControl"
        Me.Size = New System.Drawing.Size(746, 612)
        Me.panLeft.ResumeLayout(False)
        Me.panRight.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
