'**************************************************************************************************
' TreeList TreeListMenu EventArgs/EventHandler:
' Klass/Delegat f�r TreeListMenu events.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler

Public Delegate Sub TreeListMenuEventHandler(ByVal sender As Object, ByVal e As TreeListMenuEventArgs)

Public Class TreeListMenuEventArgs
    Inherits System.EventArgs

#Region "* * * K O N S T A N T E R * * *"

#End Region

#Region "* * * V A R I A B L E R * * *"
    Private mobjHandler As Handler

    Private mintIndex As Integer
#End Region

#Region "* * * P R O P E R T I E S * * *"
    Public Property Index() As Integer
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                Return mintIndex

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
        Set(ByVal Value As Integer)
            Try
                mintIndex = Value

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Set
    End Property
#End Region

#Region "* * * E V E N T S * * *"

#End Region

#Region "* * * P U B L I K A   M E T O D E R * * *"
    Public Sub New(ByVal Index As Integer)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mintIndex = Index

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * P R I V A T A   M E T O D E R * * *"
    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
