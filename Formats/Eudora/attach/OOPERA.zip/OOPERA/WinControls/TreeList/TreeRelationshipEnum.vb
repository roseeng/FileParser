Public Enum TreeRelationshipEnum
    trFirst
    trLast
    trNext
    trPrevious
    trChild
End Enum
