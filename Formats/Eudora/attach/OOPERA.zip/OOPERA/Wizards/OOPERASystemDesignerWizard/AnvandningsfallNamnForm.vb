'**************************************************************************************************
' OOPERASystemDesignerWizard AnvandningsfallNamn Form:
' Formul�r f�r wizarden.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports OOPERA.ExceptionViewer
Imports System.Windows.Forms
Imports System.Xml

Public Class AnvandningsfallNamnForm
    Inherits System.Windows.Forms.Form

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler
    Private mobjViewer As Viewer
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Placera egna variabler h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r ej modifieras
    Public ReadOnly Property XML()
        '******************************************************************************************
        ' Beskrivning: Returnerar XML.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                XML = mstrDataToXML()

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Sub LoadXML(ByVal XML As String)
        '******************************************************************************************
        ' Beskrivning: Laddar formul�ret med indata.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mXMLToData(XML)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        '******************************************************************************************
        ' Beskrivning: Returnerar DialogResult=OK.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Me.Close()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdAvbryt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAvbryt.Click
        '******************************************************************************************
        ' Beskrivning: Returnerar DialogResult=Cancel.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Me.Close()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mShowException(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjViewer Is Nothing Then mobjViewer = New Viewer()

            mobjViewer.Show(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r modifieras internt
    Private Function mstrDataToXML() As String
        '******************************************************************************************
        ' Beskrivning: Transformerar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLAttribute As XmlAttribute
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLElement = objXMLDocument.CreateElement("AnvandningsfallNamnCollection")
            objXMLDocument.AppendChild(objXMLElement)

            objXMLElement = objXMLDocument.CreateElement("AnvandningsfallNamnObject")

            objXMLAttribute = objXMLDocument.CreateAttribute("AnvandningsfallNamn")
            objXMLAttribute.Value = txtAnvandningsfallNamn.Text
            objXMLElement.Attributes.Append(objXMLAttribute)

            objXMLDocument.DocumentElement.AppendChild(objXMLElement)

            Return objXMLDocument.OuterXml

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Sub mXMLToData(ByVal strXML As String)
        '******************************************************************************************
        ' Beskrivning: Laddar formul�ret med indata.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLDocument.LoadXml(strXML)

            For Each objXMLElement In objXMLDocument.SelectNodes("/AnvandningsfallNamnCollection/AnvandningsfallNamnObject")
                txtAnvandningsfallNamn.Text = objXMLElement.Attributes.GetNamedItem("AnvandningsfallNamn").Value
            Next 'objElement

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner
    Private Sub AnvandningsfallNamnForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: Laddar formul�ret.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cmdOK.Enabled = False

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub txtAnvandningsfallNamn_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAnvandningsfallNamn.TextChanged
        '******************************************************************************************
        ' Beskrivning: S�tter cmdOK.Enabled.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cmdOK.Enabled = IIf(txtAnvandningsfallNamn.Text = "", False, True)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub
#End Region

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtAnvandningsfallNamn As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmdOK As Button
    Friend WithEvents cmdAvbryt As Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtAnvandningsfallNamn = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmdAvbryt = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtAnvandningsfallNamn
        '
        Me.txtAnvandningsfallNamn.Location = New System.Drawing.Point(80, 20)
        Me.txtAnvandningsfallNamn.Name = "txtAnvandningsfallNamn"
        Me.txtAnvandningsfallNamn.Size = New System.Drawing.Size(204, 20)
        Me.txtAnvandningsfallNamn.TabIndex = 0
        Me.txtAnvandningsfallNamn.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(10, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Namn:"
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdOK.Location = New System.Drawing.Point(130, 52)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.TabIndex = 2
        Me.cmdOK.Text = "OK"
        '
        'cmdAvbryt
        '
        Me.cmdAvbryt.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdAvbryt.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAvbryt.Location = New System.Drawing.Point(208, 52)
        Me.cmdAvbryt.Name = "cmdAvbryt"
        Me.cmdAvbryt.TabIndex = 3
        Me.cmdAvbryt.Text = "Avbryt"
        '
        'AnvandningsfallNamnForm
        '
        Me.AcceptButton = Me.cmdOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdAvbryt
        Me.ClientSize = New System.Drawing.Size(292, 83)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdAvbryt, Me.cmdOK, Me.Label1, Me.txtAnvandningsfallNamn})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AnvandningsfallNamnForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Anv�ndningsfallsnamn"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
