'**************************************************************************************************
' OOPERASystemDesignerWizard ObjektBeroendeG Form:
' Formul�r f�r wizarden.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports OOPERA.ExceptionHandler
Imports OOPERA.ExceptionViewer
Imports System.Windows.Forms
Imports System.Xml

Public Class ObjektBeroendeGForm
    Inherits System.Windows.Forms.Form

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler
    Private mobjViewer As Viewer
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Placera egna variabler h�r, inga restriktioner
    Private mblnRotObjekt As Boolean
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r ej modifieras
    Public ReadOnly Property XML()
        '******************************************************************************************
        ' Beskrivning: Returnerar XML.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                XML = mstrDataToXML()

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Sub LoadXML(ByVal XML As String)
        '******************************************************************************************
        ' Beskrivning: Laddar formul�ret med indata.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mXMLToData(XML)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        '******************************************************************************************
        ' Beskrivning: Returnerar DialogResult=OK.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Me.Close()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdAvbryt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAvbryt.Click
        '******************************************************************************************
        ' Beskrivning: Returnerar DialogResult=Cancel.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Me.Close()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mShowException(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjViewer Is Nothing Then mobjViewer = New Viewer()

            mobjViewer.Show(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r modifieras internt
    Private Function mstrDataToXML() As String
        '******************************************************************************************
        ' Beskrivning: Transformerar data.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLAttribute As XmlAttribute
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLElement = objXMLDocument.CreateElement("ObjektNamnCollection")
            objXMLDocument.AppendChild(objXMLElement)

            objXMLElement = objXMLDocument.CreateElement("ObjektNamnObject")

            objXMLAttribute = objXMLDocument.CreateAttribute("ObjektNamn")
            objXMLAttribute.Value = Me.Text
            objXMLElement.Attributes.Append(objXMLAttribute)

            objXMLAttribute = objXMLDocument.CreateAttribute("ObjektTyp")
            objXMLAttribute.Value = butRotObjekt.Checked
            objXMLElement.Attributes.Append(objXMLAttribute)

            objXMLAttribute = objXMLDocument.CreateAttribute("BeroendeObjekt")
            objXMLAttribute.Value = IIf(butRotObjekt.Checked, "", cboRotObjekt.Text)
            objXMLElement.Attributes.Append(objXMLAttribute)

            objXMLDocument.DocumentElement.AppendChild(objXMLElement)

            Return objXMLDocument.OuterXml

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Sub mXMLToData(ByVal strXML As String)
        '******************************************************************************************
        ' Beskrivning: Laddar formul�ret med indata.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try
            objXMLDocument.LoadXml(strXML)

            For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/ObjektNamnObject")
                Me.Text = objXMLElement.Attributes.GetNamedItem("ObjektNamn").Value
                mblnRotObjekt = objXMLElement.Attributes.GetNamedItem("ObjektTyp").Value
            Next 'objElement

            For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/RotObjektCollection/RotObjektObject")
                cboRotObjekt.Items.Add(objXMLElement.Attributes.GetNamedItem("ObjektNamn").Value)
            Next 'objElement

            For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/ObjektNamnObject")
                If Not mblnRotObjekt Then cboRotObjekt.Text = objXMLElement.Attributes.GetNamedItem("BeroendeObjekt").Value
            Next 'objElement

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner
    Private Sub ObjektBeroendeGForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: Laddar formul�ret.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mblnRotObjekt Then
                butRotObjekt.Select()

                cboRotObjekt.Enabled = False

                If cboRotObjekt.Items.Count = 0 Then butObjekt.Enabled = False
            Else
                butObjekt.Select()

                cboRotObjekt.Enabled = True
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub butObjekt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butObjekt.Click
        '******************************************************************************************
        ' Beskrivning: S�tter cboRotObjekt.Enabled.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cboRotObjekt.Enabled = True

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub butRotObjekt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butRotObjekt.Click
        '******************************************************************************************
        ' Beskrivning: S�tter cboRotObjekt.Enabled.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cboRotObjekt.Enabled = False

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub
#End Region

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdOK As Button
    Friend WithEvents cmdAvbryt As Button
    Friend WithEvents butObjekt As RadioButton
    Friend WithEvents butRotObjekt As RadioButton
    Friend WithEvents cboRotObjekt As ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmdAvbryt = New System.Windows.Forms.Button()
        Me.butObjekt = New System.Windows.Forms.RadioButton()
        Me.butRotObjekt = New System.Windows.Forms.RadioButton()
        Me.cboRotObjekt = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdOK.Location = New System.Drawing.Point(130, 104)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.TabIndex = 2
        Me.cmdOK.Text = "OK"
        '
        'cmdAvbryt
        '
        Me.cmdAvbryt.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdAvbryt.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAvbryt.Location = New System.Drawing.Point(208, 104)
        Me.cmdAvbryt.Name = "cmdAvbryt"
        Me.cmdAvbryt.TabIndex = 3
        Me.cmdAvbryt.Text = "Avbryt"
        '
        'butObjekt
        '
        Me.butObjekt.Location = New System.Drawing.Point(10, 46)
        Me.butObjekt.Name = "butObjekt"
        Me.butObjekt.Size = New System.Drawing.Size(130, 20)
        Me.butObjekt.TabIndex = 18
        Me.butObjekt.Text = "Objekt"
        '
        'butRotObjekt
        '
        Me.butRotObjekt.Location = New System.Drawing.Point(10, 20)
        Me.butRotObjekt.Name = "butRotObjekt"
        Me.butRotObjekt.Size = New System.Drawing.Size(130, 20)
        Me.butRotObjekt.TabIndex = 17
        Me.butRotObjekt.Text = "Rotobjekt"
        '
        'cboRotObjekt
        '
        Me.cboRotObjekt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRotObjekt.Location = New System.Drawing.Point(50, 72)
        Me.cboRotObjekt.Name = "cboRotObjekt"
        Me.cboRotObjekt.Size = New System.Drawing.Size(232, 21)
        Me.cboRotObjekt.Sorted = True
        Me.cboRotObjekt.TabIndex = 19
        '
        'ObjektBeroendeGForm
        '
        Me.AcceptButton = Me.cmdOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdAvbryt
        Me.ClientSize = New System.Drawing.Size(292, 135)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cboRotObjekt, Me.butObjekt, Me.butRotObjekt, Me.cmdAvbryt, Me.cmdOK})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ObjektBeroendeGForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Objektberoende"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
