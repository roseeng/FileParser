'**************************************************************************************************
' OOPERASystemDesignerWizard Wizard Class:
' Applikationsklass f�r wizard.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports EnvDTE
Imports OOPERA.ExceptionHandler

Public Class Wizard

#Region "* * * S T A T I S K A   K O N S T A N T E R * * *"
    'Dessa konstanter f�r ej modifieras
    Const WIZARD_DISPLAYNAME As String = "OOPERA SystemDesigner Wizard" '"OOPERA <'WizardDisplayName'> Wizard"
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler

    Private mobjVSInstance As DTE
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa metoder f�r ej modifieras
    Public ReadOnly Property DisplayName() As String
        '******************************************************************************************
        ' Beskrivning: Returnerar DisplayName.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Get
            Try
                DisplayName = WIZARD_DISPLAYNAME

            Catch objException As Exception
                Throw mobjFormatException(objException)

            End Try
        End Get
    End Property

    Public Sub Load(ByVal VSInstance As DTE)
        '******************************************************************************************
        ' Beskrivning: Visar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New WizardForm(VSInstance, WIZARD_DISPLAYNAME)

        Try
            frm.ShowDialog()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub


    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function
#End Region

End Class
