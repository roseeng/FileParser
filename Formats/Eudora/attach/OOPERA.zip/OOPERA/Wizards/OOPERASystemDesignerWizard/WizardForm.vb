'**************************************************************************************************
' OOPERASystemDesignerWizard Wizard Form:
' Formul�r f�r wizarden.
'**************************************************************************************************
' Skapad: 2002-02-29 Av: H�kan Borg
' �ndrad:            Av:
'**************************************************************************************************
Option Explicit On 

Imports EnvDTE
Imports OOPERA.ExceptionHandler
Imports OOPERA.ExceptionViewer
Imports System.Windows.Forms
Imports System.Xml

Friend Class WizardForm
    Inherits Form

#Region "* * * S T A T I S K A   K O N S T A N T E R * * *"
    'Dessa konstanter f�r ej modifieras
    Private Const NAVIGATOR_BACK As Long = 2
    Private Const NAVIGATOR_CANCEL As Long = 1
    Private Const NAVIGATOR_NEXT_FINISH As Long = 3

    Private Const STEP_START As Long = 0
#End Region

#Region "* * * D Y N A M I S K A   K O N S T A N T E R * * *"
    '<START ANPASSA KOD>
    'Skapa konstanter f�r varje steg
    Private Const STEP_1 As Long = 1
    Private Const STEP_2 As Long = 2
    Private Const STEP_3 As Long = 3
    Private Const STEP_4 As Long = 4
    Private Const STEP_5 As Long = 5
    Private Const STEP_6 As Long = 6
    Private Const STEP_FINISH As Long = 6 + 1
    '<SLUT ANPASSA KOD>
#End Region

#Region "* * * S P E C I F I K A   K O N S T A N T E R * * *"
    'Placera egna konstanter h�r, inga restriktioner
#End Region

#Region "* * * S T A T I S K A   V A R I A B L E R * * *"
    'Dessa variabler f�r ej modifieras
    Private mobjHandler As Handler
    Private mobjViewer As Viewer

    Private mblnTerminateSession As Boolean
    Private mcolInstruction As New Collection()
    Private mcolStep As New Collection()
    Private mintCurrentStep As Integer
    Private mobjVSInstance As DTE
    Private mstrDisplayName As String
#End Region

#Region "* * * S P E C I F I K A   V A R I A B L E R * * *"
    'Dimensionera egna variabler h�r, inga restriktioner
    Private mintGUI As Integer
    Private mintPlatform As Integer
    Private mstrComponentArray() As String
    Private mstrSystemName As String
    Private mstrPath As String
    Private mstrPath2 As String
    Private mstrProjectName As String
    Private mstrUseCaseArray() As String
#End Region

#Region "* * * S T A T I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r ej modifieras
    Public Sub New(ByVal VSInstance As DTE, ByVal DisplayName As String)
        '******************************************************************************************
        ' Beskrivning: Overloads Default Constructor.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Me.New()

        Try
            mobjVSInstance = VSInstance
            mstrDisplayName = DisplayName

            Me.Width = 503
            Me.Height = 385
            Me.Text = mstrDisplayName

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        '******************************************************************************************
        ' Beskrivning: Navigerar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mCancel()

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdNext_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNext.Click
        '******************************************************************************************
        ' Beskrivning: Navigerar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Cursor.Current = Cursors.WaitCursor

            If mintCurrentStep = STEP_FINISH Then
                mApply()
            Else
                If mblnValidate(mintCurrentStep) Then
                    mSetVariables(mintCurrentStep)
                    mSetStep(mintCurrentStep + 1)
                End If
            End If

        Catch objException As Exception
            mShowException(objException)

        Finally
            Cursor.Current = Cursors.Default

        End Try
    End Sub

    Private Sub cmdPrevious_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrevious.Click
        '******************************************************************************************
        ' Beskrivning: Navigerar wizarden.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mSetStep(mintCurrentStep - 1)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub WizardForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        '******************************************************************************************
        ' Beskrivning: F�rhindrar att formul�ret st�ngs via ControlMenu.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If Not mblnTerminateSession Then e.Cancel = True

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub WizardForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '******************************************************************************************
        ' Beskrivning: Initieringar.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mInitControls()

            mSetStep(STEP_START)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mCancel()
        '******************************************************************************************
        ' Beskrivning: St�nger formul�ret.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mblnTerminateSession = True

            Me.Close()

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mInitControls()
        '******************************************************************************************
        ' Beskrivning: Initiering av kontroller.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim l As Long

        Try
            mCreateGroupBoxCollections()
            mSetInstructionLabels()

            For l = STEP_START + 1 To STEP_FINISH - 1
                With CType(mcolStep.Item(l), GroupBox)
                    .Left = -2
                    .Top = -8
                    .Width = Me.Width
                    .Height = Me.Height - 62

                    .Text = ""
                End With

                With CType(mcolInstruction.Item(l), GroupBox)
                    .Left = -2
                    .Top = -8
                    .Width = Me.Width
                    .Height = Me.Height - 316

                    .Text = ""
                End With
            Next 'l

            With grpStart
                .Left = -2
                .Top = -8
                .Width = Me.Width
                .Height = Me.Height - 62

                .Text = ""
            End With

            With grpFinish
                .Left = -2
                .Top = -8
                .Width = Me.Width
                .Height = Me.Height - 62

                .Text = ""
            End With

            With picLeftMarginStart
                .Left = 0
                .Top = 0
                .Width = 166
                .Height = 321
            End With

            With picLeftMarginFinish
                .Left = 0
                .Top = 0
                .Width = 166
                .Height = 321
            End With

            With lblStart
                .Left = 200
                .Top = 80
                .Width = 264
                .Height = 98

                .Text = "V�lkommen till " & mstrDisplayName
            End With

            With lblFinish
                .Left = 200
                .Top = 80
                .Width = 264
                .Height = 98

                .Text = "Tryck p� Slutf�r f�r att genomf�ra �tg�rderna"
            End With

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mSetFrame(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Hanterar gruppboxar.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim l As Long

        Try
            For l = STEP_START + 1 To STEP_FINISH - 1
                mcolStep.Item(l).Left = -10000
            Next 'l
            grpStart.Left = -10000
            grpFinish.Left = -10000

            Select Case lngStep
                Case STEP_START
                    grpStart.Left = -2
                Case STEP_FINISH
                    grpFinish.Left = -2
                Case Else
                    mcolStep.Item(lngStep).Left = -2
            End Select

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mSetNavigator(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Hanterar navigationsknappar.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            Select Case lngStep
                Case STEP_START
                    cmdPrevious.Enabled = False
                    cmdNext.Enabled = True

                    cmdNext.Text = "&N�sta >"
                Case STEP_FINISH
                    cmdPrevious.Enabled = True
                    cmdNext.Enabled = True

                    cmdNext.Text = "&Slutf�r"
                Case Else
                    cmdPrevious.Enabled = True
                    cmdNext.Enabled = True

                    cmdNext.Text = "&N�sta >"
            End Select

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mSetStep(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Hanterar navigeringsf�ruts�ttningar och frames.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            mSetNavigator(lngStep)
            mSetFrame(lngStep)

            mintCurrentStep = lngStep

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

    Private Sub mShowException(ByVal objException As Exception)
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjViewer Is Nothing Then mobjViewer = New Viewer()

            mobjViewer.Show(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Sub
#End Region

#Region "* * * D Y N A M I S K A   M E T O D E R * * *"
    'Dessa events, properties och metoder f�r modifieras internt
    Private Sub mApply()
        '******************************************************************************************
        ' Beskrivning: Genomf�r �nskade �tg�rder.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSolution As Solution
        Dim i As Integer
        Dim intUseCase As Integer

        Try
            Cursor.Current = Cursors.WaitCursor

            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att genomf�ra �nskade �tg�rder
            objSolution = mobjVSInstance.Solution()

            For i = 1 To objSolution.Count
                objSolution.Remove(objSolution.Projects.Item(i))
            Next 'i

            Select Case 1 'mintGUI
                Case 1 'VBGUI
                    objSolution.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "OOPERA.vsz", "C:\Junk\Fan", "LUSER", False)
                    'objSolution.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "OOPERA Win32 GUI.vsz", "C:\Junk\Fan", "LUSER", False)
                Case 2 'WebbGUI
                    'ASP mallar
                    'mCreateASP mobjVSInstance.TemplatePath
                Case 3 'VB & WebbGUI
                    objSolution.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "OOPERA Win32 Start.vsz", "C:\Junk\Fan", "LUSER", False)
                Case 4 'Inget GUI
                    'Inget alls
            End Select

            'mReplaceTags(objSolution, mstrProjectName, "", lngLastFile)
            mReplaceTags(objSolution, "LUSER", "")

            If UBound(mstrUseCaseArray) > 0 Then
                objSolution.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "OOPERA UseCase.vsz", "C:\Junk\Fan", "LUSER", False)

                For i = 2 To UBound(mstrUseCaseArray)
                    objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Kklass", "C:\Junk\Fan")
                Next 'i

                mReplaceTags(objSolution, "LUSER", "LUSER")

                For i = 1 To objSolution.Item(objSolution.Count).VBComponents.Count
                    'Ett anv�ndningsfall och en rsfactory initialt... 'Beklagar h�rdk�den
                    If InStr(objSolution.Item(objSolution.Count).VBComponents(i).Name, "CAnvandningsfallsnamn") > 0 Then
                        intUseCase = intUseCase + 1
                        mReplaceTagsK(objSolution.Item(objSolution.Count).VBComponents(i), mstrUseCaseArray(intUseCase))
                    End If
                Next 'i
            End If

            For i = 1 To UBound(mstrComponentArray)

                Select Case mintGUI
                    Case 1 'VBGUI
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Gklass", "C:\Junk\Fan")
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "GWkomponent", "C:\Junk\Fan")
                    Case 2 'WebbGUI
                        'ASP mallar
                    Case 3 'VB & WebbGUI
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Gklass", "C:\Junk\Fan")
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "GWkomponent", "C:\Junk\Fan")

                        'ASP mallar
                    Case 4 'Inget GUI
                        'Inget alls
                End Select

                objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Pklass", "C:\Junk\Fan")

                Select Case mintPlatform
                    Case 1 'NT
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Dklass", "C:\Junk\Fan")
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Mklass", "C:\Junk\Fan")
                    Case 2 'AS/400 , OS/390
                        objSolution.Item(objSolution.Count).ProjectItems.AddFromTemplate(objSolution.TemplatePath(VSLangProj.PrjKind.prjKindVBProject) & "Mklass", "C:\Junk\Fan")
                End Select

                mReplaceTags(objSolution, "LUSER", mstrComponentArray(i))
            Next 'i

            'mSaveFiles(objSolution)

            ''Vi g�r asp bitarna skilt fr�n vb bitarna
            'Select Case mintGUI
            '    Case 2 'WebbGUI
            '        'ASP mallar
            '        mCreateASP(mobjVSInstance.TemplatePath)
            '    Case 3 'VB & WebbGUI
            '        'ASP mallar
            '        mCreateASP(mobjVSInstance.TemplatePath)
            'End Select

            objSolution.Close(False) 'true VBE.Quit() 'kanske refresh p� alla filer h�r
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw mobjFormatException(objException)

        Finally
            Cursor.Current = Cursors.Default

        End Try
    End Sub

    Private Function mblnValidate(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: Validering.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'Implementera den kod som kr�vs f�r att validera indata per lngStep
            Select Case lngStep
                Case STEP_1
                    If (txtStep1Nytt.Text = "" And txtStep1Oppna.Text = "") Then
                        'MessageBox.Show("Felmeddelande")

                        Return False
                    End If
                Case STEP_2
                    'If Not villkor Then mblnValidate = False
                Case STEP_3
                    If lvwStep3.Items.Count = 0 Then
                        'MessageBox.Show("Felmeddelande")

                        Return False
                    End If
                Case STEP_4
                    'If Not villkor Then mblnValidate = False
                Case STEP_5
                    'If Not villkor Then mblnValidate = False
                Case STEP_6
                    'If Not villkor Then mblnValidate = False
                Case Else
            End Select
            '<SLUT ANPASSA KOD>

            Return True

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Sub mCreateGroupBoxCollections()
        '******************************************************************************************
        ' Beskrivning: Skapar kontrollarrayer av grpStep och grpInstruction.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'L�gg till alla grpStep och grpInstruction till respektive kollektioner
            mcolStep.Add(grpStep1)
            mcolStep.Add(grpStep2)
            mcolStep.Add(grpStep3)
            mcolStep.Add(grpStep4)
            mcolStep.Add(grpStep5)
            mcolStep.Add(grpStep6)

            mcolInstruction.Add(grpInstruction1)
            mcolInstruction.Add(grpInstruction2)
            mcolInstruction.Add(grpInstruction3)
            mcolInstruction.Add(grpInstruction4)
            mcolInstruction.Add(grpInstruction5)
            mcolInstruction.Add(grpInstruction6)
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mSetInstructionLabels()
        '******************************************************************************************
        ' Beskrivning: S�tter texterna f�r lblInstruction.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            '<START ANPASSA KOD>
            'S�tt instruktionstexter till varje steg
            lblInstruction1.Text = "V�lj mellan att skapa ett nytt system eller �ppna beskrivningen av ett redan skapat system."
            lblInstruction2.Text = "V�lj vilken typ av anv�ndargr�nssnitt som skall applikationen skall st�dja."
            lblInstruction3.Text = "Ange de objekt som applikationen best�r av."
            lblInstruction4.Text = "F�r Datatj�nstlagret: Ange vilket eller vilka huvudobjekt som finns. Ange d�refter vilka objekt som �r underordnade dessa."
            lblInstruction5.Text = "F�r Anv�ndargr�nssnittet: Ange vilket eller vilka objekt som skall fungera som Console rot. Ange d�refter vilka objekt som �r underordnade det eller dessa."
            lblInstruction6.Text = "Ange de anv�ndningsfall som applikationen best�r av."
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mSetVariables(ByVal lngStep As Long)
        '******************************************************************************************
        ' Beskrivning: S�tter variabler och kontroller.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av: 
        '******************************************************************************************
        Dim objListViewItem As ListViewItem
        Dim objListViewItemClone As ListViewItem

        Try
            '<START ANPASSA KOD>
            'S�tt variabel- och kontrollv�rden per lngStep
            Select Case lngStep
                Case STEP_START 's�tt kontroller f�r steg 1
                    butStep1Oppna.Enabled = False
                    txtStep1Oppna.Enabled = False
                Case STEP_1 's�tt variabler f�r steg 1, s�tt kontroller f�r steg 1+1
                    butStep2Webb.Enabled = False
                    butStep2WindowsWebb.Enabled = False
                Case STEP_2 's�tt variabler f�r steg 2, s�tt kontroller f�r steg 2+1
                    cmdStep3Andra.Enabled = False
                    cmdStep3TaBort.Enabled = False
                Case STEP_3 's�tt variabler f�r steg 3, s�tt kontroller f�r steg 3+1
                    lvwStep4.Items.Clear()

                    For Each objListViewItem In lvwStep3.Items
                        objListViewItemClone = objListViewItem.Clone

                        objListViewItemClone.SubItems.Add("HuvudObjekt")
                        objListViewItemClone.SubItems.Add("")

                        lvwStep4.Items.Add(objListViewItemClone)
                    Next 'objListViewItem

                Case STEP_4 's�tt variabler f�r steg 4, s�tt kontroller f�r steg 4+1
                    lvwStep5.Items.Clear()

                    For Each objListViewItem In lvwStep3.Items
                        objListViewItemClone = objListViewItem.Clone

                        objListViewItemClone.SubItems.Add("RotObjekt")
                        objListViewItemClone.SubItems.Add("")

                        lvwStep5.Items.Add(objListViewItemClone)
                    Next 'objListViewItem

                Case STEP_5 's�tt variabler f�r steg 5, s�tt kontroller f�r steg 5+1
                    cmdStep6Andra.Enabled = False
                    cmdStep6TaBort.Enabled = False
                Case STEP_6 's�tt variabler f�r steg 6

                Case Else
            End Select
            '<SLUT ANPASSA KOD>

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region "* * * S P E C I F I K A   M E T O D E R * * *"
    'Placera egna events, properties och metoder h�r, inga restriktioner
    Private Sub cmdStep1Ellipse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '******************************************************************************************
        ' Beskrivning: Visar CommonDialog f�r systembeskrivningsfil.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            'Common Dialog.......................
            'C:\\Systemnamnet\Systemnamnet.sbw

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep3Andra_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStep3Andra.Click
        '******************************************************************************************
        ' Beskrivning: �ndrar ett ObjektNamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New ObjektNamnForm()

        Try
            If lvwStep3.SelectedItems.Count = 0 Then lvwStep3.Items.Item(0).Selected = True

            frm.LoadXML(mstrPrepareXML(frm.Name, False))

            If frm.ShowDialog(Me) = DialogResult.OK Then
                mParseXML(frm.Name, frm.XML, False)
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep3LaggTill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStep3LaggTill.Click
        '******************************************************************************************
        ' Beskrivning: L�gger till ett ObjektNamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New ObjektNamnForm()

        Try
            frm.LoadXML(mstrPrepareXML(frm.Name, True))

            If frm.ShowDialog(Me) = DialogResult.OK Then
                mParseXML(frm.Name, frm.XML, True)
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep3TaBort_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStep3TaBort.Click
        '******************************************************************************************
        ' Beskrivning: Tar bort ett ObjektNamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If lvwStep3.SelectedItems.Count = 0 Then lvwStep3.Items.Item(0).Selected = True

            If MessageBox.Show("Vill du ta bort " & lvwStep3.SelectedItems.Item(0).Text & "?", "Borttag", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                lvwStep3.SelectedItems.Item(0).Remove()

                If lvwStep3.Items.Count = 0 Then
                    cmdStep3Andra.Enabled = False
                    cmdStep3TaBort.Enabled = False
                End If
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep4Andra_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStep4Andra.Click
        '******************************************************************************************
        ' Beskrivning: �ndrar ett objekts beroende f�r D-lager.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New ObjektBeroendeDForm()

        Try
            frm.LoadXML(mstrPrepareXML(frm.Name, False))

            If frm.ShowDialog(Me) = DialogResult.OK Then
                mParseXML(frm.Name, frm.XML, False)
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep5Andra_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStep5Andra.Click
        '******************************************************************************************
        ' Beskrivning: �ndrar ett objekts beroende f�r G-lager.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New ObjektBeroendeGForm()

        Try
            frm.LoadXML(mstrPrepareXML(frm.Name, False))

            If frm.ShowDialog(Me) = DialogResult.OK Then
                mParseXML(frm.Name, frm.XML, False)
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep6Andra_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStep6Andra.Click
        '******************************************************************************************
        ' Beskrivning: �ndrar ett Anv�ndningsfallNamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New AnvandningsfallNamnForm()

        Try
            If lvwStep3.SelectedItems.Count = 0 Then lvwStep3.Items.Item(0).Selected = True

            frm.LoadXML(mstrPrepareXML(frm.Name, False))

            If frm.ShowDialog(Me) = DialogResult.OK Then
                mParseXML(frm.Name, frm.XML, False)
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep6LaggTill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStep6LaggTill.Click
        '******************************************************************************************
        ' Beskrivning: L�gger till ett Anv�ndningsfallNamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim frm As New AnvandningsfallNamnForm()

        Try
            frm.LoadXML(mstrPrepareXML(frm.Name, True))

            If frm.ShowDialog(Me) = DialogResult.OK Then
                mParseXML(frm.Name, frm.XML, True)
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub cmdStep6TaBort_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStep6TaBort.Click
        '******************************************************************************************
        ' Beskrivning: Tar bort ett Anv�ndningsfallNamn.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If lvwStep6.SelectedItems.Count = 0 Then lvwStep6.Items.Item(0).Selected = True

            If MessageBox.Show("Vill du ta bort " & lvwStep6.SelectedItems.Item(0).Text & "?", "Borttag", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                lvwStep6.SelectedItems.Item(0).Remove()

                If lvwStep6.Items.Count = 0 Then
                    cmdStep6Andra.Enabled = False
                    cmdStep6TaBort.Enabled = False
                End If
            End If

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub lvwStep3_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwStep3.DoubleClick
        '******************************************************************************************
        ' Beskrivning: Utf�r cmdStep3Andra_Click.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cmdStep3Andra_Click(sender, e)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub lvwStep4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwStep4.Click
        '******************************************************************************************
        ' Beskrivning: S�tter cmdStep4Andra.Enabled.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListViewItem As ListViewItem

        Try
            cmdStep4Andra.Enabled = True

            For Each objListViewItem In lvwStep4.Items
                If lvwStep4.SelectedItems.Item(0).Text = objListViewItem.SubItems.Item(2).Text Then
                    cmdStep4Andra.Enabled = False
                    Exit For
                End If
            Next 'objListViewItem

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub lvwStep4_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwStep4.DoubleClick
        '******************************************************************************************
        ' Beskrivning: Utf�r cmdStep4Andra_Click.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cmdStep4Andra_Click(sender, e)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub lvwStep5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwStep5.Click
        '******************************************************************************************
        ' Beskrivning: S�tter cmdStep5Andra.Enabled.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objListViewItem As ListViewItem

        Try
            cmdStep5Andra.Enabled = False

            For Each objListViewItem In lvwStep5.Items
                If objListViewItem.SubItems.Item(1).Text = "RotObjekt" Then
                    cmdStep5Andra.Enabled = True
                    Exit For
                End If
            Next 'objListViewItem

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub lvwStep5_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwStep5.DoubleClick
        '******************************************************************************************
        ' Beskrivning: Utf�r cmdStep5Andra_Click.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cmdStep5Andra_Click(sender, e)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    Private Sub lvwStep6_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwStep6.DoubleClick
        '******************************************************************************************
        ' Beskrivning: Utf�r cmdStep6Andra_Click.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            cmdStep6Andra_Click(sender, e)

        Catch objException As Exception
            mShowException(objException)

        End Try
    End Sub

    'Private Sub mReplaceTags(ByVal objSolution As Solution, ByVal strSystemName As String, ByVal strComponentName As String, ByRef lngLastFile As Long)
    Private Sub mReplaceTags(ByVal objSolution As Solution, ByVal strSystemName As String, ByVal strComponentName As String)
        '******************************************************************************************
        ' Beskrivning: Ers�tter tagar med "data".
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objProject As EnvDTE.Project
        Dim objProjectItem As EnvDTE.ProjectItem
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim strTemp As String

        Dim objStartPoint As EditPoint
        Dim objEndPoint As EditPoint
        '        Dim objCodeElement As CodeElement


        Dim objTextDoc As TextDocument
        '       Dim objEditPt As EditPoint, iCtr As Integer

        Try
            For Each objProject In objSolution.Projects
                For Each objProjectItem In objProject.ProjectItems
                    Try
                        objProjectItem.Open(Constants.vsViewKindTextView)

                        objTextDoc = objProjectItem.Document.Object("TextDocument")

                        objStartPoint = objTextDoc.StartPoint.CreateEditPoint
                        objStartPoint.Insert("'H�kan rules!" & vbCrLf)
                        objStartPoint.Insert("'FUCK U!" & vbCrLf)
                        objStartPoint.Insert("'" & objProjectItem.Name & "!" & vbCrLf)

                    Catch objException As Exception
                        'Det �r ok

                    End Try
                Next 'objProjectItem

                For Each objProjectItem In objProject.ProjectItems
                    MsgBox(objProjectItem.Name & " : " & objProjectItem.Kind)

                    Try
                        objProjectItem.Open(Constants.vsViewKindTextView)

                        objTextDoc = objProjectItem.Document.Object("TextDocument")

                        objStartPoint = objTextDoc.StartPoint.CreateEditPoint()
                        objEndPoint = objTextDoc.StartPoint.CreateEditPoint()

                        While Not objStartPoint.AtEndOfDocument()
                            objStartPoint.StartOfLine()
                            objEndPoint.EndOfLine()

                            strTemp = objStartPoint.GetText(objEndPoint)

                            If InStr(UCase(strTemp), "<'SYSTEMNAMN'>") > 0 Then
                                strTemp = Replace(strTemp, "<'SYSTEMNAMN'>", strSystemName)

                                objStartPoint.ReplaceText(objEndPoint, strTemp, vsEPReplaceTextOptions.vsEPReplaceTextAutoformat)
                            End If

                            If InStr(UCase(strTemp), "<'KOMPONENTNAMN'>") > 0 Then
                                strTemp = Replace(strTemp, "<'KOMPONENTNAMN'>", strComponentName)

                                objStartPoint.ReplaceText(objEndPoint, strTemp, vsEPReplaceTextOptions.vsEPReplaceTextAutoformat)
                            End If

                            If InStr(UCase(strTemp), "<'ObjektNamn'>") > 0 Then
                                strTemp = Replace(strTemp, "<'ObjektNamn'>", strComponentName)

                                objStartPoint.ReplaceText(objEndPoint, strTemp, vsEPReplaceTextOptions.vsEPReplaceTextAutoformat)
                            End If

                            'If Right(objProject.Name, 1) = "M" And mlngPlatform = 2 Then  'ej NT, ta bort referens till D-komponent
                            '    If InStr(strTemp, " objD") > 0 Then
                            '        objProjectItem.CodeModule.ReplaceLine(j, "'" & strTemp)
                            '    End If
                            'End If

                            objStartPoint.LineDown()
                            objEndPoint.LineDown()

                            If objStartPoint.AtEndOfDocument() Then objStartPoint.Insert("OLLONborre")
                        End While

                    Catch objException As Exception
                        'Det �r ok

                    End Try

                    'If objProjectItem.Type = vbext_ct_UserControl Then
                    '    objProjectItem.Properties("Name").Value = slb.ReplaceString(objProjectItem.Name, "ObjektNamn", strComponentName)
                    'Else
                    '    objProjectItem.Name = slb.ReplaceString(objProjectItem.Name, "ObjektNamn", strComponentName)
                    'End If
                Next 'objProjectItem

                'objProject.Name = slb.ReplaceString(objProject.Name, "Komponent", strComponentName)
                'objProject.Name = slb.ReplaceString(objProject.Name, "Systemnamn", mstrProjectName)
            Next 'objProject

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Sub mReplaceTagsK(ByVal objProjectItem As ProjectItem, ByVal strUseCaseName As String)
        '******************************************************************************************
        ' Beskrivning: Ers�tter tagar med "data".
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    Private Function mstrPrepareXML(ByVal strFormName As String, ByVal blnAdd As Boolean) As String
        '******************************************************************************************
        ' Beskrivning: XMLerar indata till underformul�r.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLAttribute As XmlAttribute
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement
        Dim objXMLElement2 As XmlElement
        Dim objListViewItem As ListViewItem

        Try
            Select Case strFormName
                Case "ObjektNamnForm"
                    If blnAdd Then
                        objXMLElement = objXMLDocument.CreateElement("ObjektNamnCollection")
                        objXMLDocument.AppendChild(objXMLElement)
                    Else
                        objXMLElement = objXMLDocument.CreateElement("ObjektNamnCollection")
                        objXMLDocument.AppendChild(objXMLElement)

                        objXMLElement = objXMLDocument.CreateElement("ObjektNamnObject")

                        objXMLAttribute = objXMLDocument.CreateAttribute("ObjektNamn")
                        objXMLAttribute.Value = lvwStep3.SelectedItems.Item(0).Text
                        objXMLElement.Attributes.Append(objXMLAttribute)

                        objXMLDocument.DocumentElement.AppendChild(objXMLElement)
                    End If

                Case "ObjektBeroendeDForm"
                    If blnAdd Then
                    Else
                        If Not lvwStep4.Items.Count = 0 Then
                            If lvwStep4.SelectedItems.Count = 0 Then lvwStep4.Items.Item(0).Selected = True

                            objXMLElement = objXMLDocument.CreateElement("ObjektNamnCollection")
                            objXMLDocument.AppendChild(objXMLElement)

                            objXMLElement = objXMLDocument.CreateElement("ObjektNamnObject")

                            objXMLAttribute = objXMLDocument.CreateAttribute("ObjektNamn")
                            objXMLAttribute.Value = lvwStep4.SelectedItems.Item(0).Text
                            objXMLElement.Attributes.Append(objXMLAttribute)

                            objXMLAttribute = objXMLDocument.CreateAttribute("ObjektTyp")
                            objXMLAttribute.Value = IIf(lvwStep4.SelectedItems.Item(0).SubItems.Item(1).Text = "HuvudObjekt", True, False)
                            objXMLElement.Attributes.Append(objXMLAttribute)

                            objXMLAttribute = objXMLDocument.CreateAttribute("BeroendeObjekt")
                            objXMLAttribute.Value = lvwStep4.SelectedItems.Item(0).SubItems.Item(2).Text
                            objXMLElement.Attributes.Append(objXMLAttribute)

                            objXMLDocument.DocumentElement.AppendChild(objXMLElement)

                            objXMLElement = objXMLDocument.CreateElement("HuvudObjektCollection")

                            For Each objListViewItem In lvwStep4.Items
                                If Not objListViewItem.Equals(lvwStep4.SelectedItems.Item(0)) Then
                                    If objListViewItem.SubItems.Item(1).Text = "HuvudObjekt" Then
                                        objXMLElement2 = objXMLDocument.CreateElement("HuvudObjektObject")

                                        objXMLAttribute = objXMLDocument.CreateAttribute("ObjektNamn")
                                        objXMLAttribute.Value = objListViewItem.Text
                                        objXMLElement2.Attributes.Append(objXMLAttribute)

                                        objXMLElement.AppendChild(objXMLElement2)
                                    End If
                                End If
                            Next 'objListViewItem

                            objXMLDocument.DocumentElement.AppendChild(objXMLElement)
                        End If
                    End If

                Case "ObjektBeroendeGForm"
                    If blnAdd Then
                    Else
                        If Not lvwStep5.Items.Count = 0 Then
                            If lvwStep5.SelectedItems.Count = 0 Then lvwStep5.Items.Item(0).Selected = True

                            objXMLElement = objXMLDocument.CreateElement("ObjektNamnCollection")
                            objXMLDocument.AppendChild(objXMLElement)

                            objXMLElement = objXMLDocument.CreateElement("ObjektNamnObject")

                            objXMLAttribute = objXMLDocument.CreateAttribute("ObjektNamn")
                            objXMLAttribute.Value = lvwStep5.SelectedItems.Item(0).Text
                            objXMLElement.Attributes.Append(objXMLAttribute)

                            objXMLAttribute = objXMLDocument.CreateAttribute("ObjektTyp")
                            objXMLAttribute.Value = IIf(lvwStep5.SelectedItems.Item(0).SubItems.Item(1).Text = "RotObjekt", True, False)
                            objXMLElement.Attributes.Append(objXMLAttribute)

                            objXMLAttribute = objXMLDocument.CreateAttribute("BeroendeObjekt")
                            objXMLAttribute.Value = lvwStep5.SelectedItems.Item(0).SubItems.Item(2).Text
                            objXMLElement.Attributes.Append(objXMLAttribute)

                            objXMLDocument.DocumentElement.AppendChild(objXMLElement)

                            objXMLElement = objXMLDocument.CreateElement("RotObjektCollection")

                            For Each objListViewItem In lvwStep5.Items
                                objXMLElement2 = objXMLDocument.CreateElement("RotObjektObject")

                                objXMLAttribute = objXMLDocument.CreateAttribute("ObjektNamn")
                                objXMLAttribute.Value = objListViewItem.Text
                                objXMLElement2.Attributes.Append(objXMLAttribute)

                                objXMLElement.AppendChild(objXMLElement2)
                            Next 'objListViewItem

                            objXMLDocument.DocumentElement.AppendChild(objXMLElement)
                        End If
                    End If

                Case "AnvandningsfallNamnForm"
                    If blnAdd Then
                        objXMLElement = objXMLDocument.CreateElement("AnvandningsfallNamnCollection")
                        objXMLDocument.AppendChild(objXMLElement)
                    Else
                        objXMLElement = objXMLDocument.CreateElement("AnvandningsfallNamnCollection")
                        objXMLDocument.AppendChild(objXMLElement)

                        objXMLElement = objXMLDocument.CreateElement("AnvandningsfallNamnObject")

                        objXMLAttribute = objXMLDocument.CreateAttribute("AnvandningsfallNamn")
                        objXMLAttribute.Value = lvwStep3.SelectedItems.Item(0).Text
                        objXMLElement.Attributes.Append(objXMLAttribute)

                        objXMLDocument.DocumentElement.AppendChild(objXMLElement)
                    End If

                Case Else
            End Select

            Return objXMLDocument.OuterXml

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Function

    Private Sub mParseXML(ByVal strFormName As String, ByVal strXML As String, ByVal blnAdd As Boolean)
        '******************************************************************************************
        ' Beskrivning: Parsar returdata fr�n underformul�r.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement

        Try

            objXMLDocument.LoadXml(strXML)

            Select Case strFormName
                Case "ObjektNamnForm"
                    If blnAdd Then
                        For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/ObjektNamnObject")
                            lvwStep3.Items.Add(objXMLElement.Attributes.GetNamedItem("ObjektNamn").Value)
                        Next 'objElement
                    Else
                        For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/ObjektNamnObject")
                            lvwStep3.Items.Item(lvwStep3.SelectedItems.Item(0).Index).Text = objXMLElement.Attributes.GetNamedItem("ObjektNamn").Value
                        Next 'objElement
                    End If

                Case "ObjektBeroendeDForm"
                    If blnAdd Then
                    Else
                        For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/ObjektNamnObject")
                            lvwStep4.SelectedItems.Item(0).Text = objXMLElement.Attributes.GetNamedItem("ObjektNamn").Value
                            lvwStep4.SelectedItems.Item(0).SubItems.Item(1).Text = IIf(objXMLElement.Attributes.GetNamedItem("ObjektTyp").Value, "HuvudObjekt", "UnderObjekt")
                            lvwStep4.SelectedItems.Item(0).SubItems.Item(2).Text = objXMLElement.Attributes.GetNamedItem("BeroendeObjekt").Value
                        Next 'objElement
                    End If

                Case "ObjektBeroendeGForm"
                    If blnAdd Then
                    Else
                        For Each objXMLElement In objXMLDocument.SelectNodes("/ObjektNamnCollection/ObjektNamnObject")
                            lvwStep5.SelectedItems.Item(0).Text = objXMLElement.Attributes.GetNamedItem("ObjektNamn").Value
                            lvwStep5.SelectedItems.Item(0).SubItems.Item(1).Text = IIf(objXMLElement.Attributes.GetNamedItem("ObjektTyp").Value, "RotObjekt", "Objekt")
                            lvwStep5.SelectedItems.Item(0).SubItems.Item(2).Text = objXMLElement.Attributes.GetNamedItem("BeroendeObjekt").Value
                        Next 'objElement
                    End If

                Case "AnvandningsfallNamnForm"
                    If blnAdd Then
                        For Each objXMLElement In objXMLDocument.SelectNodes("/AnvandningsfallNamnCollection/AnvandningsfallNamnObject")
                            lvwStep6.Items.Add(objXMLElement.Attributes.GetNamedItem("AnvandningsfallNamn").Value)
                        Next 'objElement
                    Else
                        For Each objXMLElement In objXMLDocument.SelectNodes("/AnvandningsfallNamnCollection/AnvandningsfallNamnObject")
                            lvwStep6.Items.Item(lvwStep6.SelectedItems.Item(0).Index).Text = objXMLElement.Attributes.GetNamedItem("AnvandningsfallNamn").Value
                        Next 'objElement
                    End If

                Case Else
            End Select

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub
#End Region

#Region " Windows Form Designer generated code "

    Private Sub New() 'HB Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdNext As Button
    Friend WithEvents cmdPrevious As Button
    Friend WithEvents cmdCancel As Button
    Friend WithEvents grpStart As GroupBox
    Friend WithEvents picLeftMarginStart As PictureBox
    Friend WithEvents lblStart As Label
    Friend WithEvents grpFinish As GroupBox
    Friend WithEvents lblFinish As Label
    Friend WithEvents picLeftMarginFinish As PictureBox
    Friend WithEvents grpStep2 As GroupBox
    Friend WithEvents grpInstruction2 As GroupBox
    Friend WithEvents grpStep2Anvandargr�nssnitt As GroupBox
    Friend WithEvents butStep2Webb As RadioButton
    Friend WithEvents butStep2Windows As RadioButton
    Friend WithEvents butStep2Inget As RadioButton
    Friend WithEvents butStep2WindowsWebb As RadioButton
    Friend WithEvents grpStep3 As GroupBox
    Friend WithEvents grpInstruction3 As GroupBox
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents cmdStep3Andra As Button
    Friend WithEvents cmdStep3TaBort As Button
    Friend WithEvents cmdStep3LaggTill As Button
    Friend WithEvents grpStep4 As GroupBox
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents grpInstruction4 As GroupBox
    Friend WithEvents grpStep1 As GroupBox
    Friend WithEvents cmdStep1Ellipse As Button
    Friend WithEvents txtStep1Oppna As TextBox
    Friend WithEvents txtStep1Nytt As TextBox
    Friend WithEvents butStep1Oppna As RadioButton
    Friend WithEvents butStep1Nytt As RadioButton
    Friend WithEvents grpInstruction1 As GroupBox
    Friend WithEvents cmdStep4Andra As Button
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents lvwStep3 As ListView
    Friend WithEvents lvwStep4 As ListView
    Friend WithEvents grpStep5 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdStep5Andra As System.Windows.Forms.Button
    Friend WithEvents lvwStep5 As System.Windows.Forms.ListView
    Friend WithEvents grpInstruction5 As System.Windows.Forms.GroupBox
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents grpStep6 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdStep6TaBort As System.Windows.Forms.Button
    Friend WithEvents cmdStep6Andra As System.Windows.Forms.Button
    Friend WithEvents cmdStep6LaggTill As System.Windows.Forms.Button
    Friend WithEvents lvwStep6 As System.Windows.Forms.ListView
    Friend WithEvents grpInstruction6 As System.Windows.Forms.GroupBox
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblInstruction1 As System.Windows.Forms.Label
    Friend WithEvents lblInstruction2 As System.Windows.Forms.Label
    Friend WithEvents lblInstruction3 As System.Windows.Forms.Label
    Friend WithEvents lblInstruction4 As System.Windows.Forms.Label
    Friend WithEvents lblInstruction5 As System.Windows.Forms.Label
    Friend WithEvents lblInstruction6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(WizardForm))
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdNext = New System.Windows.Forms.Button()
        Me.cmdPrevious = New System.Windows.Forms.Button()
        Me.grpStart = New System.Windows.Forms.GroupBox()
        Me.lblStart = New System.Windows.Forms.Label()
        Me.picLeftMarginStart = New System.Windows.Forms.PictureBox()
        Me.grpFinish = New System.Windows.Forms.GroupBox()
        Me.lblFinish = New System.Windows.Forms.Label()
        Me.picLeftMarginFinish = New System.Windows.Forms.PictureBox()
        Me.grpStep2 = New System.Windows.Forms.GroupBox()
        Me.grpStep2Anvandargr�nssnitt = New System.Windows.Forms.GroupBox()
        Me.butStep2Inget = New System.Windows.Forms.RadioButton()
        Me.butStep2WindowsWebb = New System.Windows.Forms.RadioButton()
        Me.butStep2Webb = New System.Windows.Forms.RadioButton()
        Me.butStep2Windows = New System.Windows.Forms.RadioButton()
        Me.grpInstruction2 = New System.Windows.Forms.GroupBox()
        Me.lblInstruction2 = New System.Windows.Forms.Label()
        Me.grpStep3 = New System.Windows.Forms.GroupBox()
        Me.cmdStep3TaBort = New System.Windows.Forms.Button()
        Me.cmdStep3Andra = New System.Windows.Forms.Button()
        Me.cmdStep3LaggTill = New System.Windows.Forms.Button()
        Me.lvwStep3 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.grpInstruction3 = New System.Windows.Forms.GroupBox()
        Me.lblInstruction3 = New System.Windows.Forms.Label()
        Me.grpStep4 = New System.Windows.Forms.GroupBox()
        Me.cmdStep4Andra = New System.Windows.Forms.Button()
        Me.lvwStep4 = New System.Windows.Forms.ListView()
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.grpInstruction4 = New System.Windows.Forms.GroupBox()
        Me.lblInstruction4 = New System.Windows.Forms.Label()
        Me.grpStep1 = New System.Windows.Forms.GroupBox()
        Me.cmdStep1Ellipse = New System.Windows.Forms.Button()
        Me.txtStep1Oppna = New System.Windows.Forms.TextBox()
        Me.txtStep1Nytt = New System.Windows.Forms.TextBox()
        Me.butStep1Oppna = New System.Windows.Forms.RadioButton()
        Me.butStep1Nytt = New System.Windows.Forms.RadioButton()
        Me.grpInstruction1 = New System.Windows.Forms.GroupBox()
        Me.lblInstruction1 = New System.Windows.Forms.Label()
        Me.grpStep5 = New System.Windows.Forms.GroupBox()
        Me.cmdStep5Andra = New System.Windows.Forms.Button()
        Me.lvwStep5 = New System.Windows.Forms.ListView()
        Me.ColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader7 = New System.Windows.Forms.ColumnHeader()
        Me.grpInstruction5 = New System.Windows.Forms.GroupBox()
        Me.lblInstruction5 = New System.Windows.Forms.Label()
        Me.grpStep6 = New System.Windows.Forms.GroupBox()
        Me.cmdStep6TaBort = New System.Windows.Forms.Button()
        Me.cmdStep6Andra = New System.Windows.Forms.Button()
        Me.cmdStep6LaggTill = New System.Windows.Forms.Button()
        Me.lvwStep6 = New System.Windows.Forms.ListView()
        Me.ColumnHeader8 = New System.Windows.Forms.ColumnHeader()
        Me.grpInstruction6 = New System.Windows.Forms.GroupBox()
        Me.lblInstruction6 = New System.Windows.Forms.Label()
        Me.grpStart.SuspendLayout()
        Me.grpFinish.SuspendLayout()
        Me.grpStep2.SuspendLayout()
        Me.grpStep2Anvandargr�nssnitt.SuspendLayout()
        Me.grpInstruction2.SuspendLayout()
        Me.grpStep3.SuspendLayout()
        Me.grpInstruction3.SuspendLayout()
        Me.grpStep4.SuspendLayout()
        Me.grpInstruction4.SuspendLayout()
        Me.grpStep1.SuspendLayout()
        Me.grpInstruction1.SuspendLayout()
        Me.grpStep5.SuspendLayout()
        Me.grpInstruction5.SuspendLayout()
        Me.grpStep6.SuspendLayout()
        Me.grpInstruction6.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdCancel.Location = New System.Drawing.Point(942, 737)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.TabIndex = 5
        Me.cmdCancel.Text = "Avbryt"
        '
        'cmdNext
        '
        Me.cmdNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdNext.Location = New System.Drawing.Point(849, 737)
        Me.cmdNext.Name = "cmdNext"
        Me.cmdNext.TabIndex = 6
        Me.cmdNext.Text = "&N�sta >"
        '
        'cmdPrevious
        '
        Me.cmdPrevious.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdPrevious.Location = New System.Drawing.Point(772, 737)
        Me.cmdPrevious.Name = "cmdPrevious"
        Me.cmdPrevious.TabIndex = 7
        Me.cmdPrevious.Text = "< &Bak�t"
        '
        'grpStart
        '
        Me.grpStart.BackColor = System.Drawing.SystemColors.Window
        Me.grpStart.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblStart, Me.picLeftMarginStart})
        Me.grpStart.Location = New System.Drawing.Point(448, 132)
        Me.grpStart.Name = "grpStart"
        Me.grpStart.Size = New System.Drawing.Size(208, 100)
        Me.grpStart.TabIndex = 8
        Me.grpStart.TabStop = False
        Me.grpStart.Text = "start"
        '
        'lblStart
        '
        Me.lblStart.Location = New System.Drawing.Point(156, 50)
        Me.lblStart.Name = "lblStart"
        Me.lblStart.TabIndex = 1
        Me.lblStart.Text = "Label1"
        '
        'picLeftMarginStart
        '
        Me.picLeftMarginStart.Image = CType(resources.GetObject("picLeftMarginStart.Image"), System.Drawing.Bitmap)
        Me.picLeftMarginStart.Location = New System.Drawing.Point(36, 48)
        Me.picLeftMarginStart.Name = "picLeftMarginStart"
        Me.picLeftMarginStart.TabIndex = 0
        Me.picLeftMarginStart.TabStop = False
        '
        'grpFinish
        '
        Me.grpFinish.BackColor = System.Drawing.SystemColors.Window
        Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblFinish, Me.picLeftMarginFinish})
        Me.grpFinish.Location = New System.Drawing.Point(406, 172)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(208, 100)
        Me.grpFinish.TabIndex = 9
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "finish"
        '
        'lblFinish
        '
        Me.lblFinish.Location = New System.Drawing.Point(156, 50)
        Me.lblFinish.Name = "lblFinish"
        Me.lblFinish.TabIndex = 1
        Me.lblFinish.Text = "Label1"
        '
        'picLeftMarginFinish
        '
        Me.picLeftMarginFinish.Image = CType(resources.GetObject("picLeftMarginFinish.Image"), System.Drawing.Bitmap)
        Me.picLeftMarginFinish.Location = New System.Drawing.Point(36, 48)
        Me.picLeftMarginFinish.Name = "picLeftMarginFinish"
        Me.picLeftMarginFinish.TabIndex = 0
        Me.picLeftMarginFinish.TabStop = False
        '
        'grpStep2
        '
        Me.grpStep2.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpStep2Anvandargr�nssnitt, Me.grpInstruction2})
        Me.grpStep2.Location = New System.Drawing.Point(-18, 426)
        Me.grpStep2.Name = "grpStep2"
        Me.grpStep2.Size = New System.Drawing.Size(530, 284)
        Me.grpStep2.TabIndex = 11
        Me.grpStep2.TabStop = False
        Me.grpStep2.Text = "step2"
        '
        'grpStep2Anvandargr�nssnitt
        '
        Me.grpStep2Anvandargr�nssnitt.Controls.AddRange(New System.Windows.Forms.Control() {Me.butStep2Inget, Me.butStep2WindowsWebb, Me.butStep2Webb, Me.butStep2Windows})
        Me.grpStep2Anvandargr�nssnitt.Location = New System.Drawing.Point(50, 100)
        Me.grpStep2Anvandargr�nssnitt.Name = "grpStep2Anvandargr�nssnitt"
        Me.grpStep2Anvandargr�nssnitt.Size = New System.Drawing.Size(200, 130)
        Me.grpStep2Anvandargr�nssnitt.TabIndex = 18
        Me.grpStep2Anvandargr�nssnitt.TabStop = False
        Me.grpStep2Anvandargr�nssnitt.Text = "Anv�ndargr�nssnitt"
        '
        'butStep2Inget
        '
        Me.butStep2Inget.Location = New System.Drawing.Point(10, 100)
        Me.butStep2Inget.Name = "butStep2Inget"
        Me.butStep2Inget.Size = New System.Drawing.Size(130, 20)
        Me.butStep2Inget.TabIndex = 18
        Me.butStep2Inget.Text = "Inget"
        '
        'butStep2WindowsWebb
        '
        Me.butStep2WindowsWebb.Location = New System.Drawing.Point(10, 74)
        Me.butStep2WindowsWebb.Name = "butStep2WindowsWebb"
        Me.butStep2WindowsWebb.Size = New System.Drawing.Size(130, 20)
        Me.butStep2WindowsWebb.TabIndex = 17
        Me.butStep2WindowsWebb.Text = "Windows och Webb"
        '
        'butStep2Webb
        '
        Me.butStep2Webb.Location = New System.Drawing.Point(10, 48)
        Me.butStep2Webb.Name = "butStep2Webb"
        Me.butStep2Webb.Size = New System.Drawing.Size(130, 20)
        Me.butStep2Webb.TabIndex = 16
        Me.butStep2Webb.Text = "Webb"
        '
        'butStep2Windows
        '
        Me.butStep2Windows.Checked = True
        Me.butStep2Windows.Location = New System.Drawing.Point(10, 22)
        Me.butStep2Windows.Name = "butStep2Windows"
        Me.butStep2Windows.Size = New System.Drawing.Size(130, 20)
        Me.butStep2Windows.TabIndex = 15
        Me.butStep2Windows.TabStop = True
        Me.butStep2Windows.Text = "Windows"
        '
        'grpInstruction2
        '
        Me.grpInstruction2.BackColor = System.Drawing.SystemColors.Window
        Me.grpInstruction2.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInstruction2})
        Me.grpInstruction2.Location = New System.Drawing.Point(23, 17)
        Me.grpInstruction2.Name = "grpInstruction2"
        Me.grpInstruction2.Size = New System.Drawing.Size(106, 58)
        Me.grpInstruction2.TabIndex = 12
        Me.grpInstruction2.TabStop = False
        Me.grpInstruction2.Text = "instruction2"
        '
        'lblInstruction2
        '
        Me.lblInstruction2.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInstruction2.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruction2.Location = New System.Drawing.Point(20, 20)
        Me.lblInstruction2.Name = "lblInstruction2"
        Me.lblInstruction2.Size = New System.Drawing.Size(69, 29)
        Me.lblInstruction2.TabIndex = 19
        '
        'grpStep3
        '
        Me.grpStep3.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStep3TaBort, Me.cmdStep3Andra, Me.cmdStep3LaggTill, Me.lvwStep3, Me.grpInstruction3})
        Me.grpStep3.Location = New System.Drawing.Point(380, 10)
        Me.grpStep3.Name = "grpStep3"
        Me.grpStep3.Size = New System.Drawing.Size(530, 284)
        Me.grpStep3.TabIndex = 12
        Me.grpStep3.TabStop = False
        Me.grpStep3.Text = "step3"
        '
        'cmdStep3TaBort
        '
        Me.cmdStep3TaBort.Location = New System.Drawing.Point(410, 152)
        Me.cmdStep3TaBort.Name = "cmdStep3TaBort"
        Me.cmdStep3TaBort.TabIndex = 16
        Me.cmdStep3TaBort.Text = "Ta bort"
        '
        'cmdStep3Andra
        '
        Me.cmdStep3Andra.Location = New System.Drawing.Point(410, 126)
        Me.cmdStep3Andra.Name = "cmdStep3Andra"
        Me.cmdStep3Andra.TabIndex = 15
        Me.cmdStep3Andra.Text = "�ndra..."
        '
        'cmdStep3LaggTill
        '
        Me.cmdStep3LaggTill.Location = New System.Drawing.Point(410, 100)
        Me.cmdStep3LaggTill.Name = "cmdStep3LaggTill"
        Me.cmdStep3LaggTill.TabIndex = 14
        Me.cmdStep3LaggTill.Text = "L�gg till..."
        '
        'lvwStep3
        '
        Me.lvwStep3.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.lvwStep3.FullRowSelect = True
        Me.lvwStep3.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.lvwStep3.Location = New System.Drawing.Point(50, 100)
        Me.lvwStep3.MultiSelect = False
        Me.lvwStep3.Name = "lvwStep3"
        Me.lvwStep3.Size = New System.Drawing.Size(350, 200)
        Me.lvwStep3.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwStep3.TabIndex = 13
        Me.lvwStep3.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ObjektNamn"
        Me.ColumnHeader1.Width = 340
        '
        'grpInstruction3
        '
        Me.grpInstruction3.BackColor = System.Drawing.SystemColors.Window
        Me.grpInstruction3.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInstruction3})
        Me.grpInstruction3.Location = New System.Drawing.Point(23, 17)
        Me.grpInstruction3.Name = "grpInstruction3"
        Me.grpInstruction3.Size = New System.Drawing.Size(106, 58)
        Me.grpInstruction3.TabIndex = 12
        Me.grpInstruction3.TabStop = False
        Me.grpInstruction3.Text = "instruction3"
        '
        'lblInstruction3
        '
        Me.lblInstruction3.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInstruction3.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruction3.Location = New System.Drawing.Point(20, 20)
        Me.lblInstruction3.Name = "lblInstruction3"
        Me.lblInstruction3.Size = New System.Drawing.Size(69, 29)
        Me.lblInstruction3.TabIndex = 19
        '
        'grpStep4
        '
        Me.grpStep4.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStep4Andra, Me.lvwStep4, Me.grpInstruction4})
        Me.grpStep4.Location = New System.Drawing.Point(530, 382)
        Me.grpStep4.Name = "grpStep4"
        Me.grpStep4.Size = New System.Drawing.Size(530, 284)
        Me.grpStep4.TabIndex = 13
        Me.grpStep4.TabStop = False
        Me.grpStep4.Text = "step4"
        '
        'cmdStep4Andra
        '
        Me.cmdStep4Andra.Location = New System.Drawing.Point(410, 100)
        Me.cmdStep4Andra.Name = "cmdStep4Andra"
        Me.cmdStep4Andra.TabIndex = 15
        Me.cmdStep4Andra.Text = "�ndra..."
        '
        'lvwStep4
        '
        Me.lvwStep4.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.lvwStep4.FullRowSelect = True
        Me.lvwStep4.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwStep4.Location = New System.Drawing.Point(50, 100)
        Me.lvwStep4.MultiSelect = False
        Me.lvwStep4.Name = "lvwStep4"
        Me.lvwStep4.Size = New System.Drawing.Size(350, 200)
        Me.lvwStep4.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwStep4.TabIndex = 13
        Me.lvwStep4.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "ObjektNamn"
        Me.ColumnHeader2.Width = 120
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Objekttyp"
        Me.ColumnHeader3.Width = 90
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Objektberoende"
        Me.ColumnHeader4.Width = 120
        '
        'grpInstruction4
        '
        Me.grpInstruction4.BackColor = System.Drawing.SystemColors.Window
        Me.grpInstruction4.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInstruction4})
        Me.grpInstruction4.Location = New System.Drawing.Point(23, 17)
        Me.grpInstruction4.Name = "grpInstruction4"
        Me.grpInstruction4.Size = New System.Drawing.Size(106, 58)
        Me.grpInstruction4.TabIndex = 12
        Me.grpInstruction4.TabStop = False
        Me.grpInstruction4.Text = "instruction4"
        '
        'lblInstruction4
        '
        Me.lblInstruction4.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInstruction4.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruction4.Location = New System.Drawing.Point(20, 20)
        Me.lblInstruction4.Name = "lblInstruction4"
        Me.lblInstruction4.Size = New System.Drawing.Size(69, 29)
        Me.lblInstruction4.TabIndex = 19
        '
        'grpStep1
        '
        Me.grpStep1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStep1Ellipse, Me.txtStep1Oppna, Me.txtStep1Nytt, Me.butStep1Oppna, Me.butStep1Nytt, Me.grpInstruction1})
        Me.grpStep1.Location = New System.Drawing.Point(18, 232)
        Me.grpStep1.Name = "grpStep1"
        Me.grpStep1.Size = New System.Drawing.Size(530, 284)
        Me.grpStep1.TabIndex = 14
        Me.grpStep1.TabStop = False
        Me.grpStep1.Text = "step1"
        '
        'cmdStep1Ellipse
        '
        Me.cmdStep1Ellipse.Enabled = False
        Me.cmdStep1Ellipse.Location = New System.Drawing.Point(434, 126)
        Me.cmdStep1Ellipse.Name = "cmdStep1Ellipse"
        Me.cmdStep1Ellipse.Size = New System.Drawing.Size(22, 20)
        Me.cmdStep1Ellipse.TabIndex = 17
        Me.cmdStep1Ellipse.Text = "..."
        Me.cmdStep1Ellipse.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'txtStep1Oppna
        '
        Me.txtStep1Oppna.Enabled = False
        Me.txtStep1Oppna.Location = New System.Drawing.Point(152, 126)
        Me.txtStep1Oppna.Name = "txtStep1Oppna"
        Me.txtStep1Oppna.Size = New System.Drawing.Size(280, 20)
        Me.txtStep1Oppna.TabIndex = 16
        Me.txtStep1Oppna.Text = ""
        '
        'txtStep1Nytt
        '
        Me.txtStep1Nytt.Location = New System.Drawing.Point(152, 100)
        Me.txtStep1Nytt.Name = "txtStep1Nytt"
        Me.txtStep1Nytt.Size = New System.Drawing.Size(140, 20)
        Me.txtStep1Nytt.TabIndex = 15
        Me.txtStep1Nytt.Text = "Systemnamn"
        '
        'butStep1Oppna
        '
        Me.butStep1Oppna.Enabled = False
        Me.butStep1Oppna.Location = New System.Drawing.Point(50, 126)
        Me.butStep1Oppna.Name = "butStep1Oppna"
        Me.butStep1Oppna.Size = New System.Drawing.Size(80, 20)
        Me.butStep1Oppna.TabIndex = 14
        Me.butStep1Oppna.Text = "�ppna"
        '
        'butStep1Nytt
        '
        Me.butStep1Nytt.Checked = True
        Me.butStep1Nytt.Location = New System.Drawing.Point(50, 100)
        Me.butStep1Nytt.Name = "butStep1Nytt"
        Me.butStep1Nytt.Size = New System.Drawing.Size(80, 20)
        Me.butStep1Nytt.TabIndex = 13
        Me.butStep1Nytt.TabStop = True
        Me.butStep1Nytt.Text = "Nytt"
        '
        'grpInstruction1
        '
        Me.grpInstruction1.BackColor = System.Drawing.SystemColors.Window
        Me.grpInstruction1.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInstruction1})
        Me.grpInstruction1.Location = New System.Drawing.Point(23, 17)
        Me.grpInstruction1.Name = "grpInstruction1"
        Me.grpInstruction1.Size = New System.Drawing.Size(106, 58)
        Me.grpInstruction1.TabIndex = 12
        Me.grpInstruction1.TabStop = False
        Me.grpInstruction1.Text = "instruction1"
        '
        'lblInstruction1
        '
        Me.lblInstruction1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInstruction1.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruction1.Location = New System.Drawing.Point(20, 20)
        Me.lblInstruction1.Name = "lblInstruction1"
        Me.lblInstruction1.Size = New System.Drawing.Size(69, 29)
        Me.lblInstruction1.TabIndex = 18
        '
        'grpStep5
        '
        Me.grpStep5.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStep5Andra, Me.lvwStep5, Me.grpInstruction5})
        Me.grpStep5.Location = New System.Drawing.Point(236, 438)
        Me.grpStep5.Name = "grpStep5"
        Me.grpStep5.Size = New System.Drawing.Size(530, 284)
        Me.grpStep5.TabIndex = 15
        Me.grpStep5.TabStop = False
        Me.grpStep5.Text = "step5"
        '
        'cmdStep5Andra
        '
        Me.cmdStep5Andra.Location = New System.Drawing.Point(410, 100)
        Me.cmdStep5Andra.Name = "cmdStep5Andra"
        Me.cmdStep5Andra.TabIndex = 15
        Me.cmdStep5Andra.Text = "�ndra..."
        '
        'lvwStep5
        '
        Me.lvwStep5.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7})
        Me.lvwStep5.FullRowSelect = True
        Me.lvwStep5.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwStep5.Location = New System.Drawing.Point(50, 100)
        Me.lvwStep5.MultiSelect = False
        Me.lvwStep5.Name = "lvwStep5"
        Me.lvwStep5.Size = New System.Drawing.Size(350, 200)
        Me.lvwStep5.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwStep5.TabIndex = 13
        Me.lvwStep5.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "ObjektNamn"
        Me.ColumnHeader5.Width = 120
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Objekttyp"
        Me.ColumnHeader6.Width = 90
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Objektberoende"
        Me.ColumnHeader7.Width = 120
        '
        'grpInstruction5
        '
        Me.grpInstruction5.BackColor = System.Drawing.SystemColors.Window
        Me.grpInstruction5.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInstruction5})
        Me.grpInstruction5.Location = New System.Drawing.Point(23, 17)
        Me.grpInstruction5.Name = "grpInstruction5"
        Me.grpInstruction5.Size = New System.Drawing.Size(106, 58)
        Me.grpInstruction5.TabIndex = 12
        Me.grpInstruction5.TabStop = False
        Me.grpInstruction5.Text = "instruction5"
        '
        'lblInstruction5
        '
        Me.lblInstruction5.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInstruction5.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruction5.Location = New System.Drawing.Point(20, 20)
        Me.lblInstruction5.Name = "lblInstruction5"
        Me.lblInstruction5.Size = New System.Drawing.Size(69, 29)
        Me.lblInstruction5.TabIndex = 19
        '
        'grpStep6
        '
        Me.grpStep6.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStep6TaBort, Me.cmdStep6Andra, Me.cmdStep6LaggTill, Me.lvwStep6, Me.grpInstruction6})
        Me.grpStep6.Location = New System.Drawing.Point(229, 238)
        Me.grpStep6.Name = "grpStep6"
        Me.grpStep6.Size = New System.Drawing.Size(530, 284)
        Me.grpStep6.TabIndex = 16
        Me.grpStep6.TabStop = False
        Me.grpStep6.Text = "step6"
        '
        'cmdStep6TaBort
        '
        Me.cmdStep6TaBort.Location = New System.Drawing.Point(410, 152)
        Me.cmdStep6TaBort.Name = "cmdStep6TaBort"
        Me.cmdStep6TaBort.TabIndex = 16
        Me.cmdStep6TaBort.Text = "Ta bort"
        '
        'cmdStep6Andra
        '
        Me.cmdStep6Andra.Location = New System.Drawing.Point(410, 126)
        Me.cmdStep6Andra.Name = "cmdStep6Andra"
        Me.cmdStep6Andra.TabIndex = 15
        Me.cmdStep6Andra.Text = "�ndra..."
        '
        'cmdStep6LaggTill
        '
        Me.cmdStep6LaggTill.Location = New System.Drawing.Point(410, 100)
        Me.cmdStep6LaggTill.Name = "cmdStep6LaggTill"
        Me.cmdStep6LaggTill.TabIndex = 14
        Me.cmdStep6LaggTill.Text = "L�gg till..."
        '
        'lvwStep6
        '
        Me.lvwStep6.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader8})
        Me.lvwStep6.FullRowSelect = True
        Me.lvwStep6.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.lvwStep6.Location = New System.Drawing.Point(50, 100)
        Me.lvwStep6.MultiSelect = False
        Me.lvwStep6.Name = "lvwStep6"
        Me.lvwStep6.Size = New System.Drawing.Size(350, 200)
        Me.lvwStep6.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwStep6.TabIndex = 13
        Me.lvwStep6.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "ObjektNamn"
        Me.ColumnHeader8.Width = 340
        '
        'grpInstruction6
        '
        Me.grpInstruction6.BackColor = System.Drawing.SystemColors.Window
        Me.grpInstruction6.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInstruction6})
        Me.grpInstruction6.Location = New System.Drawing.Point(23, 17)
        Me.grpInstruction6.Name = "grpInstruction6"
        Me.grpInstruction6.Size = New System.Drawing.Size(106, 58)
        Me.grpInstruction6.TabIndex = 12
        Me.grpInstruction6.TabStop = False
        Me.grpInstruction6.Text = "instruction6"
        '
        'lblInstruction6
        '
        Me.lblInstruction6.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInstruction6.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruction6.Location = New System.Drawing.Point(20, 20)
        Me.lblInstruction6.Name = "lblInstruction6"
        Me.lblInstruction6.Size = New System.Drawing.Size(69, 29)
        Me.lblInstruction6.TabIndex = 19
        '
        'WizardForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1026, 771)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpStep5, Me.grpStep4, Me.grpStep2, Me.grpStep6, Me.grpStep1, Me.grpFinish, Me.grpStart, Me.cmdPrevious, Me.cmdNext, Me.cmdCancel, Me.grpStep3})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "WizardForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "WizardForm"
        Me.grpStart.ResumeLayout(False)
        Me.grpFinish.ResumeLayout(False)
        Me.grpStep2.ResumeLayout(False)
        Me.grpStep2Anvandargr�nssnitt.ResumeLayout(False)
        Me.grpInstruction2.ResumeLayout(False)
        Me.grpStep3.ResumeLayout(False)
        Me.grpInstruction3.ResumeLayout(False)
        Me.grpStep4.ResumeLayout(False)
        Me.grpInstruction4.ResumeLayout(False)
        Me.grpStep1.ResumeLayout(False)
        Me.grpInstruction1.ResumeLayout(False)
        Me.grpStep5.ResumeLayout(False)
        Me.grpInstruction5.ResumeLayout(False)
        Me.grpStep6.ResumeLayout(False)
        Me.grpInstruction6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
