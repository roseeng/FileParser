# PSync::PunchClock.pm
# 
# Perl class for dealing with Palm PunchClock databases. 
#
#	Copyright (C) 2000, Carl Parisi
#	You may distribute this file under the terms of the Artistic
#	License, as specified in the README file.
#
# $Id: PunchClock.pm,v 1.14 2000/09/29 17:55:20 carl Exp $


use strict;
package PSync::PunchClock;
use Palm::Raw();
use Palm::StdAppInfo();

use vars qw( $VERSION @ISA );

$VERSION = (qw( $Revision: 1.14 $ ))[1];
@ISA = qw( Palm::Raw Palm::StdAppInfo );

=head1 NAME

PSync::PunchClock - Handler for Palm PunchClock databases.

=head1 SYNOPSIS

    use PSync::PunchClock;

=head1 DESCRIPTION


=head2 AppInfo block

The AppInfo block begins with standard category support. See
L<Palm::StdAppInfo> for details.

Other fields include:

    $pdb->{appinfo}{attribs}
    $pdb->{appinfo}{columns}
    $pdb->{appinfo}{flags)

Each one is a list. The columns tell you the general structure of
a record in the given database.

=head2 Sort block

=head2 Records

    $record = $pdb->{records}[N]
    The records are made up of fields that are defined by the "columns" found
    in the appinfo header.

    You can see the contents of the records like this
    foreach $record (@{$PDB->{"records"}}){
      foreach $column (@{$PDB->{"appinfo"}->{"columns"}}){
        $name = $column->{name};
        $value = $record->{$name};
        print ("$name = $value\n");
      }
    }

=cut
#'

sub import {
	&Palm::PDB::RegisterPDBHandlers(__PACKAGE__,
		[ "PClk", "PROJ" ],
		[ "PClk", "TIME" ],
		);
}

#define AppPrefCategory        1
#define AppPrefOnPunchOut      2
#define AppPrefTotalFormat     3
#define AppPrefWeekStartDay    4
#define AppPrefShowSubProjects 5
#define AppPrefTotalType       6
#define AppPrefMainTotalType   7
#define AppPrefRegisterKey     8
#define AppPrefInstallDate     9
#define AppPrefDateFormat     10
#define AppPrefTimeFormat     11
#define AppPrefNumberFormat   12
#define AppPrefDoBackup       13


=head2 new

  $pdb = new PSync::PunchClock;

Create a new PDB, initialized with the various PSync::PunchClock fields
and an empty record list.

Use this method if you're creating a PunchClock PDB from scratch.

=cut
#'

# new
# Create a new Palm::PunchClock database, and return it
sub new {
	my $classname	= shift;
	my $self	= $classname->SUPER::new(@_);
  # Create a generic PDB. No need to rebless it,
  # though.

	$self->{name} = "projectDB-PClk";	# Default
	$self->{creator} = "PClk";
	$self->{type} = "PROJ";
	$self->{attributes}{resource} = 0;
  # The PDB is not a resource database by
  # default, but it's worth emphasizing,
  # since projectDB is explicitly not a PRC.

	# Initialize the AppInfo block
	$self->{appinfo} = {
		dirty_appinfo	=> undef,	# ?
		sortOrder	=> undef,	# ?
	};

	# Add the standard AppInfo block stuff
	&Palm::StdAppInfo::seed_StdAppInfo($self->{appinfo});

	# Give the PDB a blank sort block
	$self->{sort} = undef;

	# Give the PDB an empty list of records
	$self->{records} = [];

	return $self;
}

=head2 new_Record

  $record = $pdb->new_Record;

Creates a new PunchClock record, with blank values for all of the fields.

This function is not fully implemented.

C<new_Record> does B<not> add the new record to C<$pdb>. For that,
you want C<$pdb-E<gt>append_Record>.

=cut

# new_Record
# Create a new, initialized record.
sub new_Record {
	my $classname = shift;
	my $retval = $classname->SUPER::new_Record(@_);

	return $retval;
}

# ParseAppInfoBlock
# Parse the AppInfo block for PunchClock databases.
sub ParseAppInfoBlock {
	my $self = shift;
	my $data = shift;
	my $dirtyAppInfo;
	my $sortOrder;
	my $appinfo = {};
	my $std_len;
  my $appinfo = $self->{appinfo};

	# Get the standard parts of the AppInfo block
	$std_len = &Palm::StdAppInfo::parse_StdAppInfo($appinfo, $data);

	$data = substr $data, $std_len;		# Remove the parsed part

  my ($version) = unpack("n", $data);
	$data = substr $data, 2;
  my $id;
  my $done = 0;
  my $length;

  $appinfo->{version} = $version;

#define RecordDBEnd         0
#define RecordDBAttribs     1
#define RecordDBColumns     2
#define RecordDBFlags       3
#define RecordDBUnunsed     4
#define RecordDBCategoryMap 5
  my $num;

  do{
    ($id, $data) = unpack("Ca*", $data);

    if ($id == 0){
      $done = 1;
    }else{
      ($length, $data) = unpack("wa*", $data);
      if ($id == 1){ #Attribs
        &ReadAttribs($self, $appinfo, $data);
      }elsif ($id == 2){ #Columns
        &ReadColumns($self, $appinfo, $data);
      }elsif ($id == 3){ #Flags
        &ReadFlags($self, $appinfo, $data);
      }
      $data = substr $data, $length;
    }
  }while(!$done);

	return $appinfo;
}

sub ReadAttribs {
	my $self = shift;
  my $appinfo = shift;
  my $data = shift;
  my $attrib;
  my ($num, $i);
  my $id;

  ($num, $data) = unpack("na*", $data);

  for($i=0; $i<$num; $i++){
    $attrib = &AttribRead($self, $appinfo, %{$self->{_attribIndex}[$i]}, "data"	=> $data, );

#		push @{$appinfo->{attribs}}, $attrib;
    $id = $attrib->{id};
    $appinfo->{attribs}->{$id} = $attrib;
    $data = $attrib->{data};
  }
}

sub ReadColumns {
	my $self = shift;
  my $appinfo = shift;
  my $data = shift;
  my $column;
  my ($num, $i);

  ($num, $data) = unpack("na*", $data);

  for($i=0; $i<$num; $i++){
    $column = &ColumnRead($self, $appinfo, %{$self->{_colIndex}[$i]}, "data"	=> $data, );

		push @{$appinfo->{columns}}, $column;
    $data = $column->{data};
  }
}

sub ReadFlags {
	my $self = shift;
  my $appinfo = shift;
  my $data = shift;
  my $flag;
  my ($num, $i);

  ($num, $data) = unpack("na*", $data);

  for($i=0; $i<$num; $i++){
    $flag = &FlagRead($self, $appinfo, %{$self->{_flagIndex}[$i]}, "data"	=> $data, );

		push @{$appinfo->{flags}}, $flag;
    $data = $flag->{data};
  }
}

sub AttribRead {
	my $self = shift;
  my $appinfo = shift;
  my $data;
	my %attrib = @_;
  my $id;
  my $format;
  my $name;
  my $flags;
  my $format;
  my $length = 0;
  my $ret;

  $data = $attrib{data};

  ($id, $format, $flags, $data) = unpack("wwCa*", $data);
  if ($format eq "8"){ #StringFixed
    ($length, $data) = unpack("na*", $data);
  }
  $attrib{id} = $id;
  $attrib{format} = $format;
  $attrib{data} = $data;
  $attrib{length} = $length;

  $ret = &UnpackTagBody($self, \%attrib);

  return \%attrib;
}

sub ColumnRead {
	my $self = shift;
  my $appinfo = shift;
  my $data;
	my %column = @_;
  my $id;
  my $format;
  my $name;
  my ($num, $i, $value);

  $data = $column{data};

  ($id, $format, $data) = unpack("wwa*", $data);
  $_ = $data;
  if (/(.*?)\000(.*)/s){
    $name = $1;
    $data = $2;
  }
  $column{id} = $id;
  $column{format} = $format;
  $column{name} = $name;
  $column{data} = $data;
  $column{length} = 0;

  if ($format eq "8"){ #TagFormatStringFixed
		($column{length}, $data) = unpack("na*", $data);
  }elsif ($format eq "3"){ #TagFormatEnum
#read in the enum values. Need to save them
		($num, $data) = unpack("na*", $data);
    for($i=0; $i<$num; $i++){
      ($value) = unpack("a*", $data);
      $_ = $value;
      if (/(.*?)\000(.*)/s){
        $value = $1;
        $data = $2;
      }else{
        $value = "";
      }
    }
  }
  return \%column;
}

sub FlagRead {
	my $self = shift;
  my $appinfo = shift;
  my $data;
	my %flag = @_;
  my $id;
  my $format;
  my $name;

  $data = $flag{data};

  ($id, $data) = unpack("wa*", $data);
  $_ = $data;
  if (/(.*?)\000(.*)/s){
    $name = $1;
    $data = $2;
  }else{
    $name = "noname";
  }
  $flag{id} = $id;
  $flag{name} = $name;
  $flag{data} = $data;

  return \%flag;
}

sub GetColumn {
	my $self = shift;
  my $id = shift;
  my $column;
  my $appinfo = $self->{appinfo};

  foreach $column (@{$appinfo->{"columns"}}){
    if ($id eq $column->{id}){
      return $column;
    }
  }

  return undef;
}

sub PackAppInfoBlock {
	my $self = shift;
	my $retval;

	# Pack the standard part of the AppInfo block
	$retval = &Palm::StdAppInfo::pack_StdAppInfo($self->{appinfo});

#	# And the application-specific stuff
# Still need to to this.

	return $retval;
}

sub ParseRecord {
	my $self = shift;
	my %record = @_;
	my $data = $record{data};
  my $flags;
  my $numTags;
  my %tag;
  my $name;

	delete $record{offset};		# This is useless
	delete $record{data};		# No longer necessary

	($flags, $numTags, $data) = unpack("wwa*", $data);

#should break out the flags
  $record{flags} = $flags;

  $tag{data} = $data;

  while (&UnpackTag($self, \%tag)){
    $name = $tag{name};
    $record{$name} = $tag{value};
  }
#May want to save the tag in the record

	delete $tag{data};		# No longer necessary
  
	return \%record;
}

sub PackRecord {
	my $self = shift;
	my $record = shift;
	my $retval;
	my $flags;
  my $numTags;
  my $tagData;
  my %nameTag;
  my %dbTag;

  $flags = 0;
  $numTags = 0;

	if (defined($record->{project_name})){
    $nameTag{string} = $record->{project_name};
    $numTags++;
    $tagData = &packTag(%nameTag);
  }

	if (defined($record->{project_db})){
    $dbTag{string} = $record->{project_db};
    $numTags++;
    $tagData .= &packTag(%dbTag);
  }

	$retval = pack ("C C " , $flags, $numTags) . $tagData;

	return $retval;
}

sub PackTag {
	my $self = shift;
	my $tag = shift;
  my $data;
  my ($lval, $hval);

	if (defined($tag->{string})){
    $data = pack "C a",
            1,
            $tag->{string} . "\0";
	}elsif (defined($tag->{word})){
    $hval = $tag->{word} >> 8;
    $lval = $tag->{word} & 0xff;
    $data = pack "n",
            $hval, $lval;
  }
  return $data;
}

sub UnpackTagBody {
	my $self = shift;
	my $tag = shift;
  my $id;
  my $data;
  my $format;
  my $value;
  my $ret = 0;
  
  $data = $tag->{data};
  $format = $tag->{format};

  if (($format eq "0") || ($format eq "7")){  #String
    ($value) = unpack("a*", $data);
    $_ = $value;
    if (/(.*?)\000(.*)/s){
      $value = $1;
      $data = $2;
    }else{
      $value = "";
    }
    $tag->{value} = $value;
    $ret = 1;
  }elsif ($format eq "1"){  #Word
    ($value, $data) = unpack("na*", $data);
    $tag->{value} = $value;
    $ret = 1;
  }elsif ($format eq "2"){  #Date
    my ($b, $w);
    ($b, $w, $data) = unpack("Cna*", $data);
    $tag->{month} = (($b >> 4) & 0xf);
    $tag->{day} = ((($b & 0xf) << 1) | ($w >> 15) & 0x1);
    $tag->{year} = ($w & 0x7fff);
#    $tag->{value} = "$tag->{month}/$tag->{day}/$tag->{year}";
    $tag->{value} = &FormatDate($self, $tag);
    $ret = 1;
  }elsif ($format eq "3"){  #Enum
    ($value, $data) = unpack("na*", $data);
    $tag->{value} = $value;
    $ret = 1;
  }elsif ($format eq "5"){  #Time
    my ($h, $m);
    ($h, $m, $data) = unpack("CCa*", $data);
    $tag->{hours} = $h;
    $tag->{minutes} = $m;
#    $tag->{value} = "$h:$m";
    $tag->{value} = &FormatTime($self, $tag);
    $ret = 1;
  }elsif ($format eq "6"){  #Long
    my $l;
    ($l, $data) = unpack("Na*", $data);
    $tag->{value} = $l;
    $ret = 1;
  }elsif ($format eq "8"){  #StringFixed
#not sure if this works
    my $length = $tag->{length};
    ($value, $data) = unpack("a$length". "a*", $data);
    $_ = $value;
    if (/(.*?)\000(.*)/s){
      $value = $1;
    }

    $tag->{value} = $value;
    $ret = 1;
  }
  $tag->{data} = $data;

  return $ret;
}

sub UnpackTag {
	my $self = shift;
	my $tag = shift;
  my $id;
  my $data;
  my $format;
  my $value;
  my $column;
  my $ret = 0;
  
  $data = $tag->{data};

  if (length $data > 0){
    ($id, $data) = unpack("wa*", $data);

#Get the format from the column
    $column = &GetColumn($self, $id);
    $format = $column->{format};

    $tag->{format} = $format;
    $tag->{name} = $column->{name};
    $tag->{id} = $id;
    $tag->{data} = $data;

    $ret = &UnpackTagBody($self, $tag);
  }

  return $ret;
}

sub FormatDate {
	my $self = shift;
  my $tag = shift;
  my $date;
  my $appinfo = $self->{appinfo};
  my $format = $appinfo->{attribs}->{'10'};

  if ($format eq 1){
    $date = "$tag->{day}/$tag->{month}/$tag->{year}";
  }elsif ($format eq 2){
    $date = "$tag->{day}/$tag->{month}/$tag->{year}";
  }elsif ($format eq 3){
    $date = "$tag->{day}\.$tag->{month}\.$tag->{year}";
  }elsif ($format eq 4){
    $date = "$tag->{year}/$tag->{month}/$tag->{day}";
  }elsif ($format eq 5){
    $date = "$tag->{year}\.$tag->{month}\.$tag->{day}";
  }elsif ($format eq 6){
    $date = "$tag->{year}-$tag->{month}-$tag->{day}";
  }else{ # }elsif ($format eq 0){
    $date = "$tag->{month}/$tag->{day}/$tag->{year}";
  }
  return $date;
}

sub FormatTime {
	my $self = shift;
  my $tag = shift;
  my $time;
  my $appinfo = $self->{appinfo};
  my $format = $appinfo->{attribs}->{'11'};
  my $hour24;
  my $hour;
  my $minute;
  my $pm;

#	public static final int tfColon     = 0;
#	public static final int tfColonAMPM = 1; // 1:00 pm
#  public static final int tfColon24h  = 2; // 13:00
#	public static final int tfDot       = 3;
#	public static final int tfDotAMPM   = 4; // 1.00 pm
#	public static final int tfDot24h    = 5; // 13.00
#	public static final int tfHoursAMPM = 6; // 1 pm
#	public static final int tfHours24h  = 7; // 13
#	public static final int tfComma24h  = 8; // 13,00

  $hour24 = $tag->{hours};
  $minute = $tag->{minutes};

  if ($hour24 eq 0){
    $pm = "am";
    $hour = 0;
  }elsif ($hour24 > 12){
    $pm = "pm";
    $hour = $hour24 - 12;
  }else{
    $pm = "am";
    $hour = $hour24;
  }

  if ($format eq 2){
    $time = "$hour24:$minute";
  }elsif ($format eq 4){
    $time = "$hour\.$minute $pm";
  }elsif ($format eq 5){
    $time = "$hour24\.$minute";
  }elsif ($format eq 8){
    $time = "$hour24,$minute";
  }else{
    $time = "$hour:$minute $pm";
  }
  return $time;
}

1;
__END__

=head1 AUTHOR

Carl Parisi E<lt>carl@psync.comE<gt>

=head1 SEE ALSO

Palm::PDB(3)

Palm::StdAppInfo(3)

=cut
