Imports System

Public Class HBDataProvider
    Inherits System.MarshalByRefObject

    Public Function TheData(ByVal Multiple As Integer) As String
        Dim i As Integer
        Dim strTemp As String

        For i = 1 To Multiple
            strTemp = strTemp & "A Datastring from HBDataProvider! "
        Next

        Return strTemp
    End Function

End Class
