// Constant.h : header file
//

#ifndef _CONSTANT_H_
#define _CONSTANT_H_

// ReportEvent() constants

#define RE_INFO					0x00
#define RE_NORMAL				0x01
#define RE_ERROR				0x02
#define RE_SYSTEM				0x03
#define RE_WARNING				0x04
#define RE_MAX					0x04 // max value

// ReportLog() constants

#define RL_NORMAL				0x01
#define RL_ERROR				0x02
#define RL_COMPLETE				0x03
#define RL_MARKED_COMPLETE		0x04
#define RL_MAX					0x04 // max value

// SetStatus() constants

#define SS_UNDEFINED			0x00
#define SS_ACTIVE				0x01
#define SS_INACTIVE				0x02
#define SS_ERROR				0x03
#define SS_ERROR_END			0x04
#define SS_REMOVE_ERROR			0x05
#define SS_MAX					0x05 // max value

// ShowParameters() flags

#define SP_HIDE_CANCELBUTTON	0x01
#define SP_DISABLE_YESBUTTON	0x02

#endif // _CONSTANT_H_


