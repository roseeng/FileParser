// DebugWin.cpp : implementation file
//

#include "stdafx.h"
#include "Servu.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDebugWin dialog

CDebugWin::CDebugWin(CWnd* pParent /*=NULL*/)
//	: CDialog(CDebugWin::IDD, pParent)
{
	Create( CDebugWin::IDD );
	//{{AFX_DATA_INIT(CDebugWin)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDebugWin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDebugWin)
	DDX_Control(pDX, IDC_LIST1, m_lbDebug);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDebugWin, CDialog)
	//{{AFX_MSG_MAP(CDebugWin)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDebugWin message handlers

BOOL CDebugWin::DestroyWindow() 
{
	return CDialog::DestroyWindow();
}

void CDebugWin::OnOK() 
{
	ShowWindow( SW_MINIMIZE );
//	CDialog::OnOK();
}
