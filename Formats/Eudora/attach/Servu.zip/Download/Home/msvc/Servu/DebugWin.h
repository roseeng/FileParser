#if !defined(AFX_DEBUGWIN_H__5C36E434_EAFA_11D1_872B_00805F0362AB__INCLUDED_)
#define AFX_DEBUGWIN_H__5C36E434_EAFA_11D1_872B_00805F0362AB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DebugWin.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDebugWin dialog

class CDebugWin : public CDialog
{
// Construction
public:
	CDebugWin(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDebugWin)
	enum { IDD = IDD_WDEBUG };
	CListBox	m_lbDebug;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDebugWin)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDebugWin)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEBUGWIN_H__5C36E434_EAFA_11D1_872B_00805F0362AB__INCLUDED_)
