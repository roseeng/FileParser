// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "itask.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ITask properties

/////////////////////////////////////////////////////////////////////////////
// ITask operations

BOOL ITask::Activate()
{
	BOOL result;
	InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}

BOOL ITask::Attach(LPDISPATCH lpTask)
{
	BOOL result;
	static BYTE parms[] =
		VTS_DISPATCH;
	InvokeHelper(0x2, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpTask);
	return result;
}

BOOL ITask::AttachFile(LPCTSTR lpszFileName)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x3, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszFileName);
	return result;
}

BOOL ITask::AttachID(LPCTSTR lpszID)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x4, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszID);
	return result;
}

BOOL ITask::AttachProcess(LPCTSTR lpszIdentifier)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x5, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszIdentifier);
	return result;
}

BOOL ITask::ContinueRun()
{
	BOOL result;
	InvokeHelper(0x6, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}

BOOL ITask::DeleteAllParameters()
{
	BOOL result;
	InvokeHelper(0x7, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}

BOOL ITask::DeleteAllParametersEx(BOOL bStore)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BOOL;
	InvokeHelper(0x8, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		bStore);
	return result;
}

BOOL ITask::DeleteParameter(LPCTSTR lpszName)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x9, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszName);
	return result;
}

BOOL ITask::DeleteParameterEx(LPCTSTR lpszName, BOOL bStore)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR VTS_BOOL;
	InvokeHelper(0xa, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszName, bStore);
	return result;
}

CString ITask::GetConfigParameter(LPCTSTR lpszName)
{
	CString result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0xb, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		lpszName);
	return result;
}

CString ITask::GetFile()
{
	CString result;
	InvokeHelper(0xc, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
	return result;
}

CString ITask::GetFileIdentifier(LPCTSTR lpszFileName)
{
	CString result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0xd, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		lpszFileName);
	return result;
}

short ITask::GetFlags()
{
	short result;
	InvokeHelper(0xe, DISPATCH_METHOD, VT_I2, (void*)&result, NULL);
	return result;
}

CString ITask::GetID()
{
	CString result;
	InvokeHelper(0xf, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
	return result;
}

CString ITask::GetIDEx(BOOL bUseExistingID)
{
	CString result;
	static BYTE parms[] =
		VTS_BOOL;
	InvokeHelper(0x10, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		bUseExistingID);
	return result;
}

CString ITask::GetInputFile(const VARIANT& bQuitIfMissing)
{
	CString result;
	static BYTE parms[] =
		VTS_VARIANT;
	InvokeHelper(0x11, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		&bQuitIfMissing);
	return result;
}

CString ITask::GetParameter(LPCTSTR lpszName)
{
	CString result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x12, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		lpszName);
	return result;
}

short ITask::GetStatus()
{
	short result;
	InvokeHelper(0x13, DISPATCH_METHOD, VT_I2, (void*)&result, NULL);
	return result;
}

CString ITask::GetSubParameter(LPCTSTR lpszParameter, LPCTSTR lpszName)
{
	CString result;
	static BYTE parms[] =
		VTS_BSTR VTS_BSTR;
	InvokeHelper(0x14, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		lpszParameter, lpszName);
	return result;
}

long ITask::GetTaskCount()
{
	long result;
	InvokeHelper(0x15, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

BOOL ITask::Load()
{
	BOOL result;
	InvokeHelper(0x16, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}

BOOL ITask::Remove()
{
	BOOL result;
	InvokeHelper(0x17, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}

BOOL ITask::ReportEvent(short nStatus, LPCTSTR lpszText)
{
	BOOL result;
	static BYTE parms[] =
		VTS_I2 VTS_BSTR;
	InvokeHelper(0x18, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		nStatus, lpszText);
	return result;
}

BOOL ITask::ReportLog(short nStatus, LPCTSTR lpszText)
{
	BOOL result;
	static BYTE parms[] =
		VTS_I2 VTS_BSTR;
	InvokeHelper(0x19, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		nStatus, lpszText);
	return result;
}

void ITask::SetFlags(short nFlags)
{
	static BYTE parms[] =
		VTS_I2;
	InvokeHelper(0x1a, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 nFlags);
}

BOOL ITask::SetID(LPCTSTR lpszID)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x1b, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszID);
	return result;
}

BOOL ITask::SetInputFile(LPCTSTR lpszFileName)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x1c, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszFileName);
	return result;
}

BOOL ITask::SetParameter(LPCTSTR lpszParameter)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x1d, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszParameter);
	return result;
}

BOOL ITask::SetParameterEx(LPCTSTR lpszParameter, BOOL bStore)
{
	BOOL result;
	static BYTE parms[] =
		VTS_BSTR VTS_BOOL;
	InvokeHelper(0x1e, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		lpszParameter, bStore);
	return result;
}

short ITask::SetStatus(short nStatus)
{
	short result;
	static BYTE parms[] =
		VTS_I2;
	InvokeHelper(0x1f, DISPATCH_METHOD, VT_I2, (void*)&result, parms,
		nStatus);
	return result;
}

BOOL ITask::ShowParameters()
{
	BOOL result;
	InvokeHelper(0x20, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}

BOOL ITask::ShowParametersEx(short nFlags)
{
	BOOL result;
	static BYTE parms[] =
		VTS_I2;
	InvokeHelper(0x21, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		nFlags);
	return result;
}

BOOL ITask::Store()
{
	BOOL result;
	InvokeHelper(0x22, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
	return result;
}


