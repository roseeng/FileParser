#ifndef _ITASK_H_
#define _ITASK_H_

// Machine generated IDispatch wrapper class(es) created with ClassWizard

/////////////////////////////////////////////////////////////////////////////
// ITask wrapper class

class ITask : public COleDispatchDriver
{
public:
	ITask() {}		// Calls COleDispatchDriver default constructor
	ITask(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	ITask(const ITask& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	BOOL Activate();
	BOOL Attach(LPDISPATCH lpTask);
	BOOL AttachFile(LPCTSTR lpszFileName);
	BOOL AttachID(LPCTSTR lpszID);
	BOOL AttachProcess(LPCTSTR lpszIdentifier);
	BOOL ContinueRun();
	BOOL DeleteAllParameters();
	BOOL DeleteAllParametersEx(BOOL bStore);
	BOOL DeleteParameter(LPCTSTR lpszName);
	BOOL DeleteParameterEx(LPCTSTR lpszName, BOOL bStore);
	CString GetConfigParameter(LPCTSTR lpszName);
	CString GetFile();
	CString GetFileIdentifier(LPCTSTR lpszFileName);
	short GetFlags();
	CString GetID();
	CString GetIDEx(BOOL bUseExistingID);
	CString GetInputFile(const VARIANT& bQuitIfMissing);
	CString GetParameter(LPCTSTR lpszName);
	short GetStatus();
	CString GetSubParameter(LPCTSTR lpszParameter, LPCTSTR lpszName);
	long GetTaskCount();
	BOOL Load();
	BOOL Remove();
	BOOL ReportEvent(short nStatus, LPCTSTR lpszText);
	BOOL ReportLog(short nStatus, LPCTSTR lpszText);
	void SetFlags(short nFlags);
	BOOL SetID(LPCTSTR lpszID);
	BOOL SetInputFile(LPCTSTR lpszFileName);
	BOOL SetParameter(LPCTSTR lpszParameter);
	BOOL SetParameterEx(LPCTSTR lpszParameter, BOOL bStore);
	short SetStatus(short nStatus);
	BOOL ShowParameters();
	BOOL ShowParametersEx(short nFlags);
	BOOL Store();
};

#endif // _ITASK_H_

