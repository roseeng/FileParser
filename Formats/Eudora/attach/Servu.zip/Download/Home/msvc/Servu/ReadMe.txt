

THIS PROJECT IS USING THE 'Decapus.Task" OLE COMPONENT.
=======================================================

Have in mind that all coming versions of Decapus may not be COMPLIANT TO THIS
PROJECT. The project may have to be updated.

/ Janne Andersson ENATOR Networks. 'jan.l.andersson@enator.se' 0910-822 61
