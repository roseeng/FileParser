
// Servu.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <objbase.h>
#include "Servu.h"
//#include "Constant.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

char *aSubEventError[ 8 ] = 
{	"No further information",
	"Problem writing to disk",
	"Problem reading from disk",
	"Insufficient disk quota",
	"Packet timed out",
	"User aborted transfer",
	"Unknown error",
	"Data connection closed unexpectedly" 
};


/////////////////////////////////////////////////////////////////////////////
// CServuApp
BEGIN_MESSAGE_MAP(CServuApp, CWinApp)
	//{{AFX_MSG_MAP(CServuApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServuApp construction
CServuApp::CServuApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CServuApp object
CServuApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CServuApp initialization
BOOL CServuApp::InitInstance()
{
	if( ::OleInitialize( NULL ) != S_OK )
	{
		AfxMessageBox( "Ole Init FAILED..." );
	}
//	m_pDebugWin = new CDebugWin();
//	m_pDebugWin->ShowWindow( SW_SHOW );
//	m_pDebugWin->m_lbDebug.AddString( "Debugging started..." );
	return TRUE;
}


int CServuApp::ExitInstance() 
{
	::OleUninitialize();
//	m_pDebugWin->DestroyWindow();
//	delete m_pDebugWin;
	return CWinApp::ExitInstance();
}

/////////////////////////////////////////////////////
//
EXPORTAPI_(WORD) HandleEventHook(RFTPEventStr* pEvent)
{
	CServuApp *pApp = GetApp();
	COleException oe;
	ITask task;
	CString strIdentifier, strFileName, strTemp, strText, strEvent;
	int i;

//	strText.Format( "Event type:%X, User:%s", pEvent->Event, pEvent->User );
//	pApp->m_pDebugWin->m_lbDebug.AddString( strText );

/*
Identifiers:
ServUEvent=Login|UserID=%s|IPAdress=%s
ServUEvent=Close|UserID=%s|IPAdress=%s
ServUEvent=StartDown|UserID=%s|IPAddress=%s|FileName=%s
ServUEvent=EndDown|UserID=%s|IPAddress=%s|FileName=%s
ServUEvent=StartUp|UserID=%s|IPAddress=%s|FileName=%s
ServUEvent=EndUp|UserID=%s|IPAddress=%s|FileName=%s
ServUEvent=Error|UserID=%s|Error=%s|SubEvent=%s
ServUEvent=SevereError
*/

	if( !task.CreateDispatch("Decapus.Task", &oe) ) {                  
		TCHAR szErrorMessage[128];
		oe.GetErrorMessage(szErrorMessage, sizeof(szErrorMessage));
		CString strMsg;
		strMsg.Format("Cannot create automation object \"Decapus.Task\".\n\n" \
			"OLE SCode=0x%X\nOLE ErrorMessage=%s",
			oe.m_sc, szErrorMessage);
		AfxMessageBox(strMsg);
		return REVNT_None;
	}

	switch( pEvent->Event ) {
		case EVNT_Login:
			strIdentifier.Format("ServUEvent=Login|UserID=%s|IPAdress=%s",
							pEvent->User,
							pEvent->ClientIP);

			if( !task.AttachProcess( strIdentifier ) )
			{	// No int. found, try report to default error integration.
				if( !task.AttachProcess( "ServUEvent=SevereError" ) )
				{	// No default error integration, show error in Serv-U.
					AfxMessageBox( 
					"Unable to attach process. There is no default error integration configured in Decapus.\n\n"
					"Identifier:  'ServUEvent=SevereError'" );
				}
				else
				{	// Try activate default error integration.
					task.ReportEvent( RE_ERROR, "Unable to find integration for identifier: " + strIdentifier );
					if( !task.Activate() )
					{
						AfxMessageBox( "Unable to activate Decapus default Serv-u error integration.\n\n(Identifier: 'ServUEvent=SevereError')" );
					}
				}
				return REVNT_None;	 // Quit...
			}
			if( !task.Activate() ) {
				strTemp.Format( "Unable to activate integration.\n\nIdentifier: '%s'", strIdentifier ); 
				AfxMessageBox( strTemp );
				return REVNT_None;
			}
			break;

		case EVNT_Close:
			strIdentifier.Format("ServUEvent=Close|UserID=%s|IPAdress=%s",
							pEvent->User,
							pEvent->ClientIP);

			if( !task.AttachProcess( strIdentifier ) )
			{	// No int. found, try report to default error integration.
				if( !task.AttachProcess( "ServUEvent=SevereError" ) )
				{	// No default error integration, show error in Serv-U.
					AfxMessageBox( 
					"Unable to attach process. There is no default error integration configured in Decapus.\n\n"
					"Identifier:  'ServUEvent=SevereError'" );
				}
				else
				{	// Try activate default error integration.
					task.ReportEvent( RE_ERROR, "Unable to find integration for identifier: " + strIdentifier );
					if( !task.Activate() )
					{
						AfxMessageBox( "Unable to activate Decapus default Serv-u error integration.\n\n(Identifier: 'ServUEvent=SevereError')" );
					}
				}
				return REVNT_None;	 // Quit...
			}
			if( !task.Activate() ) {
				strTemp.Format( "Unable to activate integration.\n\nIdentifier: '%s'", strIdentifier ); 
				AfxMessageBox( strTemp );
				return REVNT_None;
			}
			break;

		case EVNT_StartUp:
		case EVNT_EndUp:
		case EVNT_StartDown:
		case EVNT_EndDown:

			switch( pEvent->Event ) {
				case EVNT_StartUp:
					strEvent = "StartUp";
					break;
				case EVNT_EndUp:
					strEvent = "EndUp";
					break;
				case EVNT_StartDown:
					strEvent = "StartDown";
					break;
				case EVNT_EndDown:
					strEvent = "EndDown";
					break;
			}

			strFileName = pEvent->AuxOne;

			if( (i = strFileName.ReverseFind( '\\' )) != -1 ) {
				strFileName = strFileName.Mid( i+1 );
			};
			strIdentifier.Format( "ServUEvent=%s|UserID=%s|IPAddress=%s|FileName=%s",
							strEvent,
							pEvent->User,
							pEvent->ClientIP,
							strFileName );

			if( !task.AttachProcess( strIdentifier ) )
			{	// No int. found, try report to default error integration.
//				if( !task.AttachProcess( "FTPError=Serv-U" ) )
				if( !task.AttachProcess( "ServUEvent=SevereError" ) )
				{	// No default error integration, show error in Serv-U.
					AfxMessageBox( 
					"Unable to attach process. There is no default error integration configured in Decapus.\n\n"
					"Identifier:  'ServUEvent=SevereError'" );
				}
				else
				{	// Try activate default error integration.
					task.ReportEvent( RE_ERROR, "Unable to find integration for identifier: " + strIdentifier );
					if( !task.Activate() )
					{
						AfxMessageBox( "Unable to activate Decapus default Serv-u error integration.\n\n(Identifier: 'ServUEvent=SevereError')" );
					}
				}
				return REVNT_None;	 // Quit...
			}

			task.SetInputFile( pEvent->AuxOne );
			switch( pEvent->Event ) {
				case EVNT_EndUp:
					strText.Format( "File Upload|%s Download|File=%s|Size=%ld bytes",
							pEvent->User,
							pEvent->AuxOne,
							pEvent->Size );
					break;
				case EVNT_EndDown:
					strText.Format( "File Download|%s Download|File=%s|Size=%ld bytes",
							pEvent->User,
							pEvent->AuxOne,
							pEvent->Size );
					break;
			}
			
			task.ReportLog( RL_NORMAL, strText );
			if( !task.Activate() )
			{
				strTemp.Format( "Unable to activate integration.\n\nIdentifier: '%s'", strIdentifier ); 
				AfxMessageBox( strTemp );
				return REVNT_None;
			}
			break;

		case EVNT_AbortUp:
		case EVNT_AbortDown:
			strIdentifier.Format( "ServUEvent=Error|UserID=%s|Error=%s|SubEvent=%s"
							pEvent->User,
							"Abort",
							 aSubEventError[pEvent->SubEvent]);


			// Report to default error integration.
			if( !task.AttachProcess( strIdentifier ) )
			{	// No default error integration, show error in Serv-U.
				AfxMessageBox( 
				"Unable to attach process. There is no default error integration configured in Decapus.\n\n"
				"Identifier:  '" + strIdentifier + "'" );
				return REVNT_None;	 // Quit...
			}

			MINMAXEVENT( pEvent->SubEvent );
			strTemp.Format( "Download of file %s was aborted for user %s. (%s)", 
							pEvent->AuxOne,
							pEvent->User,
							aSubEventError[ pEvent->SubEvent ] );
			task.ReportEvent( RE_ERROR, strTemp );
			if( !task.Activate() )
			{
				AfxMessageBox( "Unable to activate Decapus default Serv-u error integration.\n\n(Identifier: 'FTPError=Serv-U')" );
			}

			return REVNT_None;	 // Quit...

		case EVNT_IPName:
		case EVNT_BouncedIP:
		case EVNT_TooMany:
		case EVNT_Connect:
		case EVNT_Rename:
		case EVNT_DelFile:
		case EVNT_DelDir:
		case EVNT_ChgDir:
		case EVNT_MakeDir:
		case EVNT_TimeOut:
		case EVNT_WrongPass:
			break;

		default:
			break;
	}

	return REVNT_None;
}

CServuApp *GetApp() { return (CServuApp *)AfxGetApp(); }


