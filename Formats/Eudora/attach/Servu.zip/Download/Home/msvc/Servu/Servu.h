// Servu.h : main header file for the SERVU DLL
//


#if !defined(AFX_SERVU_H__2DB7A5DE_CEB0_11D1_A780_00600847EBF7__INCLUDED_)
#define AFX_SERVU_H__2DB7A5DE_CEB0_11D1_A780_00600847EBF7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "DebugWin.h"
#include "ITask.h"

/////////////////////////////////////////////////////////////////////////////
// CServuApp
// See Servu.cpp for the implementation of this class
//

#ifndef EXPORTAPI_
#define EXPORTAPI_(type) extern "C" __declspec(dllexport) type CALLBACK
//#define EXPORTAPI_(type) extern "C" __declspec(dllexport) type __stdcall
#endif

// ReportEvent() constants

#define RE_INFO					0x00
#define RE_NORMAL				0x01
#define RE_ERROR				0x02
#define RE_SYSTEM				0x03
#define RE_WARNING				0x04
#define RE_MAX					0x04 // max value

// ReportLog() constants

#define RL_NORMAL				0x01
#define RL_ERROR				0x02
#define RL_COMPLETE				0x03
#define RL_MARKED_COMPLETE		0x04
#define RL_MAX					0x04 // max value


// Return values:
#define REVNT_None		0	// nothing
#define REVNT_Proceed	1	// let event pass
#define REVNT_Abort	    2	// stop event
#define REVNT_Suspend	3	// suspend event until decision is made


// Event codes are:
#define EVNT_None		0	// none
#define EVNT_IPName		1	// symbolic IP name available
#define EVNT_Connect	2	// connection was made
#define EVNT_Close		3	// closed connection
#define EVNT_BouncedIP	4	// bounced client because of IP address
#define EVNT_TooMany	5	// bounced user because there are too many
#define EVNT_WrongPass	6	// too many times wrong password
#define EVNT_TimeOut	7	// connection timed out
#define EVNT_Login		8	// use logged in
#define EVNT_StartUp	9	// start upload of file
#define EVNT_EndUp		10	// successful upload of file
#define EVNT_StartDown	11	// start of download of file
#define EVNT_EndDown	12 // successful download of file
#define EVNT_AbortUp	13	// aborted upload
#define EVNT_AbortDown	14	// aborted download
#define EVNT_Rename		15	// renamed file/dir
#define EVNT_DelFile	16	// deleted file
#define EVNT_DelDir		17	// deleted dir
#define EVNT_ChgDir		18	// changed working directory
#define EVNT_MakeDir	19	// created directory

// Sub-event codes are:
#define SEVNT_None		0	// no sub-event
#define SEVNT_ErrWrite	1	// problem writing to disk
#define SEVNT_ErrRead	2	// problem reading from disk
#define SEVNT_ErrQuota	3	// insufficient disk quota
#define SEVNT_ErrTOut	4	// packet timed out
#define SEVNT_ErrAbort	5	// user aborted transfer
#define SENVT_ErrUnknown 6	// unknown error
#define SEVNT_ErrClose	7	// data connection closed unexpectedly

#define MINMAXEVENT( x ) { x=(x>7)?0:x; x=(x<0)?0:x; }

// Notification structure:
struct RFTPEventStr {
	// event info
	DWORD  Event;			// event code
	DWORD  SubEvent;		// sub-event code

	// user info
	DWORD SessionID;		// unique ID of the FTP session
	char User[40];			// user name
	char ClientIP[16];		// IP number of client
	char LocalIP[16];		// IP number the client connected to

	// event attributes
	DWORD Duration;			// duration of events (in seconds)
	DWORD Size;				// size of object (i.e. file)

	// hook info
	HWND hWindow;			// window handle to post decision to
	UINT Message;			// message to post
	char* pReplyText;		// pointer to text to send to user

	// scratch pad area
	char AuxOne[512];		// auxiliary area one
	char AuxTwo[512];		// auxiliary area two
};



EXPORTAPI_(WORD) HandleEventHook(RFTPEventStr* pEvent);

class CServuApp : public CWinApp
{
public:
	CServuApp();
	ITask m_task;
	CDebugWin *m_pDebugWin;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServuApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CServuApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CServuApp *GetApp();
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVU_H__2DB7A5DE_CEB0_11D1_A780_00600847EBF7__INCLUDED_)
