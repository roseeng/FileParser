OOWizardTemplate
==================================================

Beskrivning:
------------
Koden �r en mall f�r hur man kan (och ska) skapa en Wizard med Visual Basic 6.0.

Koden i mallen �r det skelett kring vilket den specifika funktionaliten skall byggas.


Anv�ndning:
-----------

Skapa en Dvp-katalog f�r systemet om detta inte redan �r gjort. Kopiera sedan mallfilerna till Dvp-katalogen och starta sedan vbp filen. S�k och ers�tt sedan alla taggar tex <'WizardName'>.
�nnu b�ttre �r att kopiera mallfilerna till VBs Templatekatalog.


Inlagt av:
----------
H�kan Borg, 2001-10-22