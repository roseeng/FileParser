Imports OOPERA.ExceptionHandler
Imports System.Xml

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents tabUseCase As System.Web.UI.WebControls.Table

    Private mobjHandler As Handler

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        'HB
        Try
            mConfigureSystem()

        Catch objException As Exception
            'Viewer...Throw mobjFormatException(objException)

        End Try
        '/HB
    End Sub

    Public Sub mConfigureSystem()
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Dim objSupport As New OOPERA.ConsoleServer.Class1()
        
        Dim objXMLDocument As New XmlDocument()
        Dim objXMLElement As XmlElement
        Dim objXMLElement2 As XmlElement
        Dim objXSLTransform As New Xsl.XslTransform()
        Dim objXMLReader As XmlReader

        Dim strXSL As String

        Try
            objXMLDocument.LoadXml(objSupport.ConfigureWebSystem("UggaBugga"))

            objXSLTransform.Load(strXSL)

            objXMLReader = objXSLTransform.Transform(objXMLDocument, Nothing)

        Catch objException As Exception
            Throw mobjFormatException(objException)

        End Try
    End Sub

    'Public Sub mConfigureSystem()
    '    '******************************************************************************************
    '    ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
    '    ' Skapad.....: 2002-02-29 Av: H�kan Borg
    '    ' �ndrad.....:            Av:
    '    '******************************************************************************************
    '    Dim objSupport As New Support()
    '    Dim objController As OOPERA.Architecture.KLayer.Controller

    '    Dim objXMLDocument As New XmlDocument()
    '    Dim objXMLElement As XmlElement
    '    Dim objXMLElement2 As XmlElement

    '    Dim objXMLDocumentResult As New XmlDocument()
    '    Dim objXSLTransform As New Xsl.XslTransform()
    '    Dim objXMLReader As XmlReader

    '    Dim strXSL As String

    '    Try
    '        objXMLDocument.LoadXml(objSupport.SystemConfiguration("UggaBugga"))

    '        For Each objXMLElement In objXMLDocument.SelectNodes("ControllerCollection/Controller") 'endast en f�rv�ntas
    '            strXSL = objXMLElement.Attributes.GetNamedItem("XSL").Value

    '            objXMLDocumentResult.CreateElement("UseCaseCollection")

    '            objController = objSupport.CreateObject(objXMLElement.OuterXml)
    '            'objController = New DemoAppK.Controller()

    '            For Each objXMLElement2 In objXMLElement.SelectNodes("UseCaseCollection/UseCase")
    '                If objController.UseCaseIsAuthorized(objXMLElement2.Attributes.GetNamedItem("Name").Value) Then
    '                    objXMLDocumentResult.AppendChild(objXMLElement2.Clone())
    '                End If
    '            Next 'objXMLElement2
    '        Next 'objXMLElement

    '        objXSLTransform.Load(strXSL)

    '        objXMLReader = objXSLTransform.Transform(objXMLDocumentResult, Nothing)

    '    Catch objException As Exception
    '        Throw mobjFormatException(objException)

    '    End Try
    'End Sub

    'Public Sub mConfigureSystem()
    '    '******************************************************************************************
    '    ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
    '    ' Skapad.....: 2002-02-29 Av: H�kan Borg
    '    ' �ndrad.....:            Av:
    '    '******************************************************************************************
    '    Dim objSupport As New Support()

    '    Dim objController As OOPERA.Architecture.KLayer.Controller

    '    Dim objXMLDocument As New XmlDocument()
    '    Dim objXMLElement As XmlElement
    '    Dim objXMLElement2 As XmlElement

    '    Dim objTableCell As TableCell
    '    Dim objTableRow As TableRow

    '    Try
    '        objXMLDocument.LoadXml(objSupport.SystemConfiguration("uggeliBugg"))

    '        For Each objXMLElement In objXMLDocument.SelectNodes("ControllerCollection/Controller") 'endast en f�rv�ntas
    '            objController = Support.CreateObject(objXMLElement.OuterXml)

    '            For Each objXMLElement2 In objXMLElement.SelectNodes("UseCaseCollection/UseCase")
    '                If objController.UseCaseIsAuthorized(objXMLElement2.Attributes.GetNamedItem("Name").Value) Then
    '                    objTableCell = New TableCell()
    '                    objTableRow = New TableRow()

    '                    objTableCell.Text = objXMLElement2.Attributes.GetNamedItem("Name").Value
    '                    objTableRow.Cells.Add(objTableCell)
    '                    tabUseCase.Rows.Add(objTableRow)
    '                End If
    '            Next 'objXMLElement2
    '        Next 'objXMLElement

    '    Catch objException As Exception
    '        Throw mobjFormatException(objException)

    '    End Try
    'End Sub

    Private Function mobjFormatException(ByVal objException As Exception) As Exception
        '******************************************************************************************
        ' Beskrivning: xxxxxxxxxxxxxxxxxxxxxxxxxx.
        ' Skapad.....: 2002-02-29 Av: H�kan Borg
        ' �ndrad.....:            Av:
        '******************************************************************************************
        Try
            If mobjHandler Is Nothing Then mobjHandler = New Handler()

            Return mobjHandler.Log(objException)

        Catch objLocalException As Exception
            'Ignorera fel under felhanteringen!

        End Try
    End Function

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

End Class
