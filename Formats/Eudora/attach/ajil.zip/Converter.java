//
// Converter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil;


/**
 * <p>
 * This class provides some methods for byte array manipulation and some other
 * conversion stuff.
 * </p>
 * <p>
 * The <code>ucTo&lt;bigger type&gt;(&lt;smaller type&gt;) methods are provided
 * to fix Java's lack of unsigned numbers.<br>
 * </p>
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-21
 * @version 2000-06-20
 */



public class Converter {

// Element(s)
////////////////////

	/**
	 * This <code>char[]</code> contains the 16 hexadecimal digits
	 * <code>'0'</code> through <code>'F'</code>.
	 */
	public static final char[] hex = {
	 '0', '1', '2', '3', '4', '5', '6', '7',
	 '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
	};

	/**
	 * Used to store chars when converting numbers to thier hexadecimal
	 * string representation.
	 */
	protected static char[] buf = {
	 '0', 'x',
	 '0', '0', '0', '0', '0', '0', '0', '0',
	 '0', '0', '0', '0', '0', '0', '0', '0'
	};


// Method(s)
////////////////////


// number to byte array conversions and vice versa
//////////////////////////////////////////////////////

	/**
	 * Converts <code>8 byte</code>s of a byte array in little endian byte
	 * order to a <code>long</code>.
	 *
	 * @param b byte array that holds the bytes being converted
	 * @param pos position of first byte to convert
	 * @return converted value
	 */
	public static final long getLong(byte[] b, int pos) {
		return
		 ucToLong(b[pos    ])       |
		 ucToLong(b[pos + 1]) <<  8 |
		 ucToLong(b[pos + 2]) << 16 |
		 ucToLong(b[pos + 3]) << 24 |
		 ucToLong(b[pos + 4]) << 32 |
		 ucToLong(b[pos + 5]) << 40 |
		 ucToLong(b[pos + 6]) << 48 |
		 ucToLong(b[pos + 7]) << 56
		;
	}

	/**
	 * Assigns the values of the 8 bytes of a <code>long</code> to 8
	 * elements of a byte array in little endian byte order.
	 *
	 * @param b byte array to modify
	 * @param pos position of first element to modify
	 * @param val holds the source bytes
	 */
	public static final void setLong(byte[] b, int pos, long val) {
		b[pos    ] = (byte)(val      );
		b[pos + 1] = (byte)(val >>  8);
		b[pos + 2] = (byte)(val >> 16);
		b[pos + 3] = (byte)(val >> 24);
		b[pos + 4] = (byte)(val >> 32);
		b[pos + 5] = (byte)(val >> 40);
		b[pos + 6] = (byte)(val >> 48);
		b[pos + 7] = (byte)(val >> 56);
	}

	/**
	 * Converts <code>4 byte</code>s of a byte array in little endian byte
	 * order to a <code>long</code>.
	 *
	 * @param b byte array that holds the bytes being converted
	 * @param pos position of first byte to convert
	 * @return converted value
	 */
	public static final long get4BLong(byte[] b, int pos) {
		return
		 ucToLong(b[pos    ])       |
		 ucToLong(b[pos + 1]) <<  8 |
		 ucToLong(b[pos + 2]) << 16 |
		 ucToLong(b[pos + 3]) << 24
		;
	}

	/**
	 * Assigns the values of the 4 less significant bytes of a <code>long
	 * </code> to 4 elements of a byte array in little endian byte order.
	 *
	 * @param b byte array to modify
	 * @param pos position of first element to modify
	 * @param val holds the source bytes
	 */
	public static final void set4BLong(byte[] b, int pos, long val) {
		b[pos    ] = (byte)(val      );
		b[pos + 1] = (byte)(val >>  8);
		b[pos + 2] = (byte)(val >> 16);
		b[pos + 3] = (byte)(val >> 24);
	}

	/**
	 * Converts <code>4 byte</code>s of a byte array in little endian byte
	 * order to an <code>int</code>.
	 *
	 * @param b byte array that holds the bytes being converted
	 * @param pos position of first byte to convert
	 * @return converted value
	 */
	public static final int getInt(byte[] b, int pos) {
		return
		 ucToInt(b[pos    ])       |
		 ucToInt(b[pos + 1]) <<  8 |
		 ucToInt(b[pos + 2]) << 16 |
		 ucToInt(b[pos + 3]) << 24
		;
	}

	/**
	 * Assigns the values of the 4 bytes of an <code>int</code> to 4
	 * elements of a byte array in little endian byte order.
	 *
	 * @param b byte array to modify
	 * @param pos position of first element to modify
	 * @param val holds the source bytes
	 */
	public static final void setInt(byte[] b, int pos, int val) {
		b[pos    ] = (byte)(val      );
		b[pos + 1] = (byte)(val >>  8);
		b[pos + 2] = (byte)(val >> 16);
		b[pos + 3] = (byte)(val >> 24);
	}

	/**
	 * Converts <code>2 byte</code>s of a byte array in little endian byte
	 * order to an <code>int</code>.
	 *
	 * @param b byte array that holds the bytes being converted
	 * @param pos position of first byte to convert
	 * @return converted value
	 */
	public static final int get2BInt(byte[] b, int pos) {
		return
		 ucToInt(b[pos    ])      |
		 ucToInt(b[pos + 1]) << 8
		;
	}

	/**
	 * Assigns the values of the 2 less significant bytes of an <code>int
	 * </code> to 2 elements of a byte array in little endian byte order.
	 *
	 * @param b byte array to modify
	 * @param pos position of first element to modify
	 * @param val holds the source bytes
	 */
	public static final void set2BInt(byte[] b, int pos, int val) {
		b[pos    ] = (byte)(val      );
		b[pos + 1] = (byte)(val >>  8);
	}

	/**
	 * Converts <code>2 byte</code>s of a byte array in little endian byte
	 * order to a <code>short</code>.
	 *
	 * @param b byte array that holds the bytes being converted
	 * @param pos position of first byte to convert
	 * @return converted value
	 */
	public static final short getShort(byte[] b, int pos) {
		return (short)(
		 ucToInt(b[pos    ])      |
		 ucToInt(b[pos + 1]) << 8
		);
	}

	/**
	 * Assigns the values of the 2 bytes of a <code>short</code> to 2
	 * elements of a byte array in little endian byte order.
	 *
	 * @param b byte array to modify
	 * @param pos position of first element to modify
	 * @param val holds the source bytes
	 */
	public static final void setShort(byte[] b, int pos, short val) {
		b[pos    ] = (byte)(val      );
		b[pos + 1] = (byte)(val >>  8);
	}


// 'unsigned' number conversions
//////////////////////////////////

	/**
	 * <p>
	 * Converts an <code>int</code>, as if unsigned, to <code>long</code>.
	 * (The <code>uc</code> at the beginning of the method name is a short
	 * cut for <code>unsigned conversion</code>):
	 * </p>
	 * <code><ul>
	 * <li>((long)  0x87654321) -> 0xFFFFFFFF87654321
	 * <li>ucToLong(0x87654321) -> 0x0000000087654321
	 * <li>((long)  0x12345678) -> 0x0000000012345678
	 * <li>ucToLong(0x12345678) -> 0x0000000012345678
	 * </ul></code>
	 * <p>
	 * <b>BUT NOTE:</b><br><code>
	 * ((int)0xFFFFFFFF12345678L) == ((int)0x0000000012345678L)</code>
	 * </p>
	 *
	 * @param val value that is being converted
	 * @return converted value
	 */
	public static final long ucToLong(int val) {
		return val & 0xffffffffL;
	}

	/**
	 * Converts a <code>short</code>, as if unsigned, to <code>long</code>.
	 *
	 * @param val value that is being converted
	 * @return converted value
	 * @see #ucToLong(int)
	 */
	public static final long ucToLong(short val) {
		return (long)(val & 0xffff);
	}

	/**
	 * Converts a <code>byte</code>, as if unsigned, to <code>long</code>.
	 *
	 * @param val value that is being converted
	 * @return converted value
	 * @see #ucToLong(int)
	 */
	public static final long ucToLong(byte val) {
		return (long)(val & 0xff);
	}

	/**
	 * Converts a <code>short</code>, as if unsigned, to <code>int</code>.
	 *
	 * @param val value that is being converted
	 * @return converted value
	 * @see #ucToLong(int)
	 */
	public static final int ucToInt(short val) {
		return val & 0xffff;
	}

	/**
	 * Converts a <code>byte</code>, as if unsigned, to <code>int</code>.
	 *
	 * @param val value that is being converted
	 * @return converted value
	 * @see #ucToLong(int)
	 */
	public static final int ucToInt(byte val) {
		return val & 0xff;
	}

	/**
	 * Converts a <code>byte</code>, as if unsigned, to <code>short</code>.
	 * <b>Implement this mehtod on your own, and see, what the resulting
	 * poppycock is like, if you want Java to perform bit manipulation on
	 * <code>short</code>!</b>
	 *
	 * @param val value that is being converted
	 * @return converted value
	 * @see #ucToLong(int)
	 */
	public static final short ucToShort(byte val) {
		return (short)ucToInt(val);
	}


//number to hex-string conversions
//////////////////////////////////////

	/**
	 * Converts a long to its hexadecimal string representation of the
	 * format <code>0x&lt;16 hexadecimal digits&gt;</code> with the
	 * constant length of 18 characters.
	 *
	 * @param val value to convert to hexadecimal representation
	 */
	public static final String getHexString(long val) {
		buf[ 2] = hex[(int)(val >> 60) & 0xF];
		buf[ 3] = hex[(int)(val >> 56) & 0xF];
		buf[ 4] = hex[(int)(val >> 52) & 0xF];
		buf[ 5] = hex[(int)(val >> 48) & 0xF];
		buf[ 6] = hex[(int)(val >> 44) & 0xF];
		buf[ 7] = hex[(int)(val >> 40) & 0xF];
		buf[ 8] = hex[(int)(val >> 36) & 0xF];
		buf[ 9] = hex[(int)(val >> 32) & 0xF];
		buf[10] = hex[(int)(val >> 28) & 0xF];
		buf[11] = hex[(int)(val >> 24) & 0xF];
		buf[12] = hex[(int)(val >> 20) & 0xF];
		buf[13] = hex[(int)(val >> 16) & 0xF];
		buf[14] = hex[(int)(val >> 12) & 0xF];
		buf[15] = hex[(int)(val >>  8) & 0xF];
		buf[16] = hex[(int)(val >>  4) & 0xF];
		buf[17] = hex[(int)(val      ) & 0xF];
		return new String(buf);
	}

	/**
	 * Converts an int to its hexadecimal string representation of the
	 * format <code>0x&lt;8 hexadecimal digits&gt;</code> with the
	 * constant length of 10 characters.
	 *
	 * @param val value to convert to hexadecimal representation
	 */
	public static final String getHexString(int val) {
		buf[2] = hex[val >> 28 & 0xF];
		buf[3] = hex[val >> 24 & 0xF];
		buf[4] = hex[val >> 20 & 0xF];
		buf[5] = hex[val >> 16 & 0xF];
		buf[6] = hex[val >> 12 & 0xF];
		buf[7] = hex[val >>  8 & 0xF];
		buf[8] = hex[val >>  4 & 0xF];
		buf[9] = hex[val       & 0xF];
		return new String(buf, 0, 10);
	}

	/**
	 * Converts a short to its hexadecimal string representation of the
	 * format <code>0x&lt;4 hexadecimal digits&gt;</code> with the
	 * constant length of 6 characters.
	 *
	 * @param val value to convert to hexadecimal representation
	 */
	public static final String getHexString(short val) {
		buf[2] = hex[val >> 12 & 0xF];
		buf[3] = hex[val >>  8 & 0xF];
		buf[4] = hex[val >>  4 & 0xF];
		buf[5] = hex[val       & 0xF];
		return new String(buf, 0, 6);
	}

	/**
	 * Converts a byte to its hexadecimal string representation of the
	 * format <code>0x&lt;2 hexadecimal digits&gt;</code> with the
	 * constant length of 4 characters.
	 *
	 * @param val value to convert to hexadecimal representation
	 */
	public static final String getHexString(byte val) {
		buf[2] = hex[val >>  4 & 0xF];
		buf[3] = hex[val       & 0xF];
		return new String(buf, 0, 4);
	}


//byte array to hex-dump/string conversions
/////////////////////////////////////////////////

	/**
	 * Converts byte array data to classical hex dump.
	 *
	 * @param b byte array containing the bytes to convert
	 * @param offset array offset (position of first byte to convert)
	 * @param length number of bytes to convert
	 */
	public static final String getHexDump(byte[] b, int offset, int length) {
		if (length < 1)
			throw new IllegalArgumentException("(" + length + " = length) < 1");

		int dataEnd = offset + length;

		if (dataEnd > b.length)
			throw new ArrayIndexOutOfBoundsException(
			 "(" + dataEnd + "= offset + length) > (" + b.length + " = b.length)");

		char[] buf = new char[length * 3 - 1];

		dataEnd--; //dataEnd now points to the last element
		int bufPos;
		for (int i = offset;; i++) {
			bufPos = (i - offset) * 3;
			buf[bufPos    ] = hex[b[i] >> 4 & 0xF];
			buf[bufPos + 1] = hex[b[i]      & 0xF];

			if (i >= dataEnd) //break before trying to set a blank at the end
				break;

			buf[bufPos + 2] = ' ';
		}


		return new String(buf);
	}

	/**
	 * Converts a whole or a part of a byte array to a string.
	 *
	 * @param b byte array containing the bytes to convert
	 * @param offset array offset (position of first byte to convert)
	 * @param length number of bytes to convert
	 */
	public static final String getString(byte[] b, int offset, int length) {
		if (length < 1)
			throw new IllegalArgumentException("(" + length + " = length) < 1");

		int dataEnd = offset + length;

		if (dataEnd > b.length)
			throw new ArrayIndexOutOfBoundsException(
			 "(" + dataEnd + "= offset + length) > (" + b.length + " = b.length)");

		char[] buf = new char[length];
		int bAsI;
		for (int i = offset; i < dataEnd; i++)
			buf[i - offset] = (bAsI = ucToInt(b[i])) < 32 ?
			 '.' : (char)bAsI;

		return new String(buf);
	}


 ///////////////////////////////////////////////////////
// who will ever need to get/set a boundle of 6 bytes? //
/////////////////////////////////////////////////////////
//	/**
//	 * Converts 6 <code>byte</code>s of a byte array in little endian byte
//	 * order to a <code>long</code>.
//	 *
//	 * @param b byte array that holds the bytes being converted
//	 * @param pos position of first byte to convert
//	 */
//	public static final long get6BytesAsLong(byte[] b, int pos) {
//		return
//		 ucToLong(b[pos    ])       |
//		 ucToLong(b[pos + 1]) <<  8 |
//		 ucToLong(b[pos + 2]) << 16 |
//		 ucToLong(b[pos + 3]) << 24 |
//		 ucToLong(b[pos + 4]) << 32 |
//		 ucToLong(b[pos + 5]) << 40
//		;
//	}
//
//	/**
//	 * Assigns the values of the 6 less significant bytes of a <code>long
//	 * </code> to 6 elements of a byte array in little endian byte order.
//	 *
//	 * @param b byte array to modify
//	 * @param pos position of first element in the array that will get a
//	 *        new value
//	 * @param val holds the source bytes
//	 */
//	public static final void assign6BytesOfLong(byte[] b, int pos, long val) {
//		b[pos    ] = (byte)(val      );
//		b[pos + 1] = (byte)(val >>  8);
//		b[pos + 2] = (byte)(val >> 16);
//		b[pos + 3] = (byte)(val >> 24);
//		b[pos + 4] = (byte)(val >> 32);
//		b[pos + 5] = (byte)(val >> 40);
//	}

// Constructor(s)
////////////////////

	/**
	 * Instanciation of this class is not allowed.
	 */
	private Converter() {}
}
