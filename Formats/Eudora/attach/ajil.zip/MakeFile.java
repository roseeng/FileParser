//
// MakeFile.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil;


/**
 * This file's purpose is the one of a make file. It does not contain anything
 * valuable for runtime. It makes use of a feature of the java compiler coming
 * with the JDK. That compiler looks for uncompiled or compilation-dated (when
 * source was modified) classes and (re-)compiles them if necessary.
 *
 * @author  Daniel Strecker <daniel-strecker@gmx.net>
 * @since   2000-05-21
 * @version 2000-06-20
 */


class MakeFile {
	ajil.Converter a;

	ajil.protocol.AbstractPacketCrypter b;
	ajil.protocol.FilterPacketCrypter c;
	ajil.protocol.PacketCrypter d;

	ajil.protocol.v5.V5Command e;
	ajil.protocol.v5.V5PacketCrypter f;

	ajil.tools.redirectServer.RedirectionImpl g;
	ajil.tools.redirectServer.RedirectServer h;
	ajil.tools.redirectServer.TextAreaOutputStream i;

	ajil.udp.Connection j;
	ajil.udp.ConnectionEvent k;
	ajil.udp.ConnectionExceptionAdapter l;
	ajil.udp.ConnectionExceptionEvent m;
	ajil.udp.ConnectionExceptionListener n;
	ajil.udp.PacketAdapter o;
	ajil.udp.PacketEvent p;
	ajil.udp.PacketListener q;
}
