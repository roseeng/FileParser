//
// FilterPacketCrypter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.protocol;


/**
 * <p>
 * This class is the superclass of all classes that filter packet crypters.
 * These packet crypters sit on top of an already existing packet crypter, the
 * <i>underlying</i> packet crypter, which it uses to encrypt or decrypt
 * packets, but possibly transforming the data along the way or providing
 * additional functionality.</p>
 * <p>
 * The class <code>FilterPacketCrypter</code> itself simply overrides all
 * methods of its superclass, <code>AbstractPacketCrypter</code>, necessary to
 * override in order to pass all requests to the underlying packet crypter.
 * Subclasses of <code>FilterPacketCrypter</code> may further override some of
 * these methods as well as provide additional methods and fields.</p>
 *
 * @see PacketCrypter
 * @see AbstractPacketCrypter
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-06-21
 * @version 2000-06-21
 */



public abstract class FilterPacketCrypter extends AbstractPacketCrypter {

// Elements(s)
////////////////////

	protected PacketCrypter packetCrypter;


// Constructor(s)
////////////////////

	/**
	 * Constructs a new filter packet crypter without an underlying packet
	 * crypter. Before this filter packet crypter can be used, the underlying
	 * packet crypter must be specified by using the <code>{@link
	 * #setPacketCrypter setPacketCrypter}</code> method.
	 *
	 * @see #FilterPacketCrypter(PacketCrypter)
	 */
	FilterPacketCrypter() {}

	/**
	 * Constructs a new filter packet crypter with the specified underlying
	 * packet crypter. This underlying packet crypter can be changed by using
	 * the <code>{@link #setPacketCrypter setPacketCrypter}</code> method.
	 *
	 * @param packetCrypter the packet crypter to pass all requests to
	 */
	FilterPacketCrypter(PacketCrypter packetCrypter) {
		setPacketCrypter(packetCrypter);
	}

// Method(s)
////////////////////

	/**
	 * Changes the underlying packet crypter of this filter packet crypter.
	 *
	 * @param packetCrypter This will be used as the underlying packet
	 *        crypter.
	 */
	public void setPacketCrypter(PacketCrypter packetCrypter) {
		this.packetCrypter = packetCrypter;
	}

	/**
	 * Returns the currently used underlying packet crypter.
	 */
	public PacketCrypter getPacketCrypter() {
		return packetCrypter;
	}

	/**
	 * Forwards this method call to the underlying packet crypter.
	 *
	 * @see PacketCrypter#encrypt(byte[], int, int)
	 */
	public byte[] encrypt(byte[] packet, int offset, int length) {
		return packetCrypter.encrypt(packet, offset, length);
	}

	/**
	 * Forwards this method call to the underlying packet crypter.
	 *
	 * @see PacketCrypter#decrypt(byte[], int, int)
	 */
	public byte[] decrypt(byte[] packet, int offset, int length) {
		return packetCrypter.decrypt(packet, offset, length);
	}
}
