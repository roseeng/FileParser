//
// V5Command.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.protocol.v5;


/**
 * <p>
 * This class contains ICQ's known V5 commands and provides methods to convert
 * values to commands and commands to values.</p>
 * <p>
 * For more information, see Henrik Isaksson's document at
 * <a href="http://www.algonet.se/~henisak/icq/icqv5.html">
 * http://www.algonet.se/~henisak/icq/icqv5.html</a></p>
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-21
 * @version 2000-06-20
 */


import ajil.Converter;


public class V5Command {

// Elements(s)
////////////////////

//client commands
	public final static int
	 CMD_ACK                =   10,
	 CMD_SEND_MESSAGE       =  270,
	 CMD_LOGIN              = 1000,
	 CMD_REG_NEW_USER       = 1020,
	 CMD_CONTACT_LIST       = 1030,
	 CMD_SEARCH_UIN         = 1050,
	 CMD_SEARCH_USER        = 1060,
	 CMD_KEEP_ALIVE         = 1070,
	 CMD_SEND_TEXT_CODE     = 1080,
	 CMD_ACK_MESSAGES       = 1090,
	 CMD_LOGIN_1            = 1100,
	 CMD_MSG_TO_NEW_USER    = 1110,
	 CMD_INFO_REQ           = 1120,
	 CMD_EXT_INFO_REQ       = 1130,
	 CMD_CHANGE_PW          = 1180,
	 CMD_NEW_USER_INFO      = 1190,
	 CMD_UPDATE_EXT_INFO    = 1200,
	 CMD_QUERY_SERVERS      = 1210,
	 CMD_QUERY_ADDONS       = 1220,
	 CMD_STATUS_CHANGE      = 1240,
	 CMD_NEW_USER_1         = 1260,
	 CMD_UPDATE_INFO        = 1290,
	 CMD_AUTH_UPDATE        = 1300,
	 CMD_KEEP_ALIVE2        = 1310,
	 CMD_LOGIN_2            = 1320,
	 CMD_ADD_TO_LIST        = 1340,
	 CMD_RAND_SET           = 1380,
	 CMD_RAND_SEARCH        = 1390,
	 CMD_META_USER          = 1610,
	 CMD_INVIS_LIST         = 1700,
	 CMD_VIS_LIST           = 1710,
	 CMD_UPDATE_LIST        = 1720,

//server commands
	 SRV_ACK                =   10,
	 SRV_GO_AWAY            =   40,
	 SRV_NEW_UIN            =   70,
	 SRV_LOGIN_REPLY        =   90,
	 SRV_BAD_PASS           =  100,
	 SRV_USER_ONLINE        =  110,
	 SRV_USER_OFFLINE       =  120,
	 SRV_QUERY              =  130,
	 SRV_USER_FOUND         =  140,
	 SRV_END_OF_SEARCH      =  160,
	 SRV_NEW_USER           =  180,
	 SRV_UPDATE_EXT         =  200,
	 SRV_RECV_MESSAGE       =  220,
	 SRV_X2                 =  230,
	 SRV_NOT_CONNECTED      =  240,
	 SRV_TRY_AGAIN          =  250,
	 SRV_SYS_DELIVERED_MESS =  260,
	 SRV_INFO_REPLY         =  280,
	 SRV_EXT_INFO_REPLY     =  290,
	 SRV_STATUS_UPDATE      =  420,
	 SRV_SYSTEM_MESSAGE     =  450,
	 SRV_UPDATE_SUCCESS     =  480,
	 SRV_UPDATE_FAIL        =  490,
	 SRV_AUTH_UPDATE        =  500,
	 SRV_MULTI_PACKET       =  530,
	 SRV_X1                 =  540,
	 SRV_RAND_USER          =  590,
	 SRV_META_USER          =  990;

/* //client to client (commands/msgs?)
	 CTCINTRO,
	 CTCUDP,
	 CTCTCP,
	 CTCINIT,
	 CTCMSG,
	 CTCACK,
	 CTCDEF,
	 CTCREV,
	 CTCFDP,
	 CTCCHAT;
*/

// Constructor(s)
////////////////////

	/**
	 * Instanciation of this class isn't allowed.
	 */
	private V5Command() {}

// Method(s)
////////////////////

	/**
	 * Returns a string representation of the command name, that's ID is
	 * hold in the specified byte array at the specified position in little
	 * endian byte order.
	 *
	 * @param b byte array that holds the command ID
	 * @param pos position of the ID's first byte in the array
	 */
	public static final String forID(byte[] b, int pos) {
		return forID(Converter.get2BInt(b, pos));
	}

	/**
	 * Returns a String representing the command name for the
	 * given command ID.
	 *
	 * @param id command id to get the name for
	 */
	public static final String forID(int id) {
		switch (id) {
		  //client commands
		  case CMD_ACK               : return "ACK";  //not "CMD_ACK", because 10 is also "SRV_ACK" (see below)
		  case CMD_SEND_MESSAGE      : return "CMD_SEND_MESSAGE";
		  case CMD_LOGIN             : return "CMD_LOGIN";
		  case CMD_REG_NEW_USER      : return "CMD_REG_NEW_USER";
		  case CMD_CONTACT_LIST      : return "CMD_CONTACT_LIST";
		  case CMD_SEARCH_UIN        : return "CMD_SEARCH_UIN";
		  case CMD_SEARCH_USER       : return "CMD_SEARCH_USER";
		  case CMD_KEEP_ALIVE        : return "CMD_KEEP_ALIVE";
		  case CMD_SEND_TEXT_CODE    : return "CMD_SEND_TEXT_CODE";
		  case CMD_ACK_MESSAGES      : return "CMD_ACK_MESSAGES";
		  case CMD_LOGIN_1           : return "CMD_LOGIN_1";
		  case CMD_MSG_TO_NEW_USER   : return "CMD_MSG_TO_NEW_USER";
		  case CMD_INFO_REQ          : return "CMD_INFO_REQ";
		  case CMD_EXT_INFO_REQ      : return "CMD_EXT_INFO_REQ";
		  case CMD_CHANGE_PW         : return "CMD_CHANGE_PW";
		  case CMD_NEW_USER_INFO     : return "CMD_NEW_USER_INFO";
		  case CMD_UPDATE_EXT_INFO   : return "CMD_UPDATE_EXT_INFO";
		  case CMD_QUERY_SERVERS     : return "CMD_QUERY_SERVERS";
		  case CMD_QUERY_ADDONS      : return "CMD_QUERY_ADDONS";
		  case CMD_STATUS_CHANGE     : return "CMD_STATUS_CHANGE";
		  case CMD_NEW_USER_1        : return "CMD_NEW_USER_1";
		  case CMD_UPDATE_INFO       : return "CMD_UPDATE_INFO";
		  case CMD_AUTH_UPDATE       : return "CMD_AUTH_UPDATE";
		  case CMD_KEEP_ALIVE2       : return "CMD_KEEP_ALIVE2";
		  case CMD_LOGIN_2           : return "CMD_LOGIN_2";
		  case CMD_ADD_TO_LIST       : return "CMD_ADD_TO_LIST";
		  case CMD_RAND_SET          : return "CMD_RAND_SET";
		  case CMD_RAND_SEARCH       : return "CMD_RAND_SEARCH";
		  case CMD_META_USER         : return "CMD_META_USER";
		  case CMD_INVIS_LIST        : return "CMD_INVIS_LIST";
		  case CMD_VIS_LIST          : return "CMD_VIS_LIST";
		  case CMD_UPDATE_LIST       : return "CMD_UPDATE_LIST";

		  //server commands
		  //case SRV_ACK               : return "SRV_ACK"; //case SRV_ACK: -> case 10: (same as CMD_ACK)
		  case SRV_GO_AWAY           : return "SRV_GO_AWAY";
		  case SRV_NEW_UIN           : return "SRV_NEW_UIN";
		  case SRV_LOGIN_REPLY       : return "SRV_LOGIN_REPLY";
		  case SRV_BAD_PASS          : return "SRV_BAD_PASS";
		  case SRV_USER_ONLINE       : return "SRV_USER_ONLINE";
		  case SRV_USER_OFFLINE      : return "SRV_USER_OFFLINE";
		  case SRV_QUERY             : return "SRV_QUERY";
		  case SRV_USER_FOUND        : return "SRV_USER_FOUND";
		  case SRV_END_OF_SEARCH     : return "SRV_END_OF_SEARCH";
		  case SRV_NEW_USER          : return "SRV_NEW_USER";
		  case SRV_UPDATE_EXT        : return "SRV_UPDATE_EXT";
		  case SRV_RECV_MESSAGE      : return "SRV_RECV_MESSAGE";
		  case SRV_X2                : return "SRV_X2";
		  case SRV_NOT_CONNECTED     : return "SRV_NOT_CONNECTED";
		  case SRV_TRY_AGAIN         : return "SRV_TRY_AGAIN";
		  case SRV_SYS_DELIVERED_MESS: return "SRV_SYS_DELIVERED_MESS";
		  case SRV_INFO_REPLY        : return "SRV_INFO_REPLY";
		  case SRV_EXT_INFO_REPLY    : return "SRV_EXT_INFO_REPLY";
		  case SRV_STATUS_UPDATE     : return "SRV_STATUS_UPDATE";
		  case SRV_SYSTEM_MESSAGE    : return "SRV_SYSTEM_MESSAGE";
		  case SRV_UPDATE_SUCCESS    : return "SRV_UPDATE_SUCCESS";
		  case SRV_UPDATE_FAIL       : return "SRV_UPDATE_FAIL";
		  case SRV_AUTH_UPDATE       : return "SRV_AUTH_UPDATE";
		  case SRV_MULTI_PACKET      : return "SRV_MULTI_PACKET";
		  case SRV_X1                : return "SRV_X1";
		  case SRV_RAND_USER         : return "SRV_RAND_USER";
		  case SRV_META_USER         : return "SRV_META_USER";

		  default:
			throw new IllegalArgumentException(
			 "Unknown command ID: " +
			 Converter.getHexString((short)id) +
			 " (" + id + ')'
			);
		}
	}
}
