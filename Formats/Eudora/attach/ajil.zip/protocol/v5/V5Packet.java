//
// V5Packet.java
//
// Copyright (c) 2000 by Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.protocol.v5;


/**
 * Instances of this class represent ICQ V5 UDP packets.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-06-23
 * @version 2000-06-23
 */



public class V5Packet {

// Elements(s)
////////////////////

	private byte[] packet;
	private int offset;
	private int length;

	/**
	 * Is true, if no instance-extern references to the byte array <code>
	 * packet</code> exist.
	 */
	private boolean isPacketArrayPrivate;


// Constructor(s)
////////////////////

	/**
	 * Constructs a new V5Packet with specified packet data.
	 */
	public V5Packet() {
	}



// Method(s)
////////////////////


}
