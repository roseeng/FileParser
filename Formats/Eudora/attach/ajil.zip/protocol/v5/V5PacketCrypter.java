//
// V5PacketCrypter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.protocol.v5;


/**
 * This class implements ICQ's V5 packet encryption and decryption. For
 * details, see this <a href="http://www.algonet.se/~henisak/icq/icqv5.html">
 * inofficial-official ICQ protocol specification</a>.
 *
 * @see ajil.protocol.PacketCrypter
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-03-21
 * @version 2000-06-20
 */


import ajil.Converter;
import ajil.protocol.AbstractPacketCrypter;


public class V5PacketCrypter extends AbstractPacketCrypter {

// Elements(s)
////////////////////

	/**
	 * This byte array contains the V5 table data, necessary to encrypt or
	 * decrypt packets.
	 */
	public static final byte[] TABLE = {
	  /*        _0    _1    _2    _3    _4    _5    _6    _7    _8    _9    _A    _B    _C    _D    _E    _F  */
	  /* 0_ */ 0x59, 0x60, 0x37, 0x6B, 0x65, 0x62, 0x46, 0x48, 0x53, 0x61, 0x4C, 0x59, 0x60, 0x57, 0x5B, 0x3D,
	  /* 1_ */ 0x5E, 0x34, 0x6D, 0x36, 0x50, 0x3F, 0x6F, 0x67, 0x53, 0x61, 0x4C, 0x59, 0x40, 0x47, 0x63, 0x39,
	  /* 2_ */ 0x50, 0x5F, 0x5F, 0x3F, 0x6F, 0x47, 0x43, 0x69, 0x48, 0x33, 0x31, 0x64, 0x35, 0x5A, 0x4A, 0x42,
	  /* 3_ */ 0x56, 0x40, 0x67, 0x53, 0x41, 0x07, 0x6C, 0x49, 0x58, 0x3B, 0x4D, 0x46, 0x68, 0x43, 0x69, 0x48,
	  /* 4_ */ 0x33, 0x31, 0x44, 0x65, 0x62, 0x46, 0x48, 0x53, 0x41, 0x07, 0x6C, 0x69, 0x48, 0x33, 0x51, 0x54,
	  /* 5_ */ 0x5D, 0x4E, 0x6C, 0x49, 0x38, 0x4B, 0x55, 0x4A, 0x62, 0x46, 0x48, 0x33, 0x51, 0x34, 0x6D, 0x36,
	  /* 6_ */ 0x50, 0x5F, 0x5F, 0x5F, 0x3F, 0x6F, 0x47, 0x63, 0x59, 0x40, 0x67, 0x33, 0x31, 0x64, 0x35, 0x5A,
	  /* 7_ */ 0x6A, 0x52, 0x6E, 0x3C, 0x51, 0x34, 0x6D, 0x36, 0x50, 0x5F, 0x5F, 0x3F, 0x4F, 0x37, 0x4B, 0x35,
	  /* 8_ */ 0x5A, 0x4A, 0x62, 0x66, 0x58, 0x3B, 0x4D, 0x66, 0x58, 0x5B, 0x5D, 0x4E, 0x6C, 0x49, 0x58, 0x3B,
	  /* 9_ */ 0x4D, 0x66, 0x58, 0x3B, 0x4D, 0x46, 0x48, 0x53, 0x61, 0x4C, 0x59, 0x40, 0x67, 0x33, 0x31, 0x64,
	  /* A_ */ 0x55, 0x6A, 0x32, 0x3E, 0x44, 0x45, 0x52, 0x6E, 0x3C, 0x31, 0x64, 0x55, 0x6A, 0x52, 0x4E, 0x6C,
	  /* B_ */ 0x69, 0x48, 0x53, 0x61, 0x4C, 0x39, 0x30, 0x6F, 0x47, 0x63, 0x59, 0x60, 0x57, 0x5B, 0x3D, 0x3E,
	  /* C_ */ 0x64, 0x35, 0x3A, 0x3A, 0x5A, 0x6A, 0x52, 0x4E, 0x6C, 0x69, 0x48, 0x53, 0x61, 0x6C, 0x49, 0x58,
	  /* D_ */ 0x3B, 0x4D, 0x46, 0x68, 0x63, 0x39, 0x50, 0x5F, 0x5F, 0x3F, 0x6F, 0x67, 0x53, 0x41, 0x25, 0x41,
	  /* E_ */ 0x3C, 0x51, 0x54, 0x3D, 0x5E, 0x54, 0x5D, 0x4E, 0x4C, 0x39, 0x50, 0x5F, 0x5F, 0x5F, 0x3F, 0x6F,
	  /* F_ */ 0x47, 0x43, 0x69, 0x48, 0x33, 0x51, 0x54, 0x5D, 0x6E, 0x3C, 0x31, 0x64, 0x35, 0x5A, 0x00, 0x00
	};


// Constructor(s)
////////////////////

	/**
	 * Constructs a new V5PacketCrypter.
	 */
	public V5PacketCrypter() {}


// Method(s)
////////////////////

	/**
	 * Encrypts a packet.
	 *
	 * @see ajil.protocol.PacketCrypter#encrypt
	 */
	public byte[] encrypt(byte[] packet, int offset, int length) {
		if      (packet.length < offset + length)
			 throw new IllegalArgumentException("packet.length < offset + length");
		else if (offset < 0 || length < 0)
			 throw new IllegalArgumentException("offset or length < 0");
		else if (length < 0x18)
			 throw new IllegalArgumentException("length < 0x18");

		int checkCode = createCheckCode(packet, offset, length);

		//encrypt the packet
		doCrypt(packet, offset, length, checkCode);

		//insert scrambled checkcode
		Converter.setInt(packet, offset + 20, getScrambledCheckCode(checkCode));


		return packet;
	}

	/**
	 * Decrypts a packet.
	 *
	 * @see ajil.protocol.PacketCrypter#decrypt
	 */
	public byte[] decrypt(byte[] packet, int offset, int length) {
		if      (packet.length < offset + length)
			 throw new IllegalArgumentException("packet.length < offset + length");
		else if (offset < 0 || length < 0)
			 throw new IllegalArgumentException("offset or length < 0");
		else if (length < 0x18)
			 throw new IllegalArgumentException("length < 0x18");


		int checkCode = getCheckCode(packet, offset);

		doCrypt(packet, offset, length, checkCode);

		//insert (not encrypted,) descrambled checkcode
		Converter.setInt(packet, offset + 20, checkCode);


		return packet;
	}

	/**
	 * Performs the encryption or decryption of a packet. To make this
	 * method usable for both, encryption and decryption, it is necessary
	 * to specify the check code being used for en-/decryption.
	 *
	 * @param packet byte array storing the packet data
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @param length number of bytes that belong to the packet (packet length)
	 * @param checkCode the check code to use in the crypting algorithm
	 */
	protected static final void doCrypt(byte[] packet, int offset, int length, int checkCode) {
		long cryptCodeL = Converter.ucToLong(
		 getCryptCode(checkCode, length));

		//i is the position of the first byte of a 4-byte-bundle (== DWORD == in Java: int)
		for (int currentPos, i = 0x0A; i < length - 3; i += 4) {

			currentPos = offset + i;

			Converter.setInt(
			  packet,
			  currentPos,
			  Converter.getInt(packet, currentPos) ^

			  //We should possibly change the type of the TABLE array
			  //from byte[] to int[], because we could then avoid some
			  //calculation, such as Converter.ucToLong(TABLE[...]).
			  ((int)(cryptCodeL + Converter.ucToLong(TABLE[i & 0xFF])))
			);
		}
	}

	/**
	 * Calculates and returns the code, used to encrypt/decrypt a packet,
	 * based on the packet's check code.
	 *
	 * @param checkCode check code to use for calculating the crypt code
	 * @param packetLength the length (in bytes) of the packet the crypt
	 *        code is being calculated for
	 *
	 * @return the 32-bit crypt code
	 */
	protected static final int getCryptCode(int checkCode, int packetLength) {
		return (int)
		 (0x68656C6CL * packetLength + Converter.ucToLong(checkCode));
	}

	/**
	 * <p>
	 * Creates a check code for a packet and returns it. The check codes,
	 * returned by two different invocations of this method on the same
	 * packet data, will statistical be equal only in every <code>((length
	 * - 18) * 256)</code>th case.</p>
	 * <p>
	 * <b>NOTE:</b> Any random set of 32 bits can be used as a valid check
	 * code.</p>
	 *
	 * @param packet byte array storing the unencrypted packet data
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @param length number of bytes that belong to the packet (packet length)
	 * @return the 32-bit check code
	 */
	protected static final int createCheckCode(byte[] packet, int offset, int length) {
		int
		 number1,    //first number needed for calculation
		 number2,    //second number needed for calculation
		 rnd1, rnd2; //two random numbers needed to calculate the second needed number

		byte[] helper = new byte[4]; //makes understanding easier and
		                             //the code less erroneous :o)

		//found number1
		helper[3] = packet[offset + 8];  //remember: 0x8,0x4,0x2,0x6 == 8,4,2,6
		helper[2] = packet[offset + 4];
		helper[1] = packet[offset + 2];
		helper[0] = packet[offset + 6];
		number1 = Converter.getInt(helper, 0);


		//found number2

		//0x18 <= rnd1 <= length - 1  (length must be > 0x18)
		//This is NOT exactly, what Sebastien Dault tells in his
		//documentation about the V5 encryption, but i think that the
		//following line from his documentation contains an erratum:
		//"R1 = a random number beetween 0 and (PL - 18) - 1  (or MOD (PL - 18))"
		rnd1 = 0x18 + (int)(Math.random() * (length - 0x18));

		//0 <= rnd2 <= 0xFF
		rnd2 = (int)(Math.random() * 0x100);

		helper[3] = (byte)                  rnd1 ;
		helper[2] = (byte) ~packet[offset + rnd1];
		helper[1] = (byte)                  rnd2 ;
		helper[0] = (byte) ~TABLE [         rnd2];
		number2 = Converter.getInt(helper, 0);


		//make final calculation for the check code and return it
		return number1 ^ number2;
	}


	/**
	 * Scambles and returns the specified check code.
	 *
	 * @param checkCode the check code to scramble
	 * @return the 32-bit scrambled check code
	 */
	protected static final int getScrambledCheckCode(int checkCode) {
		long checkCodeL = Converter.ucToLong(checkCode);

		return (int)(
		  ((checkCodeL & 0x0000001FL) <<  0x0C) +
		  ((checkCodeL & 0x03E003E0L) <<  0x01) +
		  ((checkCodeL & 0xF8000400L) >>> 0x0A) +
		  ((checkCodeL & 0x0000F800L) <<  0x10) +
		  ((checkCodeL & 0x041F0000L) >>> 0x0F)
		);
	}

	/**
	 * Extracts the check code out of an encrypted packet, descrambles it,
	 * and returns it.
	 *
	 * @param packet byte array storing the packet data (or at least the
	 *        scambled check code at position <code>offset + 20</code>)
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @return the 32-bit check code
	 */
	protected static final int getCheckCode(byte[] packet, int offset) {
		long checkCodeL = Converter.ucToLong(
		 Converter.getInt(packet, offset + 20));

		checkCodeL =
		 ((checkCodeL & 0x0001F000L) >>> 0x0C) +
		 ((checkCodeL & 0x07C007C0L) >>> 0x01) +
		 ((checkCodeL & 0x003C0001L) <<  0x0A) +
		 ((checkCodeL & 0xF8000000L) >>> 0x10) +
		 ((checkCodeL & 0x0000083EL) <<  0x0F)
		;

		return (int)checkCodeL;
	}
}
