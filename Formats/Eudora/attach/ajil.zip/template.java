//
// <classname>.java
//
// Copyright (c) 2000 by <copyright holder> &lt;<copyright holder's eMail-address>&gt;
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil;


/**
 * <description>
 *
 * @author  <author> &lt;<author's eMail-address>&gt;
 * @since   2000-0-0
 * @version 2000-0-0
 */



public class <classname> {

// Elements(s)
////////////////////



// Constructor(s)
////////////////////



// Method(s)
////////////////////


}
