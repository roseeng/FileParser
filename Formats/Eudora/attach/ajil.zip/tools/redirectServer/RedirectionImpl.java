//
// RedirectionImpl.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.tools.redirectServer;


/**
 * This class is a user interface independent implementation of the
 * redirect server.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2000-06-20
 */


import ajil.udp.*;  //hey, yeah! This is the first time my tiny lib is used! :�)
import ajil.protocol.v5.*;
import ajil.Converter;
import java.io.*;
import java.net.*;


public class RedirectionImpl
 implements PacketListener {

// Elements(s)
////////////////////

	public final static String LINE_SEP_STR = System.getProperty("line.separator");


	protected PacketListener packetListener; //if there is a user interface which wants to be up to date...

	protected Connection cConn; //used for sends to and receives from clients
	protected Connection sConn; //used for sends to and receives from remote server

	protected DatagramPacket bufferPacket;

	protected InetAddress clientAddr;  //InetAddress of client which last sent a client packet
	protected int         clientPort;  //port of client which last sent a client packet


	protected ConnectionExceptionAdapter connExceptAdapter = new ConnectionExceptionAdapter();


	//----- packet en-/decryption
	public static final V5PacketCrypter pCrypter = new V5PacketCrypter();

// Constructor(s)
////////////////////

	/**
	 * Constructs a new RedirectionImpl.
	 *
	 * @param cConn Connection to use for sending to and receiving from clients
	 * @param sConn Connection to use for sending to and receiving from remote server
	 */
	public RedirectionImpl(Connection cConn, Connection sConn) {
		if (cConn != null) setClientConnection(cConn);
		if (sConn != null) setRemoteServerConnection(sConn);
		bufferPacket = new DatagramPacket(new byte[1024], 1024);
	}


// Method(s)
////////////////////

	/**
	 * @see ajil.udp.PacketListener#packetSent
	 */
	public void packetSent(PacketEvent e) {
		System.out.println("----- Sent a packet.");
	}

	/**
	 * Invoked when a packet was received from a client.
	 */
	protected void clientPacketReceived(DatagramPacket packet) {
		byte[] data = packet.getData();
		int dataLength = packet.getLength();
		int prms       = dataLength - 24; //length of comand specific parameters
		int p;

		String commandName;
		try { commandName = V5Command.forID(data, 14); }
		catch (IllegalArgumentException e) { commandName = e.getMessage(); }

		String infoString =
		 "CLIENT (" + packet.getAddress().getHostName() + ':' + packet.getPort() + "):" + LINE_SEP_STR +

		 "Packet Length: " + dataLength + LINE_SEP_STR +
		 "Version   : " + Converter.getHexDump(data, p =0,    2) + "       (" + Converter.get2BInt (data, p)       + ')' + LINE_SEP_STR +
		 "Zero      : " + Converter.getHexDump(data, p+=2,    4) +       " (" + Converter.get4BLong(data, p)       + ')' + LINE_SEP_STR +
		 "UIN       : " + Converter.getHexDump(data, p+=4,    4) +       " (" + Converter.get4BLong(data, p)       + ')' + LINE_SEP_STR +
		 "Session ID: " + Converter.getHexDump(data, p+=4,    4) +       " (" + Converter.get4BLong(data, p)       + ')' + LINE_SEP_STR +
		 "Command   : " + Converter.getHexDump(data, p+=4,    2) + "       (" + commandName                        + ')' + LINE_SEP_STR +
		 "Seq.-Num.1: " + Converter.getHexDump(data, p+=2,    2) + "       (" + Converter.get2BInt (data, p)       + ')' + LINE_SEP_STR +
		 "Seq.-Num.2: " + Converter.getHexDump(data, p+=2,    2) + "       (" + Converter.get2BInt (data, p)       + ')' + LINE_SEP_STR +
		 "Checkcode : " + Converter.getHexDump(data, p+=2,    4) +       " (" + Converter.get4BLong(data, p)       + ')' + LINE_SEP_STR +
		 "Parameters: " + Converter.getHexDump(data, p+=4, prms) +       " (" + Converter.getString(data, p, prms) + ')' + LINE_SEP_STR
		;

		System.out.println(infoString);
	}

	/**
	 * Invoked when a packet was received from the server.
	 */
	protected void serverPacketReceived(DatagramPacket packet) {
		byte[] data = packet.getData();
		int dataLength = packet.getLength();
		int prms       = dataLength - 24;

		System.out.println(
			"SERVER PACKET RECEIVED -> NOT YET IMPLEMENTED!!!"
		);
	}

	/**
	 * Invoked when a new DatagramPacket was received by either
	 * a client or the remote server.
	 */
	public synchronized void packetReceived(PacketEvent e) {
		DatagramPacket packet = e.getPacket();
		byte[] data = packet.getData();
		byte[] bufData = bufferPacket.getData();

		//----- copy received packet into buffer packet
		System.arraycopy(data, packet.getOffset(), bufData, 0, packet.getLength());
		bufferPacket.setData(bufData, 0, packet.getLength());
		bufferPacket.setAddress(packet.getAddress());
		bufferPacket.setPort(packet.getPort());

		if (e.getSource() == cConn) {
			pCrypter.decrypt(bufferPacket.getData(), 0, bufferPacket.getLength());
			clientPacketReceived(bufferPacket);

			clientAddr = packet.getAddress();
			clientPort = packet.getPort();

			packet.setAddress(null);
			sConn.send(packet); //sConn's socket must be connected

		} else if (e.getSource() == sConn) {
			serverPacketReceived(bufferPacket);

			if (clientAddr == null) {
				System.out.println("----- Couldn't forward remote server packet to client: Don't know client address.");
			} else {
				packet.setAddress(clientAddr);
				packet.setPort(clientPort);

				cConn.send(packet);
			}
		} else
			System.out.println("----- SHIT! What's this?! e.getSource() is neither equal to cConn nor to sConn (RedirectImpl.packetReceived(PacketEvent e))");

		if (packetListener != null)
			packetListener.packetReceived(e);
	}

	public Connection getClientConnection() {
		return cConn;
	}

	public void setClientConnection(Connection cConn) {
		if (this.cConn != null) {
			this.cConn.removePacketListener(this);
			this.cConn.removeConnectionExceptionListener(connExceptAdapter);
		}

		cConn.addPacketListener(this);
		cConn.addConnectionExceptionListener(connExceptAdapter);
		this.cConn = cConn;
	}

	public Connection getRemoteServerConnection() {
		return sConn;
	}

	public void setRemoteServerConnection(Connection sConn) {
		if (this.sConn != null) {
			this.sConn.removePacketListener(this);
			this.sConn.removeConnectionExceptionListener(connExceptAdapter);
		}

		sConn.addPacketListener(this);
		sConn.addConnectionExceptionListener(connExceptAdapter);
		this.sConn = sConn;
	}
}
