//
// Connection.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.udp;


/**
 * This is roughly a wrapper class for <code>java.net.DatagramSocket</code>. It
 * provides an event listener architecture for <code>PacketEvent</code>s and
 * <code>ConnectionExceptionEvent</code>s.
 *
 * The algorithm for sending packets is not implemented fine. The same thread
 * which invokes <code>send(DatagramPacket)</code> has to invoke the packet
 * listeners' <code>packetSent(PacketEvent)</code> method also. This will be
 * changed in future, but i'm too busy for now.    :�(
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2000-06-20
 *
 * @see PacketEvent
 * @see ConnectionExceptionEvent
 */


import java.io.*;
import java.net.*;
import java.util.Vector;


public class Connection implements Runnable {

// Elements(s)
////////////////////

	/**
	 * Default size for the <code>DatagramPacket</code> used to receive
	 * packets. This is used in the constructor if <code>
	 * getMaxRecvPacketSize()</code>, which returns the value of <code>
	 * socket.getReceiveBufferSize()</code>, fails.
	 *
	 * @see java.net.DatagramSocket
	 */
	public static final int DEFAULT_RECV_PACKET_SIZE = 512;

	/**
	 * This <code>Vector</code> contains the <code>PacketListener
	 * </code>s registered for this <code>Connection</code>.
	 */
	Vector packetListeners;

	/**
	 * This <code>Vector</code> contains the <code>
	 * ConnectionExceptionListener</code>s registered for this <code>
	 * Connection</code>.
	 */
	Vector exceptionListeners;

	/**
	 * <code>DatagramSocket</code> used for transceiving.
	 */
	DatagramSocket socket;

	/**
	 * A <code>DatagramPacket</code> useful when receiving packets.
	 */
	DatagramPacket recvPacket;

//	/**
//	 * A <code>DatagramPacket</code> useful when sending packets.
//	 */
//	DatagramPacket sendPacket;

	/**
	 * The Thread which listens for incoming packets.
	 */
	Thread runner;


// Constructor(s)
////////////////////

	/**
	 * Constructs a new <code>Connection</code>. The length of the <code>
	 * DatagramPacket</code> used when receiving a packet is set to the
	 * return value of the specified <code>DatagramSocket</code>'s <code>
	 * getReceiveBufferSize()</code> method.
	 *
	 * @param socket the <code>DatagramSocket</code> to use for
	 *        transceiving.
	 */
	public Connection(DatagramSocket socket) {
		this.socket = socket;

		int recvPacketSize;
		try { recvPacketSize = getMaxRecvPacketSize(); }
		catch (SocketException e) {
			recvPacketSize = DEFAULT_RECV_PACKET_SIZE;
		}

		recvPacket = new DatagramPacket(new byte[recvPacketSize], recvPacketSize);
	}


// Method(s)
////////////////////

	/**
	 * Listens for incoming <code>DatagramPackets</code>. An application
	 * should not invoked this method directly. The <code>start</code>
	 * method of this <code>Connection</code> should be used to start
	 * receiving new packets.
	 *
	 * @see Connection#start()
	 */
	public void run() {
		Thread thisThread = Thread.currentThread();

		while (thisThread == runner) {
			try {
				socket.receive(recvPacket);

				processPacketEvent(new PacketEvent(
				  this,
				  PacketEvent.PACKET_RECEIVED,
				  recvPacket
				));
			}
			catch (IOException e) {
				processConnectionExceptionEvent(
				  new ConnectionExceptionEvent(
				    this,
				    ConnectionExceptionEvent.RECEIVE_EXCEPTION,
				    null,
				    e
				  )
				);
			}
		}
	}

	/**
	 * Processes events on this connection. If the event is an instance of
	 * <code>ConnectionExceptionEvent</code>, the <code>
	 * processConnectionExceptionEvent</code> method will be invoked. If
	 * the event is an instance of <code>PacketEvent</code>, this method
	 * will invoke <code>processPacketEvent</code>. If it's an unknown
	 * event, an IllegalArgumentException will be thrown.
	 *
	 * @param        e the event being processed
	 * @see          #processPacketEvent
	 * @see          #processConnectionExceptionEvent
	 */
	protected void processEvent(ConnectionEvent e) {
		if (e instanceof ConnectionExceptionEvent)
			processConnectionExceptionEvent((ConnectionExceptionEvent)e);

		else if (e instanceof PacketEvent)
			processPacketEvent((PacketEvent)e);

		else
			throw new IllegalArgumentException("Unknown ConnectionException subclass: " + e.getClass().getName());
	}

	/**
	 * Processes <code>PacketEvent</code>s occurring on this connection by
	 * dispatching them to the registered <code>PacketListener</code>s.
	 *
	 * @param       e the packet event being processed
	 * @see         PacketListener
	 * @see         #addPacketListener
	 */
	protected void processPacketEvent(PacketEvent e) {
		switch (e.getId()) {
		  case e.PACKET_RECEIVED:
			processPacketEvent_PACKET_RECEIVED(e);
			return;

		  case e.PACKET_SENT:
			processPacketEvent_PACKET_SENT(e);
			return;

		  default:
			throw new IllegalArgumentException("Unknown event id of PacketEvent: " + e.getId());
		}
	}

	/**
	 * @see #processPacketEvent
	 */
	private final void processPacketEvent_PACKET_RECEIVED(PacketEvent e) {
		if (packetListeners == null)
			return;  //no registered listeners

		synchronized (packetListeners) {
			for (int i = 0; i < packetListeners.size(); i++)
				((PacketListener)packetListeners.elementAt(i))
				 .packetReceived(e);
		}
	}

	/**
	 * @see #processPacketEvent
	 */
	private final void processPacketEvent_PACKET_SENT(PacketEvent e) {
		if (packetListeners == null)
			return;  //no registered listeners

		synchronized (packetListeners) {
			for (int i = 0; i < packetListeners.size(); i++)
				((PacketListener)packetListeners.elementAt(i))
				 .packetSent(e);
		}
	}

	/**
	 * Processes <code>ConnectionExceptionEvent</code>s occurring on this
	 * connection by dispatching them to the registered <code>
	 * ConnectionExceptionListener</code>s.
	 *
	 * @param       e the event being processed
	 * @see         ConnectionExceptionListener
	 * @see         #addConnectionExceptionListener
	 */
	protected void processConnectionExceptionEvent(ConnectionExceptionEvent
	 e) {
		switch (e.getId()) {
		  case e.RECEIVE_EXCEPTION:
			processConnectionExceptionEvent_RECEIVE_EXCEPTION(e);
			return;

		  case e.SEND_EXCEPTION:
			processConnectionExceptionEvent_SEND_EXCEPTION(e);
			return;

		  default:
			throw new IllegalArgumentException("Unknown event id of ConnectionExceptionEvent: " + e.getId());
		}
	}

	/**
	 * @see #processConnectionExceptionEvent
	 */
	private final void processConnectionExceptionEvent_RECEIVE_EXCEPTION(
	ConnectionExceptionEvent e) {
		if (exceptionListeners == null)
			return;  //no registered listeners

		synchronized (exceptionListeners) {
			for (int i = 0; i < exceptionListeners.size(); i++)
				((ConnectionExceptionListener)exceptionListeners.elementAt(i))
				 .exceptionOccurredWhileReceiving(e);
		}
	}

	/**
	 * @see #processConnectionExceptionEvent
	 */
	private final void processConnectionExceptionEvent_SEND_EXCEPTION(
	ConnectionExceptionEvent e) {
		if (exceptionListeners == null)
			return;  //no registered listeners

		synchronized (exceptionListeners) {
			for (int i = 0; i < exceptionListeners.size(); i++)
				((ConnectionExceptionListener)exceptionListeners.elementAt(i))
				 .exceptionOccurredWhileSending(e);
		}
	}

	/**
	 * Registers the specified <code>PacketListener</code> for this <code>
	 * Connection</code>.
	 *
	 * @param listener the <code>PacketListener</code> to register
	 */
	public void addPacketListener(PacketListener listener) {
		if (packetListeners == null)
			packetListeners = new Vector(1, 4);

		packetListeners.addElement(listener);
	}

	/**
	 * Unregisters the specified <code>PacketListener</code>.
	 *
	 * @param listener the <code>PacketListener</code> to unregister
	 */
	public void removePacketListener(PacketListener listener) {
		if (packetListeners == null)
			return;  //no registered listeners

		//listener may be contained multiple times
		synchronized (packetListeners) {
			while (packetListeners.removeElement(listener)) {}
		}
	}

	/**
	 * Registers the specified <code>ConnectionExceptionListener</code> for
	 * this <code>Connection</code>.
	 *
	 * @param listener the <code>ConnectionExceptionListener</code> to
	 *        register
	 */
	public void addConnectionExceptionListener(ConnectionExceptionListener
	 listener) {
		if (exceptionListeners == null)
			exceptionListeners = new Vector(1, 4);

		exceptionListeners.addElement(listener);
	}

	/**
	 * Unregisters the specified <code>ConnectionExceptionListener</code>.
	 *
	 * @param listener the <code>ConnectionExceptionListener</code> to
	 *        unregister
	 */
	public void removeConnectionExceptionListener(ConnectionExceptionListener
	 listener) {
		if (exceptionListeners == null)
			return;  //no registered listeners

		//listener may be contained multiple times
		synchronized (exceptionListeners) {
			while (exceptionListeners.removeElement(listener)) {}
		}
	}

	/**
	 * Returns the max. size of received packets.
	 *
	 * @see java.net.DatagramSocket#getReceiveBufferSize()
	 */
	public int getMaxRecvPacketSize() throws SocketException {
		return socket.getReceiveBufferSize();
	}

	/**
	 * Returns the max. allowed size for packets to be sent.
	 *
	 * @see java.net.DatagramSocket#getSendBufferSize()
	 */
	public int getMaxSendPacketSize() throws SocketException {
		return socket.getSendBufferSize();
	}

	/**
	 * Sends the specified <code>DatagramPacket</code>.
	 *
	 * @see java.net.DatagramSocket#send
	 * @param packet <code>DatagramPacket</code> to be sent
	 */
	public void send(DatagramPacket packet) {
		try {
			socket.send(packet);

			processPacketEvent(new PacketEvent(
			  this,
			  PacketEvent.PACKET_SENT,
			  packet
			));
		}
		catch (IOException e) {
			processConnectionExceptionEvent(
			  new ConnectionExceptionEvent(
			    this,
			    ConnectionExceptionEvent.SEND_EXCEPTION,
			    packet,
			    e
			  )
			);
		}
	}

	/**
	 * Returns the <code>DatagramSocket</code> currently used for tranceiving.
	 */
	public DatagramSocket getSocket() {
		return socket;
	}

	/**
	 * Sets the <code>DatagramSocket</code> to use for transceiving.
	 */
	public void setSocket(DatagramSocket socket) {
		this.socket = socket;
	}

	/**
	 * Returns <code>true</code> if this <code>UDPConnection</code> is
	 * listening for incoming packets. Otherwise, <code>false</code> is
	 * returned.
	 */
	public boolean isListening() {
		return (runner != null);
	}

	/**
	 * Forces this <code>UDPConnection</code> to start listening for
	 * incoming packets. Does nothing if already listening.
	 */
	public synchronized void start() {
		if (runner == null)
			(runner = new Thread(this)).start();
	}

	/**
	 * Stops this <code>UDPConnection</code> listening for incoming packets.
	 * Does nothing if already not listening.
	 */
	public void stop() {
		runner = null;
	}
}
