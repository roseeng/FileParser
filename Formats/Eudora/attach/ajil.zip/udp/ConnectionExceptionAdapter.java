//
// ConnectionExceptionAdapter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.udp;


/**
 * Adapter for the <code>ConnectionExceptionListener</code> interface.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2000-06-20
 *
 * @see ConnectionExceptionListener
 */


public /*not abstract, because it's useful*/ class ConnectionExceptionAdapter
 implements ConnectionExceptionListener {

// Method(s)
////////////////////

	/**
	 * Prints the cought Exception's stack trace.
	 *
	 * @see ConnectionExceptionListener#exceptionOccurredWhileReceiving
	 */
	public void exceptionOccurredWhileReceiving(ConnectionExceptionEvent e) {
		synchronized (System.out) {
			e.getException().printStackTrace(System.out);
		}
	}

	/**
	 * Prints the cought Exception's stack trace.
	 *
	 * @see ConnectionExceptionListener#exceptionOccurredWhileSending
	 */
	public void exceptionOccurredWhileSending(ConnectionExceptionEvent e) {
		synchronized (System.out) {
			e.getException().printStackTrace(System.out);
		}
	}
}
