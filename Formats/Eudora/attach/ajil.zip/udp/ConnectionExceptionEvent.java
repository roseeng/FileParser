//
// ConnectionExceptionEvent.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.udp;


/**
 * This event is fired when an <code>Exception</code> occures while a <code>
 * Connection</code> tries to receive or send a packet.
 *
 * @see Connection
 * @see ConnectionEvent
 * @see PacketEvent
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-06-01
 * @version 2000-06-20
 */


import java.net.DatagramPacket;


public class ConnectionExceptionEvent extends PacketEvent {

// Elements(s)
////////////////////

	/**
	 * This is the event id indicating the sort of event.
	 *
	 * @see ConnectionEvent#RECEIVE_EXCEPTION
	 * @see ConnectionEvent#SEND_EXCEPTION
	 */
	protected int id;

	/**
	 * Holds the <code>Exception</code> occurred while a <code>Connection
	 * </code> was trying to send or receive a <code>DatagramPacket</code>.
	 */
	protected Exception exception;


// Constructor(s)
////////////////////

	/**
	 * Constructs a new <code>ConnectionExceptionEvent</code> with the
	 * specified source, id, packet and exception.
	 *
	 * @param source event source
	 * @param id The event id may be either <code>RECEIVE_EXCEPTION</code>
	 *        or <code>SEND_EXCEPTION</code>.
	 * @param packet This is either the <code>DatagramPacket</code> the
	 *        <code>Connection</code> tried to send when the exception
	 *        occurred or it is <code>null</code> if the exception occurred
	 *        during the try to receive a packet.
	 *
	 * @see PacketEvent
	 * @see ConnectionEvent
	 */
	public ConnectionExceptionEvent(Object source, int id, DatagramPacket packet, Exception exception) {
		super(source, id, packet);
		this.exception = exception;
	}


// Method(s)
////////////////////
 
	/**
	 * @return the <code>Exception</code> which occurred while a <code>
	 *         Connection</code> was trying to send or receive a packet
	 *
	 * @see #exception
	 */
	public Exception getException() {
		return exception;
	}
} 
