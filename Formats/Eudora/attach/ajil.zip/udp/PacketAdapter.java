//
// PacketAdapter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.udp;


/**
 * Adapter for the <code>PacketListener</code> interface.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2000-06-20
 *
 * @see PacketListener
 */


public abstract class PacketAdapter implements PacketListener {

// Method(s)
////////////////////

	/**
	 * @see PacketListener#packetReceived
	 */
	public void packetReceived(PacketEvent e) {}

	/**
	 * @see PacketListener#packetSent
	 */
	public void packetSent(PacketEvent e) {}
}
