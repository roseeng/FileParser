//
// PacketListener.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
// Before you may use this file, you must read and agree to that license.
//



package ajil.udp;


/**
 * This listener interface must be implemented in order to gain the ability of
 * receiving <code>PacketEvent</code>s.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2000-06-20
 *
 * @see Connection
 * @see PacketEvent
 */


import java.net.DatagramPacket;


public interface PacketListener extends java.util.EventListener {

// Method(s)
////////////////////

	/**
	 * This method is invoked by <code>Connection</code> instances to
	 * indicate that a <code>DatagramPacket</code> was received. The data
	 * contained in the <code>PacketEvent</code> should not be modified,
	 * because this event could be broadcasted to multiple listeners.
	 *
	 * @param e PacketEvent containing event information
	 *
	 * @see PacketEvent
	 */
	public void packetReceived(PacketEvent e);

	/**
	 * This method is invoked by <code>Connection</code> instances to
	 * indicate that a <code>DatagramPacket</code> has been sent. The data
	 * contained in the <code>PacketEvent</code> should not be modified,
	 * because this event could be broadcasted to multiple listeners.
	 *
	 * @param e PacketEvent containing event information
	 *
	 * @see PacketEvent
	 */
	public void packetSent(PacketEvent e);
}
