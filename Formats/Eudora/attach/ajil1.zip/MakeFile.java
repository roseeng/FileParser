//
// MakeFile.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil;


/**
 * This file's purpose is the one of a make file. It does not contain anything
 * valuable for runtime. It makes use of a feature of the java compiler coming
 * with the JDK. That compiler looks for uncompiled or compilation-dated (when
 * source was modified) classes and (re-)compiles them if necessary.
 *
 * @author  Daniel Strecker <daniel-strecker@gmx.net>
 * @since   2000-05-21
 * @version 2001-05-02
 */


class MakeFile {
	ajil.Converter a1;

	ajil.protocol.AbstractPacketCrypter b1;
	ajil.protocol.FilterPacketCrypter b2;
	ajil.protocol.PacketCrypter b3;

	ajil.protocol.v5.V5Command c1;
	ajil.protocol.v5.V5PacketCrypter c2;

	ajil.tools.redirectServer.RedirectionImpl d1;
	ajil.tools.redirectServer.RedirectServer d2;
	ajil.tools.redirectServer.TextAreaOutputStream d3;
	ajil.tools.manualPacketCrypter.ManualV5PacketCrypter d4;

	ajil.udp.Connection e1;
	ajil.udp.ConnectionEvent e2;
	ajil.udp.ConnectionExceptionAdapter e3;
	ajil.udp.ConnectionExceptionEvent e4;
	ajil.udp.ConnectionExceptionListener e5;
	ajil.udp.PacketAdapter e6;
	ajil.udp.PacketEvent e7;
	ajil.udp.PacketListener e8;
}
