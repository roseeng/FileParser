//
// AbstractPacketCrypter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.protocol;


/**
 * <p>
 * Implements the methods <code>getEncryptedPacket</ocde> and <code>
 * getDecryptedPacket</code> of the <code>PacketCrypter</code> interface.</p>
 * <p>
 * Let your classes <code>extend</code> this class if you want to implement a
 * packet en-/decrypter that does not have to be a subclass of any other class.
 * </p>
 * 
 *
 * @see PacketCrypter
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-06-20
 * @version 2000-06-20
 */



public abstract class AbstractPacketCrypter
 implements PacketCrypter {


// Method(s)
////////////////////

	/**
	 * An invocation of this method has the same effect as <code>
	 * encrypt(packet, 0, packet.length);</code>.
	 *
	 * @see PacketCrypter#encrypt(byte[], int, int)
	 */
	public byte[] encrypt(byte[] packet) {
		return encrypt(packet, 0, packet.length);
	}

	/**
	 * No comment.
	 * @see PacketCrypter#getEncryptedPacket(byte[], int, int)
	 */
	public byte[] getEncryptedPacket(byte[] packet, int offset, int length) {
		byte[] packetCopy = new byte[length];

		System.arraycopy(packet, offset, packetCopy, 0, length);

		return encrypt(packetCopy);
	}

	/**
	 * An invocation of this method has the same effect as <code>
	 * getEncryptedPacket(packet, 0, packet.length);</code>.
	 *
	 * @see PacketCrypter#getEncryptedPacket(byte[], int, int)
	 */
	public byte[] getEncryptedPacket(byte[] packet) {
		return getEncryptedPacket(packet, 0, packet.length);
	}

	/**
	 * An invocation of this method has the same effect as <code>
	 * decrypt(packet, 0, packet.length);</code>.
	 *
	 * @see PacketCrypter#decrypt(byte[], int, int)
	 */
	public byte[] decrypt(byte[] packet) {
		return decrypt(packet, 0, packet.length);
	}

	/**
	 * No comment.
	 * @see PacketCrypter#getDecryptedPacket(byte[], int, int)
	 */
	public byte[] getDecryptedPacket(byte[] packet, int offset, int length) {
		byte[] packetCopy = new byte[length];

		System.arraycopy(packet, offset, packetCopy, 0, length);

		return decrypt(packetCopy);
	}

	/**
	 * An invocation of this method has the same effect as <code>
	 * getDecryptedPacket(packet, 0, packet.length);</code>.
	 *
	 * @see #getDecryptedPacket(byte[], int, int)
	 */
	public byte[] getDecryptedPacket(byte[] packet) {
		return getDecryptedPacket(packet, 0, packet.length);
	}
}
