//
// PacketCrypter.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.protocol;


/**
 * <p>
 * This class provides the interface for all packet encrypting or decrypting
 * classes. To encrypt or decrypt packets, a PacketCrypter must be instanciated
 * first. Then either of the methods <code>encrypt(byte[])</code> or <code>
 * getEncryptedPacket(byte[])</code> must be used for encryption, or either of
 * the methods <code>decrypt(byte[])</code> or <code>getDecryptedPacket(byte[])
 * </code> must be used for decryption.</p>
 * <p>
 * If you want to implement a packet decrypter or encrypter, then let your
 * class <code>impement</code> this interface and override its methods. But
 * before implementing this interface directly, have a look at the classes
 * <code>{@link AbstractPacketCrypter AbstractPacketCrypter}</code> and <code>
 * {@link FilterPacketCrypter FilterPacketCrypter}</code>.
 * </p>
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-03-21
 * @version 2000-06-20
 */



public interface PacketCrypter {


// Method(s)
////////////////////

	/**
	 * Encrypts a packet. The unencrypted data will be overwritten by the
	 * encrypted data. (I.e. the encrypted data will be stored in the
	 * delivered array.)
	 *
	 * @param packet byte array storing the unencrypted packet data
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @param length number of bytes that belong to the packet (packet length)
	 * @return the same byte array as delivered, but now contains encrypted
	 *         data
	 */
	public byte[] encrypt(byte[] packet, int offset, int length);

	/**
	 * Returns an encrypted packet. (I.e. it copies the unencrypted packet,
	 * encrypts the copy, and returns the copy.)
	 *
	 * @param packet byte array storing the unencrypted packet data
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @param length number of bytes that belong to the packet (packet length)
	 * @return byte array, storing the encrypted packet data
	 */
	public byte[] getEncryptedPacket(byte[] packet, int offset, int length);

	/**
	 * Decrypts a packet. The encrypted data will be overwritten by the
	 * decrypted data. (I.e. the decrypted data will be stored in the
	 * delivered array.)
	 *
	 * @param packet byte array storing the packet data to be decrypted
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @param length number of bytes that belong to the packet (packet length)
	 * @return the same byte array as delivered, but now contains decrypted
	 *         data
	 */
	public byte[] decrypt(byte[] packet, int offset, int length);

	/**
	 * Returns a decrypted packet. (I.e. it copies the encrypted packet,
	 * decrypts the copy and returns the copy.)
	 *
	 * @param packet byte array storing the packet data to be decrypted
	 * @param offset offset of the <code>packet</code> byte array (first
	 *        byte of packet, usually <code>0</code>)
	 * @param length number of bytes that belong to the packet (packet length)
	 * @return byte array, storing the decrypted packet data
	 */
	public byte[] getDecryptedPacket(byte[] packet, int offset, int length);
}
