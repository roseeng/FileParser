//
// ManualV5PacketCrypter.java
//
// Copyright (c) 2001 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.tools.manualPacketCrypter;


/**
 * This is an application for decrypting and encrypting ICQ V5 packets.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2001-04-20
 * @version 2001-04-20
 */


import java.awt.*;
import java.awt.event.*;
import ajil.protocol.v5.*;
import ajil.Converter;
import ajil.tools.redirectServer.TextAreaOutputStream;


public class ManualV5PacketCrypter extends Frame
 implements WindowListener, /*ActionListener,*/ FocusListener, TextListener {

// Elements(s)
////////////////////

	//----- packet en-/decryption
	public static final V5PacketCrypter pCrypter = new V5PacketCrypter();

	//----- GUI components
	private TextArea  encryptedDump = new TextArea(8, 48);
	private TextArea  decryptedDump = new TextArea(8, 48);
	private TextField checkcode     = new TextField("00 00 00 00");
	private TextArea  packetInfo    = new TextArea(12, 50);

	private long lastCryption = 0;

// Constructor(s)
////////////////////

	public ManualV5PacketCrypter() {
		super("Manual V5 Packet Crypter");

		setBackground(SystemColor.control);

		//----- layout
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(new GridBagLayout());

		Label
		 encryptedLabel = new Label("Encrypted Packet Data:"),
		 decryptedLabel = new Label("Decrypted Packet Data:"),
		 packtInfoLabel = new Label("Packet Information:"),
		 checkcodeLabel = new Label("Checkcode for Encryption:", Label.RIGHT);

		addCompToContByUsingGBC(encryptedLabel, this, gbc, 0, 0, 1, 1,   0,   0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(decryptedLabel, this, gbc, 1, 0, 1, 1,   0,   0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(encryptedDump,  this, gbc, 0, 1, 1, 2,  50,   0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(decryptedDump,  this, gbc, 1, 1, 2, 1,  50, 100, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(checkcodeLabel, this, gbc, 1, 2, 1, 1,   0,   0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(checkcode,      this, gbc, 2, 2, 1, 1,   0,   0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(packtInfoLabel, this, gbc, 0, 3, 3, 1,   0,   0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(packetInfo,     this, gbc, 0, 4, 3, 1,   0,   0, gbc.CENTER, gbc.BOTH);

		Font font = new Font("Monospaced" /* similar to "Courier"*/, Font.PLAIN, 14);
		encryptedDump.setFont(font);
		decryptedDump.setFont(font);
		packetInfo   .setFont(font);
		packetInfo.setEditable(false);

		decryptedDump.setText(
		 "    Manual V5 Packet Crypter\n" +
		 "  Copyright � 2001 by Daniel Strecker <daniel-strecker@gmx.net>\n" +
		 "    This application is distributed under the GNU General Public License.\n"
		);

		pack(); //make window as small as possible

		//----- center window on screen
		Dimension screenSize = getToolkit().getScreenSize();
		setLocation((screenSize.width - getWidth()) / 2, (screenSize.height - getHeight()) / 2);

		//----- listeners
		this        .addWindowListener(this);
		encryptedDump   .addFocusListener(this);
		decryptedDump   .addFocusListener(this);
		packetInfo      .addFocusListener(this);
		checkcode       .addFocusListener(this);
		encryptedDump   .addTextListener(this);
		decryptedDump   .addTextListener(this);
		checkcode       .addTextListener(this);

		this.requestFocus();
		this.setVisible(true);
	}


// Method(s)
////////////////////

	private void encryptedDumpChanged_Client() {
		byte[] data = Converter.getByteArray(encryptedDump.getText());

		if (data.length == 0) {
			decryptedDump.setText("");
			packetInfo.setText("");
			return;
		}

		pCrypter.decrypt(data);
		updateDecryptedDump_Client(data);
		updateCheckcode_Client(data);
		updatePacketInfo_Client(data);
	}

	private void decryptedDumpChanged_Client() {
		byte[] data = Converter.getByteArray(decryptedDump.getText());

		if (data.length == 0) {
			encryptedDump.setText("");
			packetInfo.setText("");
			return;
		}

		updateCheckcode_Client(data);
		updatePacketInfo_Client(data);
		updateEncryptedDump_Client(data);
	}

	private void checkcodeChanged_Client() {
		byte[] temp = Converter.getByteArray(checkcode.getText());

		if (temp.length != 4)
			return;

		byte[] data = Converter.getByteArray(decryptedDump.getText());
		Converter.setInt(data, 20, Converter.getInt(temp, 0));
		
		updateDecryptedDump_Client(data);
		updatePacketInfo_Client(data);
		updateEncryptedDump_Client(data);
	}

	private void updateCheckcode_Client(byte[] data) {
		checkcode.setText(Converter.getHexDump(data, 20, 4));
	}

	private void updateDecryptedDump_Client(byte[] data) {
		decryptedDump.setText(getFormattedHexDump(data, 0, data.length));
	}

	private void updateEncryptedDump_Client(byte[] data) {
		int checkCode = Converter.getInt(data, 20);
		pCrypter.doCrypt(data, 0, data.length, checkCode);
		Converter.setInt(data, 20, pCrypter.getScrambledCheckCode(checkCode));

		encryptedDump.setText(getFormattedHexDump(data, 0, data.length));
	}

	private void updatePacketInfo_Client(byte[] data) {
		String hexDumpAndParamStr;
		try {
			hexDumpAndParamStr =
			 "parameters: " + Converter.getHexDump(data, 24, data.length - 24) + '\n' +
			 "            (" + Converter.getString(data, 24, data.length - 24) + ')'
			;
		} catch (Exception e) {
			hexDumpAndParamStr =
			 "parameters: An exception occurred while trying to create hex dump and parameter string:\n" +
			 "            " + e.getClass().getName() + ": " + e.getMessage()
			;
		}

		String commandName;
		try { commandName = V5Command.forID(data, 14); }
		catch (IllegalArgumentException e) { commandName = e.getMessage(); }

		String infoString =
		 "packet length: " + data.length + '\n' +
		 "version   : " + Converter.getHexDump(data,  0,    2) + "       (" + Converter.get2BInt (data,  0) + ")\n" +
		 "zero      : " + Converter.getHexDump(data,  2,    4) +       " (" + Converter.get4BLong(data,  2) + ")\n" +
		 "uin       : " + Converter.getHexDump(data,  6,    4) +       " (" + Converter.get4BLong(data,  6) + ")\n" +
		 "session id: " + Converter.getHexDump(data, 10,    4) +       " (" + Converter.get4BLong(data, 10) + ")\n" +
		 "command   : " + Converter.getHexDump(data, 14,    2) + "       (" + commandName                   + ")\n" +
		 "seq num 1 : " + Converter.getHexDump(data, 16,    2) + "       (" + Converter.get2BInt (data, 16) + ")\n" +
		 "seq num 2 : " + Converter.getHexDump(data, 18,    2) + "       (" + Converter.get2BInt (data, 18) + ")\n" +
		 "checkcode : " + Converter.getHexDump(data, 20,    4) +       " (" + Converter.get4BLong(data, 20) + ")\n" +
		 hexDumpAndParamStr
		;

		packetInfo.setText(infoString);
	}

	public static void main(String[] args) {
		new ManualV5PacketCrypter();
	}

	private static final String getFormattedHexDump(byte[] b, int offset, int length) {
		StringBuffer buf = new StringBuffer(length * 3);

		int pEnd = offset + length;

		while (true) {
			length = pEnd - offset;

			if (length <= 16) {
				buf.append(Converter.getHexDump(b, offset, length)).append('\n');
				break;
			} else {
				buf.append(Converter.getHexDump(b, offset, 16)).append('\n');
			}

			offset += 16;
		}

		return buf.toString();
	}

	/**
	 * Adds a Component to a Container by using the current LayoutManager
	 * of the Container (which should be a GridBagLayout) and a specified
	 * GridBagConstraints object. The data to reset the GridBagConstraints
	 * object is delivered in the rest of the parameters.
	 *
	 * @param comp the Component to add to the Container
	 * @param cont the Container the Component should be added to
	 * @param gbc the GridBagConstraints to use
	 *
	 * @see java.awt.GridBagConstraints
	 * @see java.awt.Container#add(Component)
	 */
	public static final void addCompToContByUsingGBC(
	 Component comp, Container cont, GridBagConstraints gbc,
	 int gridx,     int gridy,
	 int gridwidth, int gridheight,
	 int weightx,   int weighty,
	 int anchor,    int fill
	 ) {
		gbc.gridx = gridx;
		gbc.gridy = gridy;
		gbc.gridwidth = gridwidth;
		gbc.gridheight = gridheight;
		gbc.weightx = weightx;
		gbc.weighty = weighty;
		gbc.anchor = anchor;
		gbc.fill = fill;

		cont.add(comp, gbc);
	}

//----- Text Events ----------------------------------

	public void textValueChanged(TextEvent e) {
		if (System.currentTimeMillis() - lastCryption < 100)
			return;

		lastCryption = System.currentTimeMillis();

		Object o = e.getSource();

		if      (o == encryptedDump)
			encryptedDumpChanged_Client();
		else if (o == decryptedDump)
			decryptedDumpChanged_Client();
		else if (o == checkcode)
			checkcodeChanged_Client();
	}

//----- Window Events ----------------------------------

	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
	public void windowOpened(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowActivated(WindowEvent e) {}
	public void windowDeactivated(WindowEvent e) {}

//----- Focus Events ----------------------------------

    public void focusGained(FocusEvent e) {
		Object o = e.getSource();

		if (o instanceof TextComponent) {
			TextComponent tc = (TextComponent)o;

			if (tc.getSelectionStart() == tc.getSelectionEnd())
				tc.selectAll();
		}
	}

    public void focusLost(FocusEvent e) {
        Object o = e.getSource();

		if (o instanceof TextComponent) {
			TextComponent tc = (TextComponent)o;

			if (tc.getSelectionStart() == 0 && tc.getSelectionEnd() != 0) {
				int selectionStart = tc.getSelectionStart();
				int selectionEnd   = tc.getSelectionEnd();

				tc.selectAll();
				if (tc.getSelectionStart() == selectionStart && tc.getSelectionEnd() == selectionEnd)
					tc.select(0, 0);
				else
					tc.select(selectionStart, selectionEnd);
			}
		}
	}

/*
//----- Action Events ----------------------------------

	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();

		if      (o == encryptButton)
			encryptPacket();
		else if (o == decryptButton)
			decryptPacket();
	}
*/
}
