//
// RedirectServer.java
//
// Copyright (c) 2000-2001 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.tools.redirectServer;


/**
 * This is the main class of the GUI application <i>Redirect Server</i>.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-16
 * @version 2000-06-20
 */


import ajil.udp.*;
import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;


public class RedirectServer extends Frame
 implements ActionListener, WindowListener {

//	static {
//		iconImg = Toolkit.getDefaultToolkit().
//	}

// Elements(s)
////////////////////

	//----- some default values
	public static final String DEFAULT_REMOTE_SERVER = "icq.mirabilis.com"; //or 127.0.0.1;
	public static final int    DEFAULT_REMOTE_PORT   = 4000;
	public static final String DEFAULT_LOCAL_SERVER  = "127.0.0.1"; //or localhost;
	public static final int    DEFAULT_LOCAL_PORT    = 4000;


//	public static Image iconImg;

	//----- GUI components
	private TextField remoteServer            = new TextField();
	private TextField remotePort              = new TextField();
	private Button    resetRemoteServerButton = new Button("Reset Remote Server");

	private TextField localServer             = new TextField();
	private TextField localPort               = new TextField();
	private Button    resetLocalServerButton  = new Button("Reset Local Server");

	private TextArea  textArea                = new TextArea();
	private TextField statusText              = new TextField();
	private Button    clearButton             = new Button("Clear");


	//----- 'implementation'
	private RedirectionImpl redirectionImpl;


// Constructor(s)
////////////////////

	public RedirectServer(String remoteServerName, int remotePortNumber, int localPortNumber) {
		super("Redirect Server");

		System.setOut(new PrintStream(new TextAreaOutputStream(textArea)));
		System.setErr(System.out);

		setBackground(SystemColor.control);

		//----- layout
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(new GridBagLayout());
		((GridBagLayout)getLayout()).columnWeights = new double[] {0, 1000, 0, 0, 10, 0};

		Label
		 remoteServerLabel = new Label("Remote Server: ", Label.RIGHT),
		 remotePortLabel   = new Label(  "Remote Port: ", Label.RIGHT),
		 localServerLabel  = new Label( "Local Server: ", Label.RIGHT),
		 localPortLabel    = new Label(   "Local Port: ", Label.RIGHT);

		addCompToContByUsingGBC(remoteServerLabel,       this, gbc, 0, 0, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(remoteServer,            this, gbc, 1, 0, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(remotePortLabel,         this, gbc, 2, 0, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(remotePort,              this, gbc, 3, 0, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(resetRemoteServerButton, this, gbc, 4, 0, 2, 1,    0,    0, gbc.CENTER, gbc.BOTH);

		addCompToContByUsingGBC(localServerLabel,        this, gbc, 0, 1, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(localServer,             this, gbc, 1, 1, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(localPortLabel,          this, gbc, 2, 1, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(localPort,               this, gbc, 3, 1, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(resetLocalServerButton,  this, gbc, 4, 1, 2, 1,    0,    0, gbc.CENTER, gbc.BOTH);

		addCompToContByUsingGBC(textArea,                this, gbc, 0, 2, 6, 1,    0, 1000, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(statusText,              this, gbc, 0, 3, 5, 1,    0,    0, gbc.CENTER, gbc.BOTH);
		addCompToContByUsingGBC(clearButton,             this, gbc, 5, 3, 1, 1,    0,    0, gbc.CENTER, gbc.BOTH);

		remoteServer.setText(remoteServerName);
		remotePort  .setText(Integer.toString(remotePortNumber));
		localServer .setText(getLocalHostName());
		localPort   .setText(Integer.toString(localPortNumber));
		textArea    .setEditable(false);
		textArea    .setFont(new Font("Monospaced" /* similar to "Courier"*/, Font.PLAIN, 14));
		statusText  .setEditable(false);

		textArea.setText(
		 "      RedirectServer\n" +
		 "   Copyright � 2000-2001 by Daniel Strecker <daniel-strecker@gmx.net>\n" +
		 "This application is distributed under the GNU General Public License.\n"
		);

		pack(); //make window as small as possible

		//----- center window on screen
		Dimension screenSize = getToolkit().getScreenSize();
		setLocation((screenSize.width - getWidth()) / 2, (screenSize.height - getHeight()) / 2);

		//----- listeners
		this                   .addWindowListener(this);
		resetRemoteServerButton.addActionListener(this);
		resetLocalServerButton .addActionListener(this);
		clearButton            .addActionListener(this);

		this.requestFocus();
		this.setVisible(true);

		redirectionImpl = new RedirectionImpl(null, null);
		resetRemoteServer();
		resetLocalServer();
	}


// Method(s)
////////////////////

	/**
	 * Returns the name of the local host or, if not able to
	 * retrieve the correct name, returns "127.0.0.1".
	 */
	public String getLocalHostName() {
		try {
			//ensure that this name works
			return InetAddress.getLocalHost().getByName(DEFAULT_LOCAL_SERVER).getHostName();
		}
		catch (UnknownHostException e) {
			try {
				return InetAddress.getLocalHost().getHostName();
			}
			catch (UnknownHostException uhe) {
				return "127.0.0.1";
			}
		}
	}

	/**
	 * Resets the remote server connection. :�) Source is public,
	 * so find out more on your own if you want!
	 */
	protected void resetRemoteServer() {
		if (remoteServer.getText().length() == 0)
			remoteServer.setText(DEFAULT_REMOTE_SERVER);

		if (remotePort.getText().length() == 0)
			remotePort.setText(Integer.toString(DEFAULT_REMOTE_PORT));

		Connection conn = redirectionImpl.getRemoteServerConnection();
		if (conn == null) {
			conn = new Connection(null);
			redirectionImpl.setRemoteServerConnection(conn);
		} else {
			conn.stop();
			conn.getSocket().close();
		}

		DatagramSocket socket;
		try {
			socket = new DatagramSocket();
			socket.connect(InetAddress.getByName(remoteServer.getText()), Integer.parseInt(remotePort.getText()));
		}
		catch (IOException e) {
			System.out.println("----- Couldn't initialize remote server connection:");
			e.printStackTrace(System.out);

			return;
		}

		conn.setSocket(socket);
		conn.start();

		recreateStatusText();
	}

	/**
	 * Resets the local server. :�) <same as in comment of 
	 * resetRemoteServer()>!
	 */
	protected void resetLocalServer() {
		if (localServer.getText().length() == 0)
			remoteServer.setText(getLocalHostName());

		if (localPort.getText().length() == 0)
			localPort.setText(Integer.toString(DEFAULT_LOCAL_PORT));

		Connection conn = redirectionImpl.getClientConnection();
		if (conn == null) {
			conn = new Connection(null);
			redirectionImpl.setClientConnection(conn);
		} else {
			conn.stop();
			conn.getSocket().close();
		}

		DatagramSocket socket;
		try {
			socket = new DatagramSocket(Integer.parseInt(localPort.getText()), InetAddress.getByName(localServer.getText()));
		}
		catch (IOException e) {
			System.out.println("----- Couldn't initialize client connection:");
			e.printStackTrace(System.out);

			return;
		}

		conn.setSocket(socket);
		conn.start();

		recreateStatusText();
	}

	/**
	 * Recreates the status text.
	 */
	public void recreateStatusText() {
		String cStr, sStr;

		try {
			DatagramSocket socket = redirectionImpl.getClientConnection().getSocket();

			cStr = /*local Info*/
			 socket.getLocalAddress().getHostName() +
			 " (IP: " + socket.getLocalAddress().getHostAddress() + "):" +
			 socket.getLocalPort();

		} catch (NullPointerException e) {
			cStr = "null";
		}
		try {
			DatagramSocket socket = redirectionImpl.getRemoteServerConnection().getSocket();

			sStr = /*remote Info*/
			 socket.getInetAddress().getHostName() +
			 " (IP: " + socket.getInetAddress().getHostAddress() + "):" +
			 socket.getPort();

		} catch (NullPointerException e) {
			sStr = "null";
		}
		
		statusText.setText(cStr + " -> " + sStr);
	}

	/**
	 * Adds a Component to a Container by using the current LayoutManager
	 * of the Container (which should be a GridBagLayout) and a specified
	 * GridBagConstraints object. The data to reset the GridBagConstraints
	 * object is delivered in the rest of the parameters.
	 *
	 * @param comp the Component to add to the Container
	 * @param cont the Container the Component should be added to
	 * @param gbc the GridBagConstraints to use
	 *
	 * @see java.awt.GridBagConstraints
	 * @see java.awt.Container#add(Component)
	 */
	public static final void addCompToContByUsingGBC(
	 Component comp, Container cont, GridBagConstraints gbc,
	 int gridx,     int gridy,
	 int gridwidth, int gridheight,
	 int weightx,   int weighty,
	 int anchor,    int fill
	 ) {
		gbc.gridx = gridx;
		gbc.gridy = gridy;
		gbc.gridwidth = gridwidth;
		gbc.gridheight = gridheight;
		gbc.weightx = weightx;
		gbc.weighty = weighty;
		gbc.anchor = anchor;
		gbc.fill = fill;

		cont.add(comp, gbc);
	}


	/**
	 * System entry. Command line arguments are processed here.
	 */
	public static void main(String[] args) {
		String remoteServerName;
		int    remotePortNumber;
		int    localPortNumber;

		try {
			switch (args.length) {
			  case 0:
				remoteServerName = DEFAULT_REMOTE_SERVER;
				remotePortNumber = DEFAULT_REMOTE_PORT;
				localPortNumber  = DEFAULT_LOCAL_PORT;
				break;

			  case 1:
			  case 2:
				int lastIndexOfColon = args[0].lastIndexOf(':');
				if (lastIndexOfColon != -1) {
					remoteServerName = args[0].substring(0, lastIndexOfColon);
					remotePortNumber = Integer.parseInt(args[0].substring(lastIndexOfColon + 1));
				} else {
					remoteServerName = args[0];
					remotePortNumber = DEFAULT_REMOTE_PORT;
				}
				localPortNumber = (args.length == 1) ? DEFAULT_LOCAL_PORT : Integer.parseInt(args[1]);
				break;

			  default:
				throw new NumberFormatException("(too many command line parameters)");
			}
		} catch (NumberFormatException e) {
			System.out.println("Usage: RedirectServer [<servername>[:<portnumber>]] [<localport>]");
			System.out.println("Default remote server : " + DEFAULT_REMOTE_SERVER + ".");
			System.out.println("Default remote port   : " + DEFAULT_REMOTE_PORT   + ".");
			System.out.println("Default local port    : " + DEFAULT_LOCAL_PORT    + ".");

			return;  //should be interchangeable with System.exit(0);
		}

		new RedirectServer(remoteServerName, remotePortNumber, localPortNumber);
	}

//----- Window Events ----------------------------------

	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
	public void windowOpened(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowActivated(WindowEvent e) {}
	public void windowDeactivated(WindowEvent e) {}

//----- Action Events ----------------------------------

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if      (obj == resetRemoteServerButton)
			resetRemoteServer();

		else if (obj == resetLocalServerButton)
			resetLocalServer();

		else if (obj == clearButton)
			textArea.setText("");
	}
}
