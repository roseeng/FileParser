//
// RedirectionImpl.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.tools.redirectServer;


/**
 * This class is a user interface independent implementation of the
 * redirect server.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2001-04-16
 */


import ajil.udp.*;  //hey, yeah! This is the first time my tiny lib gets used! :�)
import ajil.protocol.v5.*;
import ajil.Converter;
import java.io.*;
import java.net.*;


public class RedirectionImpl
 implements PacketListener {

// Elements(s)
////////////////////

	public final static String LINE_SEP_STR = System.getProperty("line.separator");


	protected PacketListener packetListener; //if there is a user interface which wants to be up to date...

	protected Connection cConn; //used for sends to and receives from clients
	protected Connection sConn; //used for sends to and receives from remote server

	protected DatagramPacket bufferPacket;

	protected InetAddress clientAddr;  //InetAddress of client which last sent a client packet
	protected int         clientPort;  //port of client which last sent a client packet


	protected ConnectionExceptionAdapter connExceptAdapter = new ConnectionExceptionAdapter();


	//----- packet en-/decryption
	public static final V5PacketCrypter pCrypter = new V5PacketCrypter();

// Constructor(s)
////////////////////

	/**
	 * Constructs a new RedirectionImpl.
	 *
	 * @param cConn Connection to use for sending to and receiving from clients
	 * @param sConn Connection to use for sending to and receiving from remote server
	 */
	public RedirectionImpl(Connection cConn, Connection sConn) {
		if (cConn != null) setClientConnection(cConn);
		if (sConn != null) setRemoteServerConnection(sConn);
		bufferPacket = new DatagramPacket(new byte[1024], 1024);
	}


// Method(s)
////////////////////

	/**
	 * @see ajil.udp.PacketListener#packetSent
	 */
	public void packetSent(PacketEvent e) {
		Object src = e.getSource();

		if (src == sConn)
			System.out.print("=====> Forwarded packet to server.\n\n");
		else if (src == cConn)
			System.out.print("=====> Forwarded packet to client.\n\n");
	}

	/**
	 * Invoked when a packet was received from a client.
	 */
	protected void clientPacketReceived(DatagramPacket packet) {
		byte[] data   = packet.getData();
		int    length = packet.getLength();
		int    prms   = length - 24; //length of command specific parameters

		String hexDumpAndParamStr;
		try {
			hexDumpAndParamStr =
			 "parameters: " + Converter.getHexDump(data, 24, prms) + '\n' +
			 "            (" + Converter.getString(data, 24, prms) + ")\n"
			;
		} catch (Exception e) {
			hexDumpAndParamStr =
			 "parameters: An exception occurred while trying to create hex dump and parameter string:\n" +
			 "            " + e.getClass().getName() + ": " + e.getMessage() + '\n'
			;
		}

		String commandName;
		try { commandName = V5Command.forID(data, 14); }
		catch (IllegalArgumentException e) { commandName = e.getMessage(); }

		String infoString =
		 "===== Client packet received:\n" +
		 "remote host: " + packet.getAddress() + '\n' +
		 "remote port: " + packet.getPort() + '\n' +
		 "length     : " + length + '\n' +
		 "-----\n" +
		 "version   : " + Converter.getHexDump(data,  0,    2) + "       (" + Converter.get2BInt (data,  0) + ")\n" +
		 "zero      : " + Converter.getHexDump(data,  2,    4) +       " (" + Converter.get4BLong(data,  2) + ")\n" +
		 "uin       : " + Converter.getHexDump(data,  6,    4) +       " (" + Converter.get4BLong(data,  6) + ")\n" +
		 "session id: " + Converter.getHexDump(data, 10,    4) +       " (" + Converter.get4BLong(data, 10) + ")\n" +
		 "command   : " + Converter.getHexDump(data, 14,    2) + "       (" + commandName                   + ")\n" +
		 "seq num 1 : " + Converter.getHexDump(data, 16,    2) + "       (" + Converter.get2BInt (data, 16) + ")\n" +
		 "seq num 2 : " + Converter.getHexDump(data, 18,    2) + "       (" + Converter.get2BInt (data, 18) + ")\n" +
		 "checkcode : " + Converter.getHexDump(data, 20,    4) +       " (" + Converter.get4BLong(data, 20) + ")\n" +
		 hexDumpAndParamStr +
		 '\n'
		;

		System.out.print(infoString);
	}

	/**
	 * Invoked when a packet was received from the server.
	 */
	protected void serverPacketReceived(DatagramPacket packet) {
		byte[] data   = packet.getData();
		int    length = packet.getLength();
		int    prms   = length - 21; //length of command specific parameters

		String hexDumpAndParamStr;
		try {
			hexDumpAndParamStr =
			 "parameters: " + Converter.getHexDump(data, 21, prms) + '\n' +
			 "            (" + Converter.getString(data, 21, prms) + ")\n"
			;
		} catch (Exception e) {
			hexDumpAndParamStr =
			 "parameters: An exception occurred while trying to create hex dump and parameter string:\n" +
			 "            " + e.getClass().getName() + ": " + e.getMessage() + '\n'
			;
		}

		String commandName;
		try { commandName = V5Command.forID(data, 7); }
		catch (IllegalArgumentException e) { commandName = e.getMessage(); }

		String infoString =
		 "===== Server packet received:\n" +
		 "remote host: " + packet.getAddress() + '\n' +
		 "remote port: " + packet.getPort() + '\n' +
		 "length     : " + length + '\n' +
		 "-----\n" +
		 "version   : " + Converter.getHexDump(data,  0,    2) + "       (" + Converter.get2BInt (data,  0) + ")\n" +
		 "zero      : " + Converter.getHexDump(data,  2,    1)+"          ("+ Converter.get1BInt (data,  2) + ")\n" +
		 "session id: " + Converter.getHexDump(data,  3,    4) +       " (" + Converter.get4BLong(data,  3) + ")\n" +
		 "command   : " + Converter.getHexDump(data,  7,    2) + "       (" + commandName                   + ")\n" +
		 "seq num 1 : " + Converter.getHexDump(data,  9,    2) + "       (" + Converter.get2BInt (data,  9) + ")\n" +
		 "seq num 2 : " + Converter.getHexDump(data, 11,    2) + "       (" + Converter.get2BInt (data, 11) + ")\n" +
		 "uin       : " + Converter.getHexDump(data, 13,    4) +       " (" + Converter.get4BLong(data, 13) + ")\n" +
		 "checkcode : " + Converter.getHexDump(data, 17,    4) +       " (" + Converter.get4BLong(data, 17) + ")\n" +
		 hexDumpAndParamStr +
		 '\n'
		;

		System.out.print(infoString);
	}

	/**
	 * Invoked when a new DatagramPacket was received by either
	 * a client or the remote server.
	 */
	public synchronized void packetReceived(PacketEvent e) {
		DatagramPacket packet = e.getPacket();
		byte[] data = packet.getData();
		byte[] bufData = bufferPacket.getData();

		//----- copy received packet into buffer packet
		System.arraycopy(data, packet.getOffset(), bufData, 0, packet.getLength());
		bufferPacket.setData(bufData, 0, packet.getLength());
		bufferPacket.setAddress(packet.getAddress());
		bufferPacket.setPort(packet.getPort());

		if (e.getSource() == cConn) {
			pCrypter.decrypt(bufferPacket.getData(), 0, bufferPacket.getLength());

			try { clientPacketReceived(bufferPacket); }
			catch (Exception ex) {
				System.out.print("----- An exception occurred while composing client packet info:\n");
				ex.printStackTrace(System.out);
			}

			clientAddr = packet.getAddress();
			clientPort = packet.getPort();

			packet.setAddress(null);
			sConn.send(packet); //sConn's socket must be connected

		} else if (e.getSource() == sConn) {
			try { serverPacketReceived(bufferPacket); }
			catch (Exception ex) {
				System.out.print("----- An exception occurred while composing client packet info:\n");
				ex.printStackTrace(System.out);
			}

			if (clientAddr == null) {
				System.out.println("----- Couldn't forward remote server packet to client: Don't know client address.");
			} else {
				packet.setAddress(clientAddr);
				packet.setPort(clientPort);

				cConn.send(packet);
			}
		} else
			System.out.println("----- SHIT! What's this?! e.getSource() is neither equal to cConn nor to sConn (RedirectImpl.packetReceived(PacketEvent e))");

		if (packetListener != null)
			packetListener.packetReceived(e);
	}

	public Connection getClientConnection() {
		return cConn;
	}

	public void setClientConnection(Connection cConn) {
		if (this.cConn != null) {
			this.cConn.removePacketListener(this);
			this.cConn.removeConnectionExceptionListener(connExceptAdapter);
		}

		cConn.addPacketListener(this);
		cConn.addConnectionExceptionListener(connExceptAdapter);
		this.cConn = cConn;
	}

	public Connection getRemoteServerConnection() {
		return sConn;
	}

	public void setRemoteServerConnection(Connection sConn) {
		if (this.sConn != null) {
			this.sConn.removePacketListener(this);
			this.sConn.removeConnectionExceptionListener(connExceptAdapter);
		}

		sConn.addPacketListener(this);
		sConn.addConnectionExceptionListener(connExceptAdapter);
		this.sConn = sConn;
	}
}
