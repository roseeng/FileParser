//
// TextAreaOutputStream.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.tools.redirectServer;


/**
 * This <code>OutputStream</code> puts its output into a TextArea.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   1999-05-18
 * @version 2000-06-20
 */

import java.io.OutputStream;
import java.io.IOException;
import java.awt.TextArea;


public class TextAreaOutputStream extends OutputStream {

// Element(s)
////////////////////

	protected TextArea textArea;


// Constructor(s)
////////////////////

	/*
	 * Creates a new TextAreaOutputStream. The output will be put into the
	 * TextArea textArea.
	 */
	public TextAreaOutputStream(TextArea textArea) {
		if (textArea == null)
			throw new NullPointerException("textArea may not be null.");

		this.textArea = textArea;
	}

// Method(s)
////////////////////

	/*
	 * Ensures that this OutputStream is open.
	 */
	public void ensureOpen() throws IOException {
		if (textArea == null)
			throw new IOException("Stream closed.");
	}

	/*
	 * Returns the text area to put output into.
	 */
	public TextArea getTextArea() throws IOException {
		ensureOpen();

		return textArea;
	}

	/*
	 * Sets the text area to put output into.
	 */
	public void setTextArea(TextArea textArea) throws IOException {
		ensureOpen();

		if (textArea == null)
			throw new NullPointerException("textArea may not be null.");

		this.textArea = textArea;
	}

	/*
	 * Writes the specified byte to the TextArea.
	 *
	 * @param      b   the byte.
	 * @see        java.io.OutputStream#write(int)
	 */
	public final void write(int b) throws IOException {
		write(new byte[]{(byte)b});
	}

	/*
	 * Writes <code>b.length</code> bytes from the specified byte array to
	 * the TextArea.
	 *
	 * @param      b   the data.
	 * @see        java.io.OutputStream#write(byte[])
	 */
	public void write(byte b[]) throws IOException {
		ensureOpen();
		textArea.append(new String(b));
	}

	/*
	 * Writes len bytes from the specified byte array starting at offset
	 * off to the TextArea. 
	 *
	 * @param      b     the data.
	 * @param      off   the start offset in the data.
	 * @param      len   the number of bytes to write.
	 * @see        java.io.OutputStream#write(byte[], int, int)
	 */
	public void write(byte b[], int off, int len) throws IOException {
		ensureOpen();

		if (b == null)
			throw new NullPointerException();

		else if (len == 0)
			return;

		textArea.append(new String(b, off, len));
	}

	/*
	 * Flushes this output stream and forces any buffered output bytes 
	 * to be written to the TextArea. This output stream does not implement
	 * any buffering.
	 *
	 * @see        java.io.OutputStream#flush()
	 */
	public void flush() throws IOException {
		ensureOpen();
	}

	/*
	* Closes this output stream and releases any system resources 
	* associated with this stream.
	*
	* @exception  IOException  if an I/O error occurs.
	*/
	public void close() throws IOException {
		ensureOpen();

		try { finalize(); } catch (Throwable t) {}
	}
}
