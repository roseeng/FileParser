//
// ConnectionEvent.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.udp;


/**
 * This is the superclass of all event classes fired by a <code>Connection
 * </code>.
 *
 * @see Connection
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-06-01
 * @version 2000-06-20
 */



public abstract class ConnectionEvent extends java.util.EventObject {

// Elements(s)
////////////////////

	/**
	 * This id is assigned when a packet was received.
	 */
	public final static int PACKET_RECEIVED = 0;

	/**
	 * This id is assigned when a packet was sent.
	 */
	public final static int PACKET_SENT = 1;

	/**
	 * This id is assigned when the <code>Connection</code> encountered
	 * problems while trying to receive a packet.
	 */
	public final static int RECEIVE_EXCEPTION = 2;

	/**
	 * This id is assigned when the <code>Connection</code> encountered
	 * problems while trying to send a packet.
	 */
	public final static int SEND_EXCEPTION = 3;

	/**
	 * This is the event id indicating the sort of event.
	 */
	protected int id;

	/**
	 * The time when this event was constructed.
	 */
	protected long timestamp;


// Constructor(s)
////////////////////

	/**
	 * Constructs a new <code>ConnectionEvent</code> with the specified
	 * source and id.
	 *
	 * @param source The event source must be a <code>Connection</code>.
	 *        If not, a <code>java.lang.IllegalArgumentException</code>
	 *        will be thrown.
	 * @param id event id
	 */
	public ConnectionEvent(Object source, int id) {
		super(source);

		timestamp = System.currentTimeMillis();

		if (!(source instanceof Connection))
			throw new IllegalArgumentException("Event source must be an instance of ajil.udp.Connection.");

		this.id = id;
	}


// Method(s)
////////////////////
 
	/**
	 * Returns the id of this <code>ConnectionEvent</code>.
	 *
	 * @return event id
	 */
	public int getId() {
		return id;
	}
 
	/**
	 * Returns the time stamp. This is the time, when this event was
	 * constructed, in milliseconds since midnight, January 1st, 1970 UTC.
	 *
	 * @return timestamp
	 * @see java.lang.System.currentTimeMillis
	 */
	public long getTimestamp() {
		return timestamp;
	}
} 
