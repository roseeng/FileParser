//
// ConnectionExceptionListener.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.udp;


/**
 * The <code>ConnectionExceptionListener</code> listens for <code>
 * ConnectionExceptionEvent</code>s fired by a <code>Connection<code> to
 * indicate that an <code>Exception</code> occurred.
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-04-17
 * @version 2000-06-20
 *
 * @see Connection
 * @see ConnectionExceptionEvent
 */


import java.net.DatagramPacket;


public interface ConnectionExceptionListener extends java.util.EventListener {

// Method(s)
////////////////////

	/**
	 * This method is invoked by <code>Connection</code> instances to
	 * indicate that an <code>Exception</code> occurred while trying to
	 * receive a packet.
	 *
	 * @param e ConnectionExceptionEvent containing event information
	 *
	 * @see ConnectionExceptionEvent
	 */
	public void exceptionOccurredWhileReceiving(ConnectionExceptionEvent e);

	/**
	 * This method is invoked by <code>Connection</code> instances to
	 * indicate that an <code>Exception</code> occurred while trying to
	 * send a packet.
	 *
	 * @param e ConnectionExceptionEvent containing event information
	 *
	 * @see ConnectionExceptionEvent
	 */
	public void exceptionOccurredWhileSending(ConnectionExceptionEvent e);
}
