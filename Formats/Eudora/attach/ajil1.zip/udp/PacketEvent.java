//
// PacketEvent.java
//
// Copyright (c) 2000 by Daniel Strecker <daniel-strecker@gmx.net>
//
// This file is distributed under the GNU General Public License.
//



package ajil.udp;


/**
 * This event is fired when a <code>Connection</code> received or sent a <code>
 * DatagramPacket</code>.
 *
 * @see Connection
 *
 * @author  Daniel Strecker &lt;daniel-strecker@gmx.net&gt;
 * @since   2000-06-01
 * @version 2000-06-20
 */


import java.net.DatagramPacket;


public class PacketEvent extends ConnectionEvent {

// Elements(s)
////////////////////

	/**
	 * This is the event id indicating the sort of event.
	 *
	 * @see ConnectionEvent#PACKET_RECEIVED
	 * @see ConnectionEvent#PACKET_SENT
	 */
	protected int id;

	/**
	 * The received or sent <code>DatagramPacket</code>.
	 *
	 * @see #getPacket()
	 */
	protected DatagramPacket packet;


// Constructor(s)
////////////////////

	/**
	 * Constructs a new <code>PacketEvent</code> with the specified
	 * source, id, and packet.
	 *
	 * @param source event source
	 * @param id The event id may be either <code>PACKET_RECEIVED</code> or
	 *        <code>PACKET_SENT</code>.
	 * @param packet the received or sent <code>DatagramPacket</code>
	 *
	 * @see ConnectionEvent
	 */
	public PacketEvent(Object source, int id, DatagramPacket packet) {
		super(source, id);
		this.packet = packet;
	}


// Method(s)
////////////////////
 
	/**
	 * @return received or sent <code>DatagramPacket</code> this <code>
	 *         PacketEvent is constructed for
	 */
	public DatagramPacket getPacket() {
		return packet;
	}
} 
